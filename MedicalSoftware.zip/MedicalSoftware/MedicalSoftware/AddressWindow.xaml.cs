﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for AddressWindow.xaml
    /// </summary>
    public partial class AddressWindow : Window
    {
        Address address;
        private static int count;

        public static int Count
        {
            get { return AddressWindow.count; }
            set { AddressWindow.count = value; }
        }
        public AddressWindow()
        {
            InitializeComponent();
            
         }

        public AddressWindow(string aa1,string add2,string add3,string add4)
        {
            InitializeComponent();
            txtAddress.Text = aa1;
            txtCity.Text = add2;
            txtState.Text = add3;
            txtPincode.Text = add4;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
        }

        private void txtAddress_TextChanged(object sender, TextChangedEventArgs e)
        {
            Status.Visibility = Visibility.Hidden;
            ErrorStatus.Visibility = Visibility.Hidden;
            if (txtAddress.Text.Equals(""))
            {
                txtAddress.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtAddress.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                txtAddress.BorderBrush = new SolidColorBrush(Colors.Gray);
                txtAddress.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void txtCity_TextChanged(object sender, TextChangedEventArgs e)
        {
            Status.Visibility = Visibility.Hidden;
            ErrorStatus.Visibility = Visibility.Hidden;
            if (txtCity.Text.Equals(""))
            {
                txtCity.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtCity.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                System.Text.RegularExpressions.Regex regex4 = new System.Text.RegularExpressions.Regex("[a-zA-Z]+");
                if (!regex4.IsMatch(txtCity.Text))
                {
                    txtCity.BorderBrush = new SolidColorBrush(Colors.Red);
                    txtCity.Foreground = new SolidColorBrush(Colors.Red);
                    ErrorStatus.Text = "City Not In Correct Format."+"\n"+"Only Alphabets Accepted"+"\n"+"Ex:Hyderabad";
                    ErrorStatus.Visibility = Visibility.Visible;
                    txtCity.Focus();
                }
                else
                {
                    txtCity.BorderBrush = new SolidColorBrush(Colors.Gray);
                    txtCity.Foreground = new SolidColorBrush(Colors.Orange);
                }
            }
        }

        private void txtState_TextChanged(object sender, TextChangedEventArgs e)
        {
            Status.Visibility = Visibility.Hidden;
            ErrorStatus.Visibility = Visibility.Hidden;
            if (txtState.Text.Equals(""))
            {
                txtState.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtState.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                System.Text.RegularExpressions.Regex regex2 = new System.Text.RegularExpressions.Regex("[a-zA-Z]+");
                            if (!regex2.IsMatch(txtState.Text))
                            {
                                txtState.BorderBrush = new SolidColorBrush(Colors.Red);
                                txtState.Foreground = new SolidColorBrush(Colors.Red);
                                ErrorStatus.Text = "State Not In Correct Format."+"\n"+"Only Alphabets Accepted"+"\n"+"Ex:AndhraPradesh";
                                ErrorStatus.Visibility = Visibility.Visible;
                                txtState.Focus();
                            }
                            else
                            {
                txtState.BorderBrush = new SolidColorBrush(Colors.Gray);
                txtState.Foreground = new SolidColorBrush(Colors.Orange);
            }
            }
        }

        private void txtPincode_TextChanged(object sender, TextChangedEventArgs e)
        {
            Status.Visibility = Visibility.Hidden;
            ErrorStatus.Visibility = Visibility.Hidden;
            if (txtPincode.Text.Equals(""))
            {
                txtPincode.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtPincode.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
               
                 System.Text.RegularExpressions.Regex regex3 = new System.Text.RegularExpressions.Regex("[1-9]+");
                 if (!regex3.IsMatch(txtPincode.Text))
                 {
                     txtPincode.BorderBrush = new SolidColorBrush(Colors.Red);
                     txtPincode.Foreground = new SolidColorBrush(Colors.Red);
                     ErrorStatus.Text = "Pincode Not In Correct Format."+"\n"+"It should Be Of 6 Digits Not Starting With 0."+"\n"+"[ex:Pincode:500060]";
                     ErrorStatus.Visibility = Visibility.Visible;
                     txtPincode.Focus();
                 }
                 else
                 {
                     txtPincode.BorderBrush = new SolidColorBrush(Colors.Gray);
                     txtPincode.Foreground = new SolidColorBrush(Colors.Orange);
                 }
            }
        }

        private void btnAddAddress_Click(object sender, RoutedEventArgs e)
        {
            Status.Visibility = Visibility.Hidden;
            ErrorStatus.Visibility = Visibility.Hidden;
            Thickness marginText = Status.Margin;
            Status.Height = 20;
            Status.Width = 200;
            if (txtAddress.Text.Equals(""))
            {
                txtAddress.BorderBrush = new SolidColorBrush(Colors.Red);
                Status.Margin = new Thickness(40.0, -70.0, 0.0, 0.0);
                Status.Text = "Enter Address";
                Status.Visibility = Visibility.Visible;
                txtAddress.Focus();
            }
            else
            {
                //System.Text.RegularExpressions.Regex regex1 = new System.Text.RegularExpressions.Regex("");
                //if (!regex1.IsMatch(txtAddress.Text))
                //{
                //    txtAddress.BorderBrush = new SolidColorBrush(Colors.Red);
                //    Status.Text = "Address Not In Correct Format";
                //    Status.Visibility = Visibility.Visible;
                //    txtAddress.Focus();
                //}
                //else
                //{
                if (txtCity.Text.Equals(""))
                {
                    txtCity.BorderBrush = new SolidColorBrush(Colors.Red);
                    Status.Margin = new Thickness(40.0, 2.0, 0.0, 0.0);
                    Status.Text = "Enter City";
                    Status.Visibility = Visibility.Visible;
                    txtCity.Focus();
                }
                else
                {
                    if (txtState.Text.Equals(""))
                        {
                            txtState.BorderBrush = new SolidColorBrush(Colors.Red);
                            Status.Margin = new Thickness(40.0, 72.0, 0.0, 0.0);
                            Status.Text = "Enter State";
                            Status.Visibility = Visibility.Visible;
                            txtState.Focus();
                        }
                        else
                        {
                             if (txtPincode.Text.Equals(""))
                                {
                                    txtPincode.BorderBrush = new SolidColorBrush(Colors.Red);
                                    Status.Margin = new Thickness(40.0, 147.0, 0.0, 0.0);
                                    Status.Text = "Enter Pincode";
                                    Status.Visibility = Visibility.Visible;
                                    txtPincode.Focus();
                                }
                                else
                                {
                                    System.Text.RegularExpressions.Regex regex3 = new System.Text.RegularExpressions.Regex("[1-9]{1}[0-9]{5}");
                                    if (!regex3.IsMatch(txtPincode.Text))
                                    {
                                        txtPincode.BorderBrush = new SolidColorBrush(Colors.Red);
                                        ErrorStatus.Text = "Pincode Not In Correct Format." + "\n" + "It should Be Of 6 Digits Not Starting With 0." + "\n" + "[ex:Pincode:500060]";
                                        txtPincode.Foreground = new SolidColorBrush(Colors.Red);
                                        ErrorStatus.Visibility = Visibility.Visible;
                                        txtPincode.Focus();
                                    }
                                    else
                                    {
                                        address = new Address(txtAddress.Text, txtCity.Text, txtState.Text, Convert.ToInt64(txtPincode.Text));
                                        Count = 1;
                                        this.Close();
                                        txtAddress.Text = null;
                                        txtCity.Text = null;
                                        txtPincode.Text = null;
                                        txtState.Text = null;
                                    }
                                }
                            }

                        }
                    }
                }
            

        private void btnResetAddress_Click(object sender, RoutedEventArgs e)
        {
            txtAddress.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtCity.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtState.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtPincode.BorderBrush = new SolidColorBrush(Colors.Orange);
            Status.Visibility = Visibility.Hidden;
            ErrorStatus.Visibility = Visibility.Hidden;
            txtAddress.Text = null;
            txtCity.Text = null;
            txtPincode.Text = null;
            txtState.Text = null;
            
        }
    }
}
