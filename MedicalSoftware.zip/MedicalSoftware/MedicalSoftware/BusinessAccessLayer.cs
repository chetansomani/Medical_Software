﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace MedicalSoftware
{
   public class BusinessAccessLayer
    {
       DataAccessLayer dataAccess;
       public BusinessAccessLayer()
       {
           dataAccess = new DataAccessLayer();
       }

        //********************Login & Register*********************//

       //Check Login Credentials
       public DataTable checkLoginDetails(string username, string passward)
       {
           return dataAccess.checkLoginDetails(username, passward);
       }


        //Registered Data
       public int newRegisterDetails(string RegisterID, string USERNAME, string PASSWARD, string QUESTION, string ANSWER)
       {
           return dataAccess.newRegisterDetails(RegisterID, USERNAME, PASSWARD, QUESTION, ANSWER);
       }

        //AutoGenerate Register Id
       public string autoRegisterId()
       {
           return dataAccess.autoRegisterId();
       }

        //Forgot Password

       public string getQuestion(string username)
       {
           return dataAccess.getQuestion(username);
       }

       //Validate Answer
       public int validateAns(string username, string answer)
       {
           return dataAccess.validateAns(username, answer);
       }

         //Update New Password
       public int updateNewPassword(string username, string newPass)
       {
           return dataAccess.updateNewPassword(username, newPass);
       }
        //******************Customer***********************//
      
       //Populate CustomerName
       public DataTable populateCustomerName()
       {
           return dataAccess.populateCustomerName();
       }

         //Display CustomerName
       public DataTable displayCustomerName(string custName)
       {
           return dataAccess.displayCustomerName(custName);
       }

       //Add CustomerDetails
       public int newCustomerDetails(string custCode, string custDlno, string custName, string custAddress, long custPhno1, long custPhno2)
       {
           return dataAccess.newCustomerDetails(custCode, custDlno, custName, custAddress, custPhno1, custPhno2);
       }

        //View CustomerDetails
       public DataSet viewCustomerDetails(string custcode)
       {
           return dataAccess.viewCustomerDetails(custcode);
       }

       //Update CustomerDetails
       public int updateCustomerDetails(string custCode, string custDlno, string custName, string custAddress, long custPhno1, long custPhno2)
       {
           return dataAccess.updateCustomerDetails(custCode, custDlno, custName, custAddress, custPhno1, custPhno2);
       }

         //Delete CustomerDetails
       public int deleteCustomerDetails(string custCode)
       {
           return dataAccess.deleteCustomerDetails(custCode);
       }

         //***********************************Customer Transactions******************************************//
       //New CustomerTransactions
       //public void newCustTransaction(out int value, string custcode, DateTime dateOfRecieval, double amount)
       //{
       //   dataAccess.newCustTransaction(out value, custcode, dateOfRecieval, amount);
       //}

       
       ////Update CustomerTransactions
       //public int updateCustomerTransaction(int transactionId, double amount)
       //{
       //    return dataAccess.updateCustomerTransaction(transactionId, amount);
       //}
        
       //***********************************View Common Transactions******************************************//
        //View Transactions (Customer-1,Vendor-2,TotalCustomer-3,TotalVendor-4)
       //public DataSet viewTransactions(int value, string custcode)
       //{
       //    return dataAccess.viewTransactions(value, custcode);
       //}

       //******************Vendor***********************//

       //Populate VendorName
       public DataTable populateVendorName()
       {
           return dataAccess.populateVendorName();
       }

        //Display VendorName
       public DataTable displayVendorName(string venName)
       {
           return dataAccess.displayVendorName(venName);
       }

       //Add VendorDetails
       public int newVendorDetails(string venCode, string venDlno, string venName, string venAddress, long venPhno1, long venPhno2)
       {
           return dataAccess.newVendorDetails(venCode, venDlno, venName, venAddress, venPhno1, venPhno2);
       }

       //View VendorDetails
       public DataSet viewVendorDetails(string vencode)
       {
           return dataAccess.viewVendorDetails(vencode);
       }

       //Update VendorDetails
       public int updateVendorDetails(string venCode, string venDlno, string venName, string venAddress, long venPhno1, long venPhno2)
       {
           return dataAccess.updateVendorDetails(venCode, venDlno, venName, venAddress, venPhno1, venPhno2);
       }

       //Delete VendorDetails
       public int deleteVendorDetails(string venCode)
       {
           return dataAccess.deleteVendorDetails(venCode);
       }

         //***********************************View Common Customer Transactions******************************************//
       //View Transactions 
       //public DataSet viewVendorTransactions(int value, string vencode)
       //{
       //    return dataAccess.viewVendorTransactions(value, vencode);
       //}
       ////***********************************Vendor Transactions******************************************//
       ////New VendorTransactions
       //public void newvenTransaction(out int value, string vencode, DateTime dateOfRecieval, double amount)
       //{
       //    dataAccess.newvenTransaction(out value, vencode, dateOfRecieval, amount);
       //}


       ////Update VendorTransactions
       //public int updateVendorTransaction(int transactionId, double amount)
       //{
       //    return dataAccess.updateVendorTransaction(transactionId, amount);
       //}

       //**********************************************Product Details**********************************************//

         //AutoGenerate Product Id
       public string autoProductId()
       {
           return dataAccess.autoProductId();
       }

       //Populate ProductName
       public DataTable populateProductName()
       {
           return dataAccess.populateProductName();
       }

       //Add ProductDetails
       public int newProductDetails(string prodId, string prodBatchNo, string prodMFG, string prodName, string prodPack, long quant, DateTime prodExpiry, double prodMRP)
       {
           return dataAccess.newProductDetails(prodId,prodBatchNo,prodMFG,prodName,prodPack,quant,prodExpiry,prodMRP);
       }

       //View ProductDetails
       public DataSet viewProductDetails(string Productdata, int count)
       {
           return dataAccess.viewProductDetails(Productdata,count);
       }

       //Update ProductDetails
       public int updateProductDetails(string prodId, string prodBatchNo, string prodMFG, string prodName, string prodPack, long quant, DateTime prodExpiry, double prodMRP)
       {
           return dataAccess.updateProductDetails(prodId, prodBatchNo, prodMFG, prodName, prodPack, quant, prodExpiry, prodMRP);
       }

       //Delete ProductDetails
       public int deleteProductDetails(string productBatchNo)
       {
           return dataAccess.deleteProductDetails(productBatchNo);
       }

       /***************************************************Booking***************************************************/
       public string autoBookingId()
       {
           return dataAccess.autoBookingId();
       }
    
         /****************************Insert Booking Details***********************************************************/
       public int insertBookingDetails(string bookId, string venName, string prodName, int carBooked, long quantBooked, DateTime dateOfBooking, string statusOfBooking)
       {
           return dataAccess.insertBookingDetails(bookId, venName, prodName, carBooked, quantBooked, dateOfBooking, statusOfBooking);
       }

          /************View Booking Details****************/

       public DataSet viewBookingDetails(int count, string status, string vendor, string date, string product)
       {
           return dataAccess.viewBookingDetails(count, status, vendor, date, product);
       }
    }
}
