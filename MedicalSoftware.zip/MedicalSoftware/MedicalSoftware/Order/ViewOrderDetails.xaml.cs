﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace MedicalSoftware.Order
{
    /// <summary>
    /// Interaction logic for ViewOrderDetails.xaml
    /// </summary>
    public partial class ViewOrderDetails : UserControl
    {
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        //DataSet ds;
        private int count;

        public int Count
        {
            get { return count; }
            set { count = value; }
        }

        public ViewOrderDetails()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void checkboxOrderPending_Checked(object sender, RoutedEventArgs e)
        {
            Count = 1;
            txtBorderSearchOrderPending.BorderBrush = new SolidColorBrush(Colors.Orange);
            checkboxOrderDispatched.IsChecked = false;
            checkboxOrderDelivered.IsChecked = false;
            checkboxGroupByDate.Visibility = Visibility.Visible;
            checkboxgroupByProduct.Visibility = Visibility.Visible;
            checkboxGroupByCustomer.Visibility = Visibility.Visible;
            txtBorderGroupByDate.BorderBrush = new SolidColorBrush(Colors.White);
            txtBordergroupByProduct.BorderBrush = new SolidColorBrush(Colors.White);
            txtBorderGroupByCustomer.BorderBrush = new SolidColorBrush(Colors.White);
            checkboxgroupByProduct.IsChecked = false;
            checkboxGroupByDate.IsChecked = false;
            checkboxGroupByCustomer.IsChecked = false;
        }

        private void checkboxOrderPending_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBorderSearchOrderPending.BorderBrush = new SolidColorBrush(Colors.White);
            checkboxGroupByDate.Visibility = Visibility.Collapsed;
            checkboxgroupByProduct.Visibility = Visibility.Collapsed;
            checkboxGroupByCustomer.Visibility = Visibility.Collapsed;
        }

        private void checkboxOrderDispatched_Checked(object sender, RoutedEventArgs e)
        {
            Count = 2;
            txtBorderSearchOrderDispatched.BorderBrush = new SolidColorBrush(Colors.Orange);
            checkboxOrderPending.IsChecked = false;
            checkboxOrderDelivered.IsChecked = false;
            checkboxGroupByDate.Visibility = Visibility.Visible;
            checkboxgroupByProduct.Visibility = Visibility.Visible;
            checkboxGroupByCustomer.Visibility = Visibility.Visible;
            txtBorderGroupByDate.BorderBrush = new SolidColorBrush(Colors.White);
            txtBordergroupByProduct.BorderBrush = new SolidColorBrush(Colors.White);
            txtBorderGroupByCustomer.BorderBrush = new SolidColorBrush(Colors.White);
            checkboxgroupByProduct.IsChecked = false;
            checkboxGroupByDate.IsChecked = false;
            checkboxGroupByCustomer.IsChecked = false;
        }

        private void checkboxOrderDispatched_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBorderSearchOrderDispatched.BorderBrush = new SolidColorBrush(Colors.White);
            checkboxGroupByDate.Visibility = Visibility.Collapsed;
            checkboxgroupByProduct.Visibility = Visibility.Collapsed;
            checkboxGroupByCustomer.Visibility = Visibility.Collapsed;
        }

        private void checkboxOrderDelivered_Checked(object sender, RoutedEventArgs e)
        {
            Count = 3;
            txtBorderSearchOrderDelivered.BorderBrush = new SolidColorBrush(Colors.Orange);
            checkboxOrderPending.IsChecked = false;
            checkboxOrderDispatched.IsChecked = false;
            checkboxGroupByDate.Visibility = Visibility.Visible;
            checkboxgroupByProduct.Visibility = Visibility.Visible;
            checkboxGroupByCustomer.Visibility = Visibility.Visible;
            txtBorderGroupByDate.BorderBrush = new SolidColorBrush(Colors.White);
            txtBordergroupByProduct.BorderBrush = new SolidColorBrush(Colors.White);
            txtBorderGroupByCustomer.BorderBrush = new SolidColorBrush(Colors.White);
            checkboxgroupByProduct.IsChecked = false;
            checkboxGroupByDate.IsChecked = false;
            checkboxGroupByCustomer.IsChecked = false;
        }

        private void checkboxOrderDelivered_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBorderSearchOrderDelivered.BorderBrush = new SolidColorBrush(Colors.White);
            checkboxGroupByDate.Visibility = Visibility.Collapsed;
            checkboxgroupByProduct.Visibility = Visibility.Collapsed;
            checkboxGroupByCustomer.Visibility = Visibility.Collapsed;
        }

        private void checkboxGroupByCustomer_Checked(object sender, RoutedEventArgs e)
        {
            txtBorderGroupByCustomer.BorderBrush = new SolidColorBrush(Colors.Orange);
            checkboxgroupByProduct.IsChecked = false;
            checkboxGroupByDate.IsChecked = false;
        }

        private void checkboxGroupByCustomer_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBorderGroupByCustomer.BorderBrush = new SolidColorBrush(Colors.White);
        }

        private void checkboxGroupByDate_Checked(object sender, RoutedEventArgs e)
        {
            txtBorderGroupByDate.BorderBrush = new SolidColorBrush(Colors.Orange);
            checkboxgroupByProduct.IsChecked = false;
            checkboxGroupByCustomer.IsChecked = false;
        }

        private void checkboxGroupByDate_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBorderGroupByDate.BorderBrush = new SolidColorBrush(Colors.White);
        }

        private void checkboxgroupByProduct_Checked(object sender, RoutedEventArgs e)
        {
            txtBordergroupByProduct.BorderBrush = new SolidColorBrush(Colors.Orange);
            checkboxGroupByCustomer.IsChecked = false;
            checkboxGroupByDate.IsChecked = false;
        }

        private void checkboxgroupByProduct_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBordergroupByProduct.BorderBrush = new SolidColorBrush(Colors.White);
        }

     
    }
}
