﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace MedicalSoftware.Order
{
    /// <summary>
    /// Interaction logic for AddOrderDetails.xaml
    /// </summary>
    public partial class AddOrderDetails : UserControl
    {
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        DataTable dt;
        DataSet ds;
        private int count;

        public int Count
        {
            get { return count; }
            set { count = value; }
        }

        public AddOrderDetails()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void NewOrderCustomerName_TextChanged(object sender, TextChangedEventArgs e)
        {
            Thickness marginList = displayOrderDataDetails.Margin;
            Thickness marginError = ErrorStatus.Margin;
            if (NewOrderCustomerName.Text.Equals(""))
            {
                NewOrderCustomerName.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewOrderCustomerName.Foreground = new SolidColorBrush(Colors.Gray);
                Status.Visibility = Visibility.Collapsed;
                displayOrderDataDetails.Visibility = Visibility.Collapsed;
                ErrorStatus.Visibility = Visibility.Collapsed;
            }
            else
            {
                NewOrderCustomerName.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewOrderCustomerName.Foreground = new SolidColorBrush(Colors.Orange);
                dt = businessLayer.displayCustomerName(NewOrderCustomerName.Text);
                if (dt.Rows.Count == 0)
                {
                    displayOrderDataDetails.Visibility = Visibility.Collapsed;
                    ErrorStatus.Margin = new Thickness(40.0, -214.0, 0.0, 0.0);
                    ErrorStatus.Visibility = Visibility.Visible;
                    ErrorStatus.Text = "No Customer Records Found";
                }
                else
                {
                    Count = 1;
                    Binding bind = new Binding();
                    Binding bind1 = new Binding("CustomerName");
                    ErrorStatus.Visibility = Visibility.Collapsed;
                    Status.Visibility = Visibility.Collapsed;
                    displayOrderDataDetails.Visibility = Visibility.Visible;
                    displayOrderDataDetails.DataContext = dt;
                    displayOrderDataDetails.SetBinding(ListView.ItemsSourceProperty, bind);
                    listColumnView.Header = "CustomerName";
                    listColumnView.DisplayMemberBinding = bind1;
                    displayOrderDataDetails.Margin = new Thickness(-270, 10, 0, 0);

                }
            }
        }

        private void NewOrderProductName_TextChanged(object sender, TextChangedEventArgs e)
        {
            Thickness marginList = displayOrderDataDetails.Margin;
            if (NewOrderProductName.Text.Equals(""))
            {
                NewOrderProductName.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewOrderProductName.Foreground = new SolidColorBrush(Colors.Gray);
                Status.Visibility = Visibility.Collapsed;
                displayOrderDataDetails.Visibility = Visibility.Collapsed;
                ErrorStatus.Visibility = Visibility.Collapsed;
            }
            else
            {
                NewOrderProductName.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewOrderProductName.Foreground = new SolidColorBrush(Colors.Orange);
                ds = businessLayer.viewProductDetails(NewOrderProductName.Text, 1);
                if (ds.Tables["ProductTable"].Rows.Count == 0)
                {
                    displayOrderDataDetails.Visibility = Visibility.Collapsed;
                    ErrorStatus.Margin = new Thickness(40.0, -120.0, 0.0, 0.0);
                    ErrorStatus.Visibility = Visibility.Visible;
                    ErrorStatus.Text = "No Product Records Found";
                }
                else
                {
                    Count = 2;
                    Binding bind = new Binding("ProductTable");
                    Binding bind1 = new Binding("ProductName");
                    ErrorStatus.Visibility = Visibility.Collapsed;
                    Status.Visibility = Visibility.Collapsed;
                    displayOrderDataDetails.Visibility = Visibility.Visible;
                    displayOrderDataDetails.DataContext = ds;
                    displayOrderDataDetails.SetBinding(ListView.ItemsSourceProperty, bind);
                    listColumnView.Header = "ProductName";
                    listColumnView.DisplayMemberBinding = bind1;
                    displayOrderDataDetails.Margin = new Thickness(-270, 120, 0, 0);

                }
            }
        }

        private void displayOrderDataDetails_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int i = displayOrderDataDetails.SelectedIndex;
            if (i < 0)
            {

            }
            else
            {
                if (Count == 1)
                {
                    string CustomerName = (displayOrderDataDetails.SelectedItem as DataRowView).Row["CustomerName"].ToString();
                    NewOrderCustomerName.Text = CustomerName;
                    displayOrderDataDetails.Visibility = Visibility.Collapsed;
                }
                else if (Count == 2)
                {
                    NewOrderProductName.Text = (displayOrderDataDetails.SelectedItem as DataRowView).Row["ProductName"].ToString();
                    displayOrderDataDetails.Visibility = Visibility.Collapsed;
                }
            }
        }

        private void NewOrderPacks_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Collapsed;
            Status.Visibility = Visibility.Collapsed;
            if (NewOrderPacks.Text.Equals(""))
            {
                NewOrderPacks.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewOrderPacks.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewOrderPacks.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewOrderPacks.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void NewOrderQuantity_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Collapsed;
            Status.Visibility = Visibility.Collapsed;
            if (NewOrderQuantity.Text.Equals(""))
            {
                NewOrderQuantity.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewOrderQuantity.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewOrderQuantity.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewOrderQuantity.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void dtpNewOrderDate_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {

            ErrorStatus.Visibility = Visibility.Collapsed;
            Status.Visibility = Visibility.Collapsed;
            if (dtpNewOrderDate.SelectedDate.Equals(null))
            {
                dtpNewOrderDate.BorderBrush = new SolidColorBrush(Colors.Orange);
                dtpNewOrderDate.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                dtpNewOrderDate.BorderBrush = new SolidColorBrush(Colors.Gray);
                dtpNewOrderDate.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void cmbNewOrderStatus_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (cmbNewOrderStatus.SelectedIndex == 0)
            {
                cmbNewOrderStatus.BorderBrush = new SolidColorBrush(Colors.Orange);
                cmbNewOrderStatus.Foreground = new SolidColorBrush(Colors.Gray);

            }
            else
            {
                ErrorStatus.Visibility = Visibility.Hidden;
                Status.Visibility = Visibility.Hidden;
                cmbNewOrderStatus.BorderBrush = new SolidColorBrush(Colors.Gray);
                cmbNewOrderStatus.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void btnAddNewOrderDetails_Click(object sender, RoutedEventArgs e)
        {
            Thickness marginText = ErrorStatus.Margin;
            ErrorStatus.Height = 20;
            ErrorStatus.Width = 200;
            if (NewOrderCustomerName.Text.Equals(""))
            {
                NewOrderCustomerName.BorderBrush = new SolidColorBrush(Colors.Red);
                ErrorStatus.Margin = new Thickness(40.0, -214.0, 0.0, 0.0);
                ErrorStatus.Text = "Enter Customer Name";
                ErrorStatus.Visibility = Visibility.Visible;
                NewOrderCustomerName.Focus();
            }
            else
            {
                if (NewOrderProductName.Text.Equals(""))
                {
                    NewOrderProductName.BorderBrush = new SolidColorBrush(Colors.Red);
                    ErrorStatus.Margin = new Thickness(40.0, -120.0, 0.0, 0.0);
                    ErrorStatus.Text = "Enter Product Name";
                    ErrorStatus.Visibility = Visibility.Visible;
                    NewOrderProductName.Focus();
                }
                else
                {
                    if (NewOrderPacks.Text.Equals(""))
                    {
                        NewOrderPacks.BorderBrush = new SolidColorBrush(Colors.Red);
                        ErrorStatus.Margin = new Thickness(40.0, -30.0, 0.0, 0.0);
                        ErrorStatus.Text = "Enter Product Packs Ordered";
                        ErrorStatus.Visibility = Visibility.Visible;
                        NewOrderPacks.Focus();
                    }
                    else
                    {
                        if (NewOrderQuantity.Text.Equals(""))
                        {
                            NewOrderQuantity.BorderBrush = new SolidColorBrush(Colors.Red);
                            ErrorStatus.Margin = new Thickness(0.0, 60.0, 0.0, 0.0);
                            ErrorStatus.Text = "Enter Product Quantity Ordered";
                            ErrorStatus.Visibility = Visibility.Visible;
                            NewOrderQuantity.Focus();

                        }
                        else
                        {
                            if (dtpNewOrderDate.SelectedDate.Equals(null))
                            {
                                dtpNewOrderDate.BorderBrush = new SolidColorBrush(Colors.Red);
                                ErrorStatus.Margin = new Thickness(0.0, 170.0, 0.0, 0.0);
                                ErrorStatus.Text = "Enter Date Of Order";
                                ErrorStatus.Visibility = Visibility.Visible;
                                dtpNewOrderDate.Focus();
                            }
                            else
                            {
                                if (cmbNewOrderStatus.SelectedIndex == 0)
                                {
                                    cmbNewOrderStatus.BorderBrush = new SolidColorBrush(Colors.Red);
                                    ErrorStatus.Margin = new Thickness(0.0, 270.0, 0.0, 0.0);
                                    ErrorStatus.Text = "Select Order Status";
                                    ErrorStatus.Visibility = Visibility.Visible;
                                    cmbNewOrderStatus.Focus();
                                }

                                else
                                {
                                    //int result = businessLayer.newProductDetails(NewProductId.Text, NewProductBatchNo.Text, NewProductMFG.Text, NewProductName.Text, NewProductPack.Text, Convert.ToInt32(NewProductQuantity.Text), Convert.ToDateTime(NewProductExpiry.Text), Convert.ToDouble(NewProductMRP.Text));
                                    //if (result > 0)
                                    //{
                                    //    Status.Foreground = new SolidColorBrush(Colors.Gray);
                                    //    Status.Text = "Product" + " " + NewProductName.Text + " " + "Details Inserted Successfully";
                                    //    Status.Visibility = Visibility.Visible;

                                    //}
                                    //else
                                    //{
                                    //    Status.Foreground = new SolidColorBrush(Colors.Red);
                                    //    Status.Text = "Error In Inserting The Details Of Product" + " " + NewProductName.Text;
                                    //    Status.Visibility = Visibility.Visible;
                                    //}
                                }
                            }
                        }
                    }
                }
            }
        }

        private void btnResetNewOrderDetails_Click(object sender, RoutedEventArgs e)
        {
            nullMethod();
        }

        private void nullMethod()
        {
            displayOrderDataDetails.Visibility = Visibility.Collapsed;
            ErrorStatus.Visibility = Visibility.Collapsed;
            Status.Visibility = Visibility.Collapsed;
            NewOrderPacks.Text = null;
            NewOrderProductName.Text = null;
            NewOrderQuantity.Text = null;
            NewOrderCustomerName.Text = null;
            cmbNewOrderStatus.SelectedIndex = 0;
            dtpNewOrderDate.SelectedDate = null;
            dtpNewOrderDate.BorderBrush = new SolidColorBrush(Colors.Orange);
            dtpNewOrderDate.Foreground = new SolidColorBrush(Colors.Gray);
            cmbNewOrderStatus.BorderBrush = new SolidColorBrush(Colors.Orange);
            cmbNewOrderStatus.Foreground = new SolidColorBrush(Colors.Gray);
            NewOrderQuantity.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewOrderQuantity.Foreground = new SolidColorBrush(Colors.Gray);
            NewOrderPacks.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewOrderPacks.Foreground = new SolidColorBrush(Colors.Gray);
            NewOrderProductName.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewOrderProductName.Foreground = new SolidColorBrush(Colors.Gray);
            NewOrderCustomerName.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewOrderCustomerName.Foreground = new SolidColorBrush(Colors.Gray);
        }

       
    }
}
