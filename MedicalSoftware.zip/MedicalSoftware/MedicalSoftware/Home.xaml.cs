﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Windows.Forms.Integration;

namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    public partial class Home : Window
    {
        DispatcherTimer progressDispatch;
        ViewVendorDetails viewV;
        public Home()
        {
            InitializeComponent();
            progressDispatch = new DispatcherTimer();
            viewV = new ViewVendorDetails();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            homeTree.Visibility = Visibility.Hidden;
          
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            homeTree.Visibility = Visibility.Hidden;
        }

        //Menu Customer
        private void MenuCustomer_Click(object sender, RoutedEventArgs e)
        {
            homeTree.Visibility = Visibility.Visible;
            nullStackPanels();
            //Changing Tree Headers
           
            NewTreeHeaderPart1.Header = "CustomerDetails";
            NewTreeHeaderPart2.Header = "CustomerTransactions";
            ViewTreeHeaderPart1.Header = "CustomerDetails";
            ViewTreeHeaderPart2.Header = "CustomerTransactions";
            UpdateTreeHeaderPart1.Header = "CustomerDetails";
            UpdateTreeHeaderPart2.Header = "CustomerTransactions";
            DeleteTreeHeaderPart1.Header = "CustomerDetails";
            //DeleteTreeHeaderPart2.Header = "CustomerTransactions";
        }

        //Menu Vendor
        private void MenuVendor_Click(object sender, RoutedEventArgs e)
        {
            nullStackPanels();
            homeTree.Visibility = Visibility.Visible;
            //Changing Tree Headers
          
            NewTreeHeaderPart1.Header = "VendorDetails";
            NewTreeHeaderPart2.Header = "VendorTransactions";
            ViewTreeHeaderPart1.Header = "VendorDetails";
            ViewTreeHeaderPart2.Header = "VendorTransactions";
            UpdateTreeHeaderPart1.Header = "VendorDetails";
            UpdateTreeHeaderPart2.Header = "VendorTransactions";
            DeleteTreeHeaderPart1.Header = "VendorDetails";
            //DeleteTreeHeaderPart2.Header = "VendorTransactions";
        }

        //Menu Stock
        private void MenuStock_Click(object sender, RoutedEventArgs e)
        {
            nullStackPanels();
            homeTree.Visibility = Visibility.Visible;
            //Changing Tree Headers
          
            NewTreeHeaderPart1.Header = "StockDetails";
            NewTreeHeaderPart2.Header = "StockTransactions";
            ViewTreeHeaderPart1.Header = "StockDetails";
            ViewTreeHeaderPart2.Header = "StockTransactions";
           
            UpdateTreeHeaderPart1.Header = "StockDetails";
            UpdateTreeHeaderPart2.Header = "StockTransactions";
            DeleteTreeHeaderPart1.Header = "StockDetails";
            DeleteTreeHeaderPart2.Header = "StockTransactions";
        }


        //Menu Sales
        private void MenuSales_Click(object sender, RoutedEventArgs e)
        {
            nullStackPanels();
            homeTree.Visibility = Visibility.Visible;
            //Changing Tree Headers
           
            NewTreeHeaderPart1.Header = "SalesDetails";
            NewTreeHeaderPart2.Header = "SalesTransactions";
            ViewTreeHeaderPart1.Header = "SalesDetails";
            ViewTreeHeaderPart2.Header = "SalesTransactions";
           
            UpdateTreeHeaderPart1.Header = "SalesDetails";
            UpdateTreeHeaderPart2.Header = "SalesTransactions";
            DeleteTreeHeaderPart1.Header = "SalesDetails";
            DeleteTreeHeaderPart2.Header = "SalesTransactions";
        }

        //Menu Booking
        private void MenuBooking_Click(object sender, RoutedEventArgs e)
        {
            nullStackPanels();
            homeTree.Visibility = Visibility.Visible;
            //Changing Tree Headers
           
            NewTreeHeaderPart1.Header = "BookingDetails";
            NewTreeHeaderPart2.Header = null ;
            ViewTreeHeaderPart1.Header = "BookingDetails";
            ViewTreeHeaderPart2.Header = null;
            UpdateTreeHeaderPart1.Header ="BookingDetails";
            UpdateTreeHeaderPart2.Header = null;
            DeleteTreeHeaderPart1.Header = "BookingDetails";
            DeleteTreeHeaderPart2.Header = null;
        }

        //Menu Order
        private void MenuOrder_Click(object sender, RoutedEventArgs e)
        {
            nullStackPanels();
            homeTree.Visibility = Visibility.Visible;
            //Changing Tree Headers
            
            NewTreeHeaderPart1.Header = "OrderDetails";
            NewTreeHeaderPart2.Header = null;
            ViewTreeHeaderPart1.Header = "OrderDetails";
            ViewTreeHeaderPart2.Header = null;
            UpdateTreeHeaderPart1.Header = "OrderDetails";
            UpdateTreeHeaderPart2.Header = null;
            DeleteTreeHeaderPart1.Header = "OrderDetails";
            DeleteTreeHeaderPart2.Header = null;
        }

       
        //Tree Header-New
        private void NewTreeHeader_Selected(object sender, RoutedEventArgs e)
        {
            nullStackPanels();
            if (NewTreeHeaderPart1.IsSelected == true)
            {
                if (NewTreeHeaderPart1.Header.Equals("CustomerDetails"))
                {
                    sleepMethod();
                    StackPanelNewCustomerDetails.Visibility = Visibility.Visible;
                    UserControlNewCustDetails.NewCustCode.Text = "";
                    UserControlNewCustDetails.NewCustAdd.Text = "";
                    UserControlNewCustDetails.NewCustDlNo.Text = "";
                    UserControlNewCustDetails.NewCustName.Text = "";
                    UserControlNewCustDetails.NewCustPhno1.Text = "";
                    UserControlNewCustDetails.NewCustPhno2.Text = "";
                    UserControlNewCustDetails.Status.Visibility = Visibility.Hidden;
                    UserControlNewCustDetails.ErrorStatus.Visibility = Visibility.Hidden;
                   
                    
                }

                else if (NewTreeHeaderPart1.Header.Equals("VendorDetails"))
                {
                    sleepMethod();
                    StackPanelNewVendorDetails.Visibility = Visibility.Visible;
                    UserControlNewVendorDetails.NewVendorAdd.Text = "";
                    UserControlNewVendorDetails.NewVendorCode.Text = "";
                    UserControlNewVendorDetails.NewVendorDlNo.Text = "";
                    UserControlNewVendorDetails.NewVendorName.Text = "";
                    UserControlNewVendorDetails.NewVendorPhno1.Text = "";
                    UserControlNewVendorDetails.NewVendorPhno2.Text="";
                    UserControlNewVendorDetails.ErrorStatus.Visibility = Visibility.Hidden;
                    UserControlNewVendorDetails.Status.Visibility = Visibility.Hidden;
                }

                else if (NewTreeHeaderPart1.Header.Equals("StockDetails"))
                {
                    sleepMethod();
                    StackPanelNewProductDetails.Visibility = Visibility.Visible;
                }

                else if (NewTreeHeaderPart1.Header.Equals("BookingDetails"))
                {
                    sleepMethod();
                    StackPanelNewBookingDetails.Visibility = Visibility.Visible;
                }
                else if (NewTreeHeaderPart1.Header.Equals("OrderDetails"))
                {
                    sleepMethod();
                    StackPanelNewOrderDetails.Visibility = Visibility.Visible;
                }
            }
            else
            {
                
                if (NewTreeHeaderPart2.IsSelected == true)
                {
                    if (NewTreeHeaderPart2.Header.Equals("CustomerTransactions"))
                    {
                        sleepMethod();
                        StackPanelNewCustomerTransactions.Visibility = Visibility.Visible;
                    }
                    else if (NewTreeHeaderPart2.Header.Equals("VendorTransactions"))
                    {
                        sleepMethod();
                        StackPanelNewVendorTransactions.Visibility = Visibility.Visible;
                    }

                  
                }
                else
                { }
            }
    }

        //Tree Header-View
        private void ViewTreeHeader_Selected(object sender, RoutedEventArgs e)
        {
            nullStackPanels();
            if (ViewTreeHeaderPart1.IsSelected == true)
            {
                if (ViewTreeHeaderPart1.Header.Equals("CustomerDetails"))
                {
                    sleepMethod();
                    StackPanelViewCustomerDetails.Visibility = Visibility.Visible;
                    UserControlViewCustDetails.cmbViewCustomerDetails.SelectedIndex = 0;
                    UserControlViewCustDetails.StatusViewCustomerDetails.Visibility = Visibility.Hidden;
                    UserControlViewCustDetails.cmbViewCustomerDetails.BorderBrush = new SolidColorBrush(Colors.Orange);
                    UserControlViewCustDetails.cmbViewCustomerDetails.Foreground = new SolidColorBrush(Colors.Gray);
                }

                else if (ViewTreeHeaderPart1.Header.Equals("VendorDetails"))
                {
                    sleepMethod();
                    StackPanelViewVendorDetails.Visibility = Visibility.Visible;
                    UserControlViewVendorDetails.cmbViewVendorDetails.SelectedIndex = 0;
                    UserControlViewVendorDetails.StatusViewVendorDetails.Visibility = Visibility.Hidden;
                    UserControlViewVendorDetails.cmbViewVendorDetails.BorderBrush = new SolidColorBrush(Colors.Orange);
                    UserControlViewVendorDetails.cmbViewVendorDetails.Foreground = new SolidColorBrush(Colors.Gray);
                 }

                else if (ViewTreeHeaderPart1.Header.Equals("StockDetails"))
                {
                    sleepMethod();
                    StackPanelViewProductDetails.Visibility = Visibility.Visible;
                }
                else if (ViewTreeHeaderPart1.Header.Equals("BookingDetails"))
                {
                    sleepMethod();
                    StackPanelViewBookingDetails.Visibility = Visibility.Visible;
                }
                else if (ViewTreeHeaderPart1.Header.Equals("OrderDetails"))
                {
                    sleepMethod();
                    StackPanelViewOrderDetails.Visibility = Visibility.Visible;
                }
            }
            else
            {

                if (ViewTreeHeaderPart2.IsSelected == true)
                {
                    if (ViewTreeHeaderPart2.Header.Equals("CustomerTransactions"))
                    {
                        sleepMethod();
                        StackPanelViewCustomerTransactions.Visibility = Visibility.Visible;
                    }

                    else if (ViewTreeHeaderPart2.Header.Equals("VendorTransactions"))
                    {
                        sleepMethod();
                        StackPanelViewVendorTransactions.Visibility = Visibility.Visible;
                    }

                }
                else
                { }
            }
        }

        //Tree Header-Update
        private void UpdateTreeHeader_Selected(object sender, RoutedEventArgs e)
        {
            nullStackPanels();
            if (UpdateTreeHeaderPart1.IsSelected == true)
            {
                if (UpdateTreeHeaderPart1.Header.Equals("CustomerDetails"))
                {
                    sleepMethod();
                    StackPanelUpdateCustomerDetails.Visibility = Visibility.Visible;
                    UserControlUpdateCustDetails.UpdateCustAdd.Text = "";
                    UserControlUpdateCustDetails.UpdateCustCode.Text = "";
                    UserControlUpdateCustDetails.UpdateCustDlNo.Text = "";
                    UserControlUpdateCustDetails.UpdateCustPhno1.Text = "";
                    UserControlUpdateCustDetails.UpdateCustPhno2.Text = "";
                    UserControlUpdateCustDetails.cmbUpdateCustomerDetails.SelectedIndex = 0;
                    UserControlUpdateCustDetails.Status.Visibility = Visibility.Hidden;
                    UserControlUpdateCustDetails.ErrorStatus.Visibility = Visibility.Hidden;
                    UserControlUpdateCustDetails.cmbUpdateCustomerDetails.BorderBrush = new SolidColorBrush(Colors.Orange);
                    UserControlUpdateCustDetails.cmbUpdateCustomerDetails.Foreground = new SolidColorBrush(Colors.Gray);
                }

                else if (UpdateTreeHeaderPart1.Header.Equals("VendorDetails"))
                {
                    sleepMethod();
                    StackPanelUpdateVendorDetails.Visibility = Visibility.Visible;
                    UserControlUpdateVendorDetails.UpdateVendorAdd.Text = "";
                    UserControlUpdateVendorDetails.UpdateVendorCode.Text = "";
                    UserControlUpdateVendorDetails.UpdateVendorDlNo.Text = "";
                    UserControlUpdateVendorDetails.UpdateVendorPhno1.Text = "";
                    UserControlUpdateVendorDetails.UpdateVendorPhno2.Text = "";
                    UserControlUpdateVendorDetails.cmbUpdateVendorDetails.SelectedIndex = 0;
                    UserControlUpdateVendorDetails.Status.Visibility = Visibility.Hidden;
                    UserControlUpdateVendorDetails.ErrorStatus.Visibility = Visibility.Hidden;
                    UserControlUpdateVendorDetails.cmbUpdateVendorDetails.BorderBrush = new SolidColorBrush(Colors.Orange);
                    UserControlUpdateVendorDetails.cmbUpdateVendorDetails.Foreground = new SolidColorBrush(Colors.Gray);
                }

                else if (UpdateTreeHeaderPart1.Header.Equals("StockDetails"))
                {
                    sleepMethod();
                    StackPanelUpdateProductDetails.Visibility = Visibility.Visible;
                }

            }
            else
            {

                if (UpdateTreeHeaderPart2.IsSelected == true)
                {

                    if (UpdateTreeHeaderPart2.Header.Equals("CustomerTransactions"))
                    {
                        sleepMethod();
                        StackPanelUpdateCustomerTransactions.Visibility = Visibility.Visible;
                    }

                    else if (UpdateTreeHeaderPart2.Header.Equals("VendorTransactions"))
                    {
                        sleepMethod();
                        StackPanelUpdateVendorTransactions.Visibility = Visibility.Visible;
                    }
                }
                else
                { }
            }
        }

        //Tree Header-Delete
        private void DeleteTreeHeader_Selected(object sender, RoutedEventArgs e)
        {
            nullStackPanels();
            if (DeleteTreeHeaderPart1.IsSelected == true)
            {
                if (DeleteTreeHeaderPart1.Header.Equals("CustomerDetails"))
                {
                    sleepMethod();
                    StackPanelDeleteCustomerDetails.Visibility = Visibility.Visible;
                    UserControlDeleteCustDetails.cmbDeleteCustomerDetails.SelectedIndex = 0;
                    UserControlDeleteCustDetails.StatusDeleteCustomerDetails.Visibility = Visibility.Hidden;
                    UserControlDeleteCustDetails.cmbDeleteCustomerDetails.BorderBrush = new SolidColorBrush(Colors.Orange);
                    UserControlDeleteCustDetails.cmbDeleteCustomerDetails.Foreground = new SolidColorBrush(Colors.Gray);
                }

                else if (DeleteTreeHeaderPart1.Header.Equals("VendorDetails"))
                {
                    sleepMethod();
                    StackPanelDeleteVendorDetails.Visibility = Visibility.Visible;
                    UserControlDeleteVendorDetails.cmbDeleteVendorDetails.SelectedIndex = 0;
                    UserControlDeleteVendorDetails.StatusDeleteVendorDetails.Visibility = Visibility.Hidden;
                    UserControlDeleteVendorDetails.cmbDeleteVendorDetails.BorderBrush = new SolidColorBrush(Colors.Orange);
                    UserControlDeleteVendorDetails.cmbDeleteVendorDetails.Foreground = new SolidColorBrush(Colors.Gray);
                }

                else if (DeleteTreeHeaderPart1.Header.Equals("StockDetails"))
                {
                    sleepMethod();
                    StackPanelDeleteProductDetails.Visibility = Visibility.Visible;
                }

            }
            else
            {

                if (DeleteTreeHeaderPart2.IsSelected == true)
                {
                    if (DeleteTreeHeaderPart2.Header.Equals("CustomerTransactions"))
                    {
                        sleepMethod();
                        //StackPanelDeleteCustomerTransactions.Visibility = Visibility.Visible;
                    }

                    else if (DeleteTreeHeaderPart2.Header.Equals("VendorTransactions"))
                    {
                         sleepMethod();
                        //StackPanelDeleteVendorTransactions.Visibility = Visibility.Visible;
                    }

                }
                else
                { }
            }
        }

        //NullMethod-Hide All The StackPanels
        public void nullStackPanels()
        {
            StatusProgress.Value = 20;
            //Customer And Vendor
            StackPanelNewCustomerDetails.Visibility = Visibility.Hidden;
            StackPanelNewVendorDetails.Visibility = Visibility.Hidden;
            StackPanelViewCustomerDetails.Visibility = Visibility.Hidden;
            StackPanelViewVendorDetails.Visibility = Visibility.Hidden;
            StackPanelUpdateCustomerDetails.Visibility = Visibility.Hidden;
            StackPanelUpdateVendorDetails.Visibility = Visibility.Hidden;
            StackPanelDeleteCustomerDetails.Visibility = Visibility.Hidden;
            StackPanelDeleteVendorDetails.Visibility = Visibility.Hidden;
            StackPanelNewCustomerTransactions.Visibility = Visibility.Hidden;
            StackPanelViewCustomerTransactions.Visibility = Visibility.Hidden;
            StackPanelUpdateCustomerTransactions.Visibility = Visibility.Hidden;
            StackPanelNewVendorTransactions.Visibility = Visibility.Hidden;
            StackPanelViewVendorTransactions.Visibility = Visibility.Hidden;
            StackPanelUpdateVendorTransactions.Visibility = Visibility.Hidden;
            //Product
            StackPanelNewProductDetails.Visibility = Visibility.Hidden;
            StackPanelViewProductDetails.Visibility = Visibility.Hidden;
            StackPanelUpdateProductDetails.Visibility = Visibility.Hidden;
            StackPanelDeleteProductDetails.Visibility = Visibility.Hidden;
            //Booking
            StackPanelNewBookingDetails.Visibility = Visibility.Hidden;
            StackPanelViewBookingDetails.Visibility = Visibility.Hidden;
            //Order
            StackPanelNewOrderDetails.Visibility = Visibility.Hidden;
            StackPanelViewOrderDetails.Visibility = Visibility.Hidden;
        }


      
        //SleepMethod

        public void sleepMethod()
        {
            progressDispatch.Tick += new EventHandler(dispatcher_Tick);
            progressDispatch.Interval = TimeSpan.FromMilliseconds(50);
            progressDispatch.Start();
            System.Threading.Thread.Sleep(1000);
        }

        //DispatcherTick Method.
        private void dispatcher_Tick(object sender, EventArgs e)
        {
            if (StatusProgress.Value == 100)
            {
                progressDispatch.Stop();
            }
            else
            {
                StatusProgress.Value += 10;
            }
          
        }

        private void myHyperlink_MouseEnter(object sender, MouseEventArgs e)
        {
            myHyperlink.TextDecorations = TextDecorations.Underline;
        }

        private void myHyperlink_MouseLeave(object sender, MouseEventArgs e)
        {
            myHyperlink.TextDecorations = null;
        }

        private void myHyperlink_Click(object sender, RoutedEventArgs e)
        {
            ChangePassword change = new ChangePassword();
            change.ShowDialog();
        }

        private void logOutButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        } 
       
    }
}
