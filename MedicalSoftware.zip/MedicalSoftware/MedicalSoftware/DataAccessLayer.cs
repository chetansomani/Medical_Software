﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace MedicalSoftware
{
   public  class DataAccessLayer
    {
       SqlConnection con;
       SqlCommand cmdDetails;
       SqlDataAdapter dataAdapter;
       DataTable dt;
       DataSet ds;
       int result;
       string resu;
       public DataAccessLayer()
       {

           string connstring = @"Data Source=CHETAN-PC\SQLEXPRESS;Initial Catalog=MedicalRetail;Integrated Security=True";
           con = new SqlConnection(connstring);
          
       }

       //********************Login & Register*********************//

       //Check Login Credentials
       public DataTable checkLoginDetails(string username, string passward)
       {
           dt = new DataTable();
           dataAdapter = new SqlDataAdapter("SELECT USERNAME FROM REGISTER WHERE USERNAME='" + username + "' AND PASSWARD='" + passward + "'", con);
           try
           {
               con.Open();
               dataAdapter.Fill(dt);
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return dt;
       }
       
       //Registered Data
       public int newRegisterDetails(string RegisterID, string USERNAME, string PASSWARD, string QUESTION, string ANSWER)
       {
           cmdDetails = new SqlCommand("INSERT INTO REGISTER VALUES ('" + RegisterID + "','" + USERNAME + "','" + PASSWARD + "','" + QUESTION + "','" + ANSWER + "')", con);
           try
           {
               con.Open();
               result = cmdDetails.ExecuteNonQuery();
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return result;
       }

       //AutoGenerate Register Id
       public string autoRegisterId()
       {
           string regId = "";
           int regIncrement = 100;
           cmdDetails = new SqlCommand("SELECT MAX(RegisterID) FROM  REGISTER", con);
           try
           {
               con.Open();
               regId = cmdDetails.ExecuteScalar().ToString();
               if (regId.Equals(""))
               {
                   regId = "R" + regIncrement.ToString();
               }
               else
               {
                   regIncrement = Convert.ToInt32(regId.Substring(1, 3));
                   regIncrement = regIncrement + 1;
                   regId = "R" + regIncrement.ToString();
               }
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return regId;
       }

       //Forgot Password

       public string getQuestion(string username)
       {
           cmdDetails = new SqlCommand("SELECT QUESTION FROM REGISTER WHERE USERNAME='"+username+"'", con);
           try
           {
               con.Open();
               if (cmdDetails.ExecuteScalar() == null)
               {
                   resu = "";
               }
               else
               {
                   resu = cmdDetails.ExecuteScalar().ToString();
               }
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }

           return resu;

       }

       //Validate Answer
       public int validateAns(string username, string answer)
       {
           int val=0;
           cmdDetails = new SqlCommand("SELECT COUNT(*) FROM REGISTER WHERE USERNAME='" + username + "' AND ANSWER='" + answer + "'", con);
           try
           {
               con.Open();
               val = Convert.ToInt32(cmdDetails.ExecuteScalar());
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }

           return val;

       }

       //Update New Password
       public int updateNewPassword(string username, string newPass)
       {
           cmdDetails = new SqlCommand("UPDATE REGISTER SET PASSWARD='"+newPass+"' WHERE USERNAME='"+username+"'", con);
           try
           {
               con.Open();
               result = cmdDetails.ExecuteNonQuery();
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return result;
       }

       //******************Customer***********************//

       //Populate CustomerName
       public DataTable populateCustomerName()
       {
           dt = new DataTable();
           dataAdapter = new SqlDataAdapter("SELECT CustomerCode,CustomerName FROM Customer", con);
           try
           {
               con.Open();
               dataAdapter.Fill(dt);
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return dt;
       }

       //Display VendorName
       public DataTable displayCustomerName(string custName)
       {
           dt = new DataTable();
           custName = custName + "%";
           dataAdapter = new SqlDataAdapter("SELECT CustomerCode,CustomerName FROM Customer WHERE (CustomerName LIKE '" + custName + "')", con);
           try
           {
               con.Open();
               dataAdapter.Fill(dt);
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return dt;
       }

       //Add CustomerDetails
       public int newCustomerDetails(string custCode,string custDlno,string custName,string custAddress,long custPhno1,long custPhno2)
       {
           cmdDetails = new SqlCommand("INSERT INTO Customer (CustomerCode, CustomerDlno, CustomerName, CustomerAddress, CustomerPhno1, CustomerPhno2)"+
                                       "VALUES ('"+custCode+"','"+custDlno+"','"+custName+"','"+custAddress+"','"+custPhno1+"','"+custPhno2+"')", con);
           try
           {
               con.Open();
               result = cmdDetails.ExecuteNonQuery();
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return result;
       }

       //View CustomerDetails
       public DataSet viewCustomerDetails(string custcode)
       {
           ds = new DataSet();
           dataAdapter = new SqlDataAdapter("SELECT CustomerId, CustomerCode, CustomerDlno, CustomerName, CustomerAddress, CustomerPhno1, CustomerPhno2 FROM Customer WHERE (CustomerCode = '"+custcode+"')", con);
           try
           {
               con.Open();
               dataAdapter.Fill(ds,"Customer");
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return ds;
       }

       //Update CustomerDetails
       public int updateCustomerDetails(string custCode, string custDlno, string custName, string custAddress, long custPhno1, long custPhno2)
       {
           cmdDetails = new SqlCommand("UPDATE Customer SET CustomerCode ='"+custCode+"', CustomerDlno ='"+custDlno+"', CustomerAddress ='"+custAddress+"', CustomerPhno1 ="+custPhno1+", CustomerPhno2 ="+custPhno2+" WHERE CustomerName='"+custName+"'", con);
           try
           {
               con.Open();
               result = cmdDetails.ExecuteNonQuery();
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return result;
       }

       //Delete CustomerDetails
       public int deleteCustomerDetails(string custCode)
       {
           cmdDetails = new SqlCommand("DELETE FROM Customer WHERE (CustomerCode = '"+custCode+"')", con);
           try
           {
               con.Open();
               result = cmdDetails.ExecuteNonQuery();
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return result;
       }

       //***********************************Customer Transactions******************************************//
       //New CustomerTransactions
       //public void newCustTransaction(out int value, string custcode, DateTime dateOfRecieval, double amount)
       //{

       //    cmdDetails = new SqlCommand("dbo.InsertCustomerTransaction");
       //    cmdDetails.CommandType = CommandType.StoredProcedure;
       //    cmdDetails.Connection = con;
       //    cmdDetails.Parameters.AddWithValue("@CustomerCode", custcode);
       //    cmdDetails.Parameters.AddWithValue("@ReceivedAmount", amount);
       //    cmdDetails.Parameters.AddWithValue("@DateOfReceival", dateOfRecieval.Date);
       //    SqlParameter parameter4 = new SqlParameter("@value", SqlDbType.Int);
       //    parameter4.Direction = ParameterDirection.Output;
       //    cmdDetails.Parameters.Add(parameter4);
       //    try
       //    {
       //        con.Open();
       //        value = cmdDetails.ExecuteNonQuery();
       //    }
       //    catch (SqlException exe)
       //    {
       //        value = -2;
       //        Console.Write("Exception Caught" + exe.Message);
       //    }
       //    finally
       //    {
       //        con.Close();
       //    }
          
       //}

       ////Update CustomerTransactions
       //public int updateCustomerTransaction(int transactionId, double amount)
       //{
       //    cmdDetails = new SqlCommand("UPDATE CustomerTransaction SET ReceivedAmount ="+amount+" WHERE (RTransactionId ="+transactionId+") ", con);
       //    try
       //    {
       //        con.Open();
       //        result = cmdDetails.ExecuteNonQuery();
       //    }
       //    catch (SqlException exe)
       //    {
       //        Console.Write("Exception Caught" + exe.Message);
       //    }
       //    finally
       //    {
       //        con.Close();
       //    }
       //    return result;
       //}

        //***********************************View Common Customer Transactions******************************************//
        //View Transactions 
       //public DataSet viewTransactions(int value, string custcode)
       //{
       //    ds = new DataSet();
       //    cmdDetails = new SqlCommand("SELECT * FROM dbo.CustomerTransactions(@CustomerCode,@value)");
       //    cmdDetails.Connection = con;
       //    cmdDetails.CommandType = CommandType.Text;
       //    cmdDetails.Parameters.AddWithValue("@CustomerCode", custcode);
       //    cmdDetails.Parameters.AddWithValue("@value", value);
       //    dataAdapter = new SqlDataAdapter(cmdDetails);
       //  try
       //    {
       //        con.Open();
       //        dataAdapter.Fill(ds, "Transaction");
       //    }
       //    catch (SqlException exe)
       //    {
              
       //        Console.Write("Exception Caught" + exe.Message);
       //    }
       //    finally
       //    {
       //        con.Close();
       //    }
       //  return ds;
       //}

       //******************Vendor***********************//

       //Populate VendorName
       public DataTable populateVendorName()
       {
           dt = new DataTable();
           dataAdapter = new SqlDataAdapter("SELECT VendorCode,VendorName FROM Vendor", con);
           try
           {
               con.Open();
               dataAdapter.Fill(dt);
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return dt;
       }

       //Display VendorName
       public DataTable displayVendorName(string venName)
       {
           dt = new DataTable();
           venName = venName + "%";
           dataAdapter = new SqlDataAdapter("SELECT VendorCode,VendorName FROM Vendor WHERE (VendorName LIKE '" + venName + "')", con);
           try
           {
               con.Open();
               dataAdapter.Fill(dt);
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return dt;
       }

       //Add VendorDetails
       public int newVendorDetails(string venCode, string venDlno, string venName, string venAddress, long venPhno1, long venPhno2)
       {
           cmdDetails = new SqlCommand("INSERT INTO Vendor (VendorCode, VendorDlno, VendorName, VendorAddress, VendorPhno1, VendorPhno2)" +
                                       "VALUES ('" + venCode + "','" + venDlno + "','" + venName + "','" + venAddress + "','" + venPhno1 + "','" + venPhno2 + "')", con);
           try
           {
               con.Open();
               result = cmdDetails.ExecuteNonQuery();
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return result;
       }

       //View VendorDetails
       public DataSet viewVendorDetails(string vencode)
       {
           ds = new DataSet();
           dataAdapter = new SqlDataAdapter("SELECT VendorId, VendorCode, VendorDlno, VendorName, VendorAddress, VendorPhno1, VendorPhno2 FROM Vendor WHERE (VendorCode = '" + vencode + "')", con);
           try
           {
               con.Open();
               dataAdapter.Fill(ds, "Vendor");
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return ds;
       }

       //Update VendorDetails
       public int updateVendorDetails(string venCode, string venDlno, string venName, string venAddress, long venPhno1, long venPhno2)
       {
           cmdDetails = new SqlCommand("UPDATE Vendor SET VendorCode ='" + venCode + "', VendorDlno ='" + venDlno + "', VendorAddress ='" + venAddress + "', VendorPhno1 =" + venPhno1 + ", VendorPhno2 =" + venPhno2 + " WHERE VendorName='" + venName + "'", con);
           try
           {
               con.Open();
               result = cmdDetails.ExecuteNonQuery();
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return result;
       }

       //Delete VendorDetails
       public int deleteVendorDetails(string venCode)
       {
           cmdDetails = new SqlCommand("DELETE FROM Vendor WHERE (VendorCode = '" + venCode + "')", con);
           try
           {
               con.Open();
               result = cmdDetails.ExecuteNonQuery();
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return result;
       }

       //***********************************View Common Customer Transactions******************************************//
       //View Transactions 
       //public DataSet viewVendorTransactions(int value, string custcode)
       //{
       //    ds = new DataSet();
       //    cmdDetails = new SqlCommand("SELECT * FROM dbo.VendorTransactions(@VendorCode,@value)");
       //    cmdDetails.Connection = con;
       //    cmdDetails.CommandType = CommandType.Text;
       //    cmdDetails.Parameters.AddWithValue("@VendorCode", custcode);
       //    cmdDetails.Parameters.AddWithValue("@value", value);
       //    dataAdapter = new SqlDataAdapter(cmdDetails);
       //    try
       //    {
       //        con.Open();
       //        dataAdapter.Fill(ds, "Transaction");
       //    }
       //    catch (SqlException exe)
       //    {

       //        Console.Write("Exception Caught" + exe.Message);
       //    }
       //    finally
       //    {
       //        con.Close();
       //    }
       //    return ds;
       //}


       //***********************************Vendor Transactions******************************************//
       //New VendorTransactions
       //public void newvenTransaction(out int value, string vencode, DateTime dateOfRecieval, double amount)
       //{

       //    cmdDetails = new SqlCommand("dbo.InsertVendorTransaction");
       //    cmdDetails.CommandType = CommandType.StoredProcedure;
       //    cmdDetails.Connection = con;
       //    cmdDetails.Parameters.AddWithValue("@VendorCode", vencode);
       //    cmdDetails.Parameters.AddWithValue("@PaidAmount", amount);
       //    cmdDetails.Parameters.AddWithValue("@DateOfPayment", dateOfRecieval.Date);
       //    SqlParameter parameter4 = new SqlParameter("@value", SqlDbType.Int);
       //    parameter4.Direction = ParameterDirection.Output;
       //    cmdDetails.Parameters.Add(parameter4);
       //    try
       //    {
       //        con.Open();
       //        value = cmdDetails.ExecuteNonQuery();
       //    }
       //    catch (SqlException exe)
       //    {
       //        value = -2;
       //        Console.Write("Exception Caught" + exe.Message);
       //    }
       //    finally
       //    {
       //        con.Close();
       //    }

       //}

       ////Update VendorTransactions
       //public int updateVendorTransaction(int transactionId, double amount)
       //{
       //    cmdDetails = new SqlCommand("UPDATE VendorTransaction SET PaidAmount =" + amount + " WHERE (PTransactionId =" + transactionId + ") ", con);
       //    try
       //    {
       //        con.Open();
       //        result = cmdDetails.ExecuteNonQuery();
       //    }
       //    catch (SqlException exe)
       //    {
       //        Console.Write("Exception Caught" + exe.Message);
       //    }
       //    finally
       //    {
       //        con.Close();
       //    }
       //    return result;
       //}

       //**********************************************Product Details**********************************************//

       //AutoGenerate Product Id
       public string autoProductId()
       {
           string prodId = "";
           int prodIncrement = 100;
           cmdDetails = new SqlCommand("SELECT MAX(ProductId) FROM Product", con);
           try
           {
               con.Open();
               prodId = cmdDetails.ExecuteScalar().ToString();
               if (prodId.Equals(""))
               {
                   prodId = "P" + prodIncrement.ToString();
               }
               else
               {
                   prodIncrement =Convert.ToInt32(prodId.Substring(1, 3));
                   prodIncrement = prodIncrement + 1;
                   prodId = "P" + prodIncrement.ToString();
               }
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return prodId;
       }

       //Populate ProductName
       public DataTable populateProductName()
       {
           dt = new DataTable();
           dataAdapter = new SqlDataAdapter("SELECT ProductBatchNo,ProductName FROM Product", con);
           try
           {
               con.Open();
               dataAdapter.Fill(dt);
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return dt;
       }

       //Add ProductDetails
       public int newProductDetails(string prodId,string prodBatchNo,string prodMFG,string prodName,string prodPack,long quant,DateTime prodExpiry,double prodMRP)
       {
           cmdDetails = new SqlCommand("INSERT INTO Product (ProductId, ProductBatchNo, ProductMFG, ProductName, ProductPack, ProductQuantity, ProductExpiry, ProductMRP)"+
                                        "VALUES ('"+prodId+"','"+prodBatchNo+"','"+prodMFG+"','"+prodName+"','"+prodPack+"',"+quant+",'"+prodExpiry.Date+"',"+prodMRP+")", con);
           try
           {
               con.Open();
               result = cmdDetails.ExecuteNonQuery();
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return result;
       }

       //View ProductDetails
       public DataSet viewProductDetails(string Productdata,int count)
       {
           ds = new DataSet();
           Productdata = Productdata + "%";
           if (count == 0)
           {
               dataAdapter = new SqlDataAdapter("SELECT Product.* FROM Product WHERE (ProductBatchNo LIKE '" + Productdata + "')", con);
           }
           else
           {
               dataAdapter = new SqlDataAdapter("SELECT Product.* FROM Product WHERE (ProductName LIKE '" + Productdata + "')", con);
           }
       
           try
           {
               con.Open();
               dataAdapter.Fill(ds, "ProductTable");
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return ds;
       }

       //Update ProductDetails
       public int updateProductDetails(string prodId, string prodBatchNo, string prodMFG, string prodName, string prodPack, long quant, DateTime prodExpiry, double prodMRP)
       {
           cmdDetails = new SqlCommand("UPDATE Product SET ProductMFG ='"+prodMFG+"', ProductName ='"+prodName+"', ProductPack ='"+prodPack+"', ProductQuantity ="+quant+", ProductExpiry ='"+prodExpiry.Date+"', ProductMRP ="+prodMRP+" WHERE ProductId='"+prodId+"'", con);
           try
           {
               con.Open();
               result = cmdDetails.ExecuteNonQuery();
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return result;
       }

       //Delete ProductDetails
       public int deleteProductDetails(string productBatchNo)
       {
           cmdDetails = new SqlCommand("DELETE FROM Product WHERE (ProductBatchNo = '" + productBatchNo + "')", con);
           try
           {
               con.Open();
               result = cmdDetails.ExecuteNonQuery();
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return result;
       }

       /***************************************************Booking***************************************************/
       public string autoBookingId()
       {
           string bookId = "";
           int bookIncrement = 100;
           cmdDetails = new SqlCommand("SELECT MAX(BookingId) FROM Booking", con);
           try
           {
               con.Open();
               bookId = cmdDetails.ExecuteScalar().ToString();
               if (bookId.Equals(""))
               {
                   bookId = "B" + bookIncrement.ToString();
               }
               else
               {
                   bookIncrement = Convert.ToInt32(bookId.Substring(1, 3));
                   bookIncrement = bookIncrement + 1;
                   bookId = "B" + bookIncrement.ToString();
               }
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return bookId;
       
       }

       /****************************Insert Booking Details***********************************************************/
       public int insertBookingDetails(string bookId,string venName,string prodName,int carBooked,long quantBooked,DateTime dateOfBooking,string statusOfBooking)
       {
           cmdDetails = new SqlCommand("INSERT INTO Booking VALUES('"+bookId+"','"+venName+"','"+prodName+"',"+carBooked+","+quantBooked+",'"+dateOfBooking.Date+"','"+statusOfBooking+"')",con);
           try
           {
               con.Open();
               result = cmdDetails.ExecuteNonQuery();
           }
           catch (SqlException exe)
           {
               Console.Write("Exception Caught" + exe.Message);
           }
           finally
           {
               con.Close();
           }
           return result;

       }

       /************View Booking Details****************/
       
        public DataSet viewBookingDetails(int count,string status,string vendor,string date,string product)
        {
            ds = new DataSet();
            cmdDetails = new SqlCommand("SELECT * FROM  viewBookingDetails(@Count,@Status,@Vendor,@Date,@Product)");
            cmdDetails.Connection = con;
            cmdDetails.CommandType = CommandType.Text;
            cmdDetails.Parameters.AddWithValue("@Count", count);
            cmdDetails.Parameters.AddWithValue("@Status", status);
            cmdDetails.Parameters.AddWithValue("@Vendor", vendor);
            cmdDetails.Parameters.AddWithValue("@Date", date);
            cmdDetails.Parameters.AddWithValue("@Product", product);
            dataAdapter = new SqlDataAdapter(cmdDetails);
            try
            {
                con.Open();
                dataAdapter.Fill(ds, "Booking");
            }
            catch (SqlException exe)
            {

                Console.Write("Exception Caught" + exe.Message);
            }
            finally
            {
                con.Close();
            }
            return ds;
        }
    }
}
