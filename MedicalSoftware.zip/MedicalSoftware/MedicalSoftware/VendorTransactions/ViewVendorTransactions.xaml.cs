﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for ViewVendorTransactions.xaml
    /// </summary>
    public partial class ViewVendorTransactions : UserControl
    {
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        DataTable dt;
        //DataSet ds;
        int count;

        public ViewVendorTransactions()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            nullMethod();
            populateComboBox();
        }

        private void hypercheck1_Checked(object sender, RoutedEventArgs e)
        {
            count = 1;
            hypercheck2.IsChecked = false;
            hypercheck4.IsChecked = false;
            hypercheck3.IsChecked = false;
            hyperchecklabel1.BorderBrush = new SolidColorBrush(Colors.Orange);
            hyperchecklabel1.Foreground = new SolidColorBrush(Colors.Orange);
            hyperchecklabel2.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel2.BorderBrush = new SolidColorBrush(Colors.White);
            cmbViewVendorTran.Visibility = Visibility.Visible;
            textVendorName.Visibility = Visibility.Visible;
        }

        private void hypercheck1_Unchecked(object sender, RoutedEventArgs e)
        {
            hyperchecklabel1.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel1.BorderBrush = new SolidColorBrush(Colors.White);
            cmbViewVendorTran.Visibility = Visibility.Hidden;
            StatusViewVendorTran.Visibility = Visibility.Hidden;
            ViewVendorTranList.Visibility = Visibility.Hidden;
            textVendorName.Visibility = Visibility.Hidden;
            hypercheck3.Visibility = Visibility.Hidden;
            hypercheck4.Visibility = Visibility.Hidden;
            cmbViewVendorTran.SelectedIndex = 0;
            cmbViewVendorTran.BorderBrush = new SolidColorBrush(Colors.Orange);
            cmbViewVendorTran.Foreground = new SolidColorBrush(Colors.Gray);
        }

        private void hypercheck2_Unchecked(object sender, RoutedEventArgs e)
        {
            hyperchecklabel2.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel2.BorderBrush = new SolidColorBrush(Colors.White);
            cmbViewVendorTran.Visibility = Visibility.Hidden;
            StatusViewVendorTran.Visibility = Visibility.Hidden;
            ViewVendorTranList.Visibility = Visibility.Hidden;
            textVendorName.Visibility = Visibility.Hidden;
            hypercheck3.Visibility = Visibility.Hidden;
            hypercheck4.Visibility = Visibility.Hidden;
            cmbViewVendorTran.SelectedIndex = 0;
            cmbViewVendorTran.BorderBrush = new SolidColorBrush(Colors.Orange);
            cmbViewVendorTran.Foreground = new SolidColorBrush(Colors.Gray);
        }

        private void hypercheck2_Checked(object sender, RoutedEventArgs e)
        {
            count = 2;
            hypercheck1.IsChecked = false;
            hypercheck4.IsChecked = false;
            hypercheck3.IsChecked = false;
            hyperchecklabel2.BorderBrush = new SolidColorBrush(Colors.Orange);
            hyperchecklabel2.Foreground = new SolidColorBrush(Colors.Orange);
            hyperchecklabel1.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel1.BorderBrush = new SolidColorBrush(Colors.White);
            cmbViewVendorTran.Visibility = Visibility.Visible;
            textVendorName.Visibility = Visibility.Visible;
        }

        private void hypercheck3_Checked(object sender, RoutedEventArgs e)
        {
            hypercheck4.IsChecked = false;
            hyperchecklabel3.BorderBrush = new SolidColorBrush(Colors.Orange);
            hyperchecklabel3.Foreground = new SolidColorBrush(Colors.Orange);
            hyperchecklabel4.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel4.BorderBrush = new SolidColorBrush(Colors.White);
           // int value;
            if (count == 1)
            {
               // value = 1;
                //ds = businessLayer.viewTransactions(value, cmbViewVendorTran.SelectedValue.ToString());
                //if (ds.Tables["Transaction"].Rows.Count == 0)
                //{
                //    StatusViewVendorTran.Foreground = new SolidColorBrush(Colors.Red);
                //    StatusViewVendorTran.Text = "No Paid Transaction Records Found For The Customer" + " " + cmbViewVendorTran.Text;
                //    StatusViewVendorTran.Visibility = Visibility.Visible;
                //}
                //else
                //{
                //    ViewVendorTranList.DataContext = ds;
                //    ViewVendorTranList.Visibility = Visibility.Visible;
                //    StatusViewVendorTran.Visibility = Visibility.Hidden;
                //}
            }
            else if (count == 2)
            {
                //value = 3;
                //ds = businessLayer.viewTransactions(value, cmbViewVendorTran.SelectedValue.ToString());
                //if (ds.Tables["Transaction"].Rows.Count == 0)
                //{
                //    StatusViewVendorTran.Foreground = new SolidColorBrush(Colors.Red);
                //    StatusViewVendorTran.Text = "No Paid Transaction Records Found For The Customer" + " " + cmbViewVendorTran.Text;
                //    StatusViewVendorTran.Visibility = Visibility.Visible;
                //}
                //else
                //{
                //    ViewVendorTranList.DataContext = ds;
                //    ViewVendorTranList.Visibility = Visibility.Visible;
                //    StatusViewVendorTran.Visibility = Visibility.Hidden;
                //}
            }
        }

        private void hypercheck3_Unchecked(object sender, RoutedEventArgs e)
        {
            hyperchecklabel3.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel3.BorderBrush = new SolidColorBrush(Colors.White);
            StatusViewVendorTran.Visibility = Visibility.Hidden;
            ViewVendorTranList.Visibility = Visibility.Hidden;
        }

        private void hypercheck4_Unchecked(object sender, RoutedEventArgs e)
        {
            hyperchecklabel4.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel4.BorderBrush = new SolidColorBrush(Colors.White);
            StatusViewVendorTran.Visibility = Visibility.Hidden;
            ViewVendorTranList.Visibility = Visibility.Hidden;
        }

        private void hypercheck4_Checked(object sender, RoutedEventArgs e)
        {
            hypercheck3.IsChecked = false;
            hyperchecklabel4.BorderBrush = new SolidColorBrush(Colors.Orange);
            hyperchecklabel4.Foreground = new SolidColorBrush(Colors.Orange);
            hyperchecklabel3.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel3.BorderBrush = new SolidColorBrush(Colors.White);
           // int value;
            if (count == 1)
            {
               // value = 2;
                //ds = businessLayer.viewTransactions(value, cmbViewVendorTran.SelectedValue.ToString());
                //if (ds.Tables["Transaction"].Rows.Count == 0)
                //{
                //    StatusViewVendorTran.Foreground = new SolidColorBrush(Colors.Red);
                //    StatusViewVendorTran.Text = "No Purchased Transaction Records Found For The Customer" + " " + cmbViewVendorTran.Text;
                //    StatusViewVendorTran.Visibility = Visibility.Visible;
                //}
                //else
                //{
                //    ViewVendorTranList.DataContext = ds;
                //    ViewVendorTranList.Visibility = Visibility.Visible;
                //    StatusViewVendorTran.Visibility = Visibility.Hidden;
                //}
            }
            else if (count == 2)
            {
               // value = 4;
                //ds = businessLayer.viewTransactions(value, cmbViewVendorTran.SelectedValue.ToString());
                //if (ds.Tables["Transaction"].Rows.Count == 0)
                //{
                //    StatusViewVendorTran.Foreground = new SolidColorBrush(Colors.Red);
                //    StatusViewVendorTran.Text = "No Purchased Transaction Records Found For The Customer" + " " + cmbViewVendorTran.Text;
                //    StatusViewVendorTran.Visibility = Visibility.Visible;
                //}
                //else
                //{
                //    ViewVendorTranList.DataContext = ds;
                //    ViewVendorTranList.Visibility = Visibility.Visible;
                //    StatusViewVendorTran.Visibility = Visibility.Hidden;

                //}
            }
        }

        private void cmbViewVendorTran_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            StatusViewVendorTran.Visibility = Visibility.Hidden;
            if (cmbViewVendorTran.SelectedIndex == 0)
            {
                cmbViewVendorTran.BorderBrush = new SolidColorBrush(Colors.Orange);
                cmbViewVendorTran.Foreground = new SolidColorBrush(Colors.Gray);
                hypercheck3.Visibility = Visibility.Hidden;
                hypercheck4.Visibility = Visibility.Hidden;
            }
            else
            {
                hypercheck3.Visibility = Visibility.Visible;
                hypercheck4.Visibility = Visibility.Visible;
                cmbViewVendorTran.BorderBrush = new SolidColorBrush(Colors.Gray);
                cmbViewVendorTran.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        public void populateComboBox()
        {
            dt = new DataTable();
            dt = businessLayer.populateVendorName();
            dt.TableName = "PopulateVendor";
            DataRow dr = dt.NewRow();
            dr["VendorName"] = "--Select--";
            dr["VendorCode"] = "null";
            dt.Rows.InsertAt(dr, 0);
            cmbViewVendorTran.DataContext = dt;
            cmbViewVendorTran.DisplayMemberPath = dt.Columns["VendorName"].ToString();
            cmbViewVendorTran.SelectedValuePath = dt.Columns["VendorCode"].ToString();
        }

        private void nullMethod()
        {
            hypercheck1.IsChecked = false;
            hypercheck2.IsChecked = false;
            hypercheck3.IsChecked = false;
            hypercheck4.IsChecked = false;
            hyperchecklabel1.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel1.BorderBrush = new SolidColorBrush(Colors.White);
            hyperchecklabel2.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel2.BorderBrush = new SolidColorBrush(Colors.White);
            hyperchecklabel3.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel3.BorderBrush = new SolidColorBrush(Colors.White);
            hyperchecklabel4.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel4.BorderBrush = new SolidColorBrush(Colors.White);
            cmbViewVendorTran.Visibility = Visibility.Hidden;
            StatusViewVendorTran.Visibility = Visibility.Hidden;
            ViewVendorTranList.Visibility = Visibility.Hidden;
            textVendorName.Visibility = Visibility.Hidden;
            hypercheck3.Visibility = Visibility.Hidden;
            hypercheck4.Visibility = Visibility.Hidden;
            cmbViewVendorTran.SelectedIndex = 0;
            cmbViewVendorTran.BorderBrush = new SolidColorBrush(Colors.Orange);
            cmbViewVendorTran.Foreground = new SolidColorBrush(Colors.Gray);

        }
    }
}
