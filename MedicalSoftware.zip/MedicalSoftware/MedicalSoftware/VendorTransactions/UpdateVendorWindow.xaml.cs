﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalSoftware.VendorTransactions
{
    /// <summary>
    /// Interaction logic for UpdateVendorWindow.xaml
    /// </summary>
    public partial class UpdateVendorWindow : Window
    {
        private string vendorName;

        public string VendorName
        {
            get { return vendorName; }
            set { vendorName = value; }
        }
        private string dateOfPayment;

        public string DateOfPayment
        {
            get { return dateOfPayment; }
            set { dateOfPayment = value; }
        }
        private string amount;

        public string Amount
        {
            get { return amount; }
            set { amount = value; }
        }
        private int count;

        public int Count
        {
            get { return count; }
            set { count = value; }
        }

        public UpdateVendorWindow()
        {
            InitializeComponent();
        }

        public UpdateVendorWindow(string Venname, string date, string amount)
        {
            InitializeComponent();
            VendorName = Venname;
            Amount = amount;
            DateOfPayment = date;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            status.Visibility = Visibility.Hidden;
            txtVendor.Text = VendorName;
            txtDateOfPayment.Text = DateOfPayment;
            txtUpdateAmount.Text = Amount;
        }

        private void txtUpdateAmount_TextChanged(object sender, TextChangedEventArgs e)
        {
            status.Visibility = Visibility.Hidden;
            if (txtUpdateAmount.Text == null)
            {
                txtUpdateAmount.Foreground = new SolidColorBrush(Colors.Gray);
                txtUpdateAmount.BorderBrush = new SolidColorBrush(Colors.Orange);
            }
            else
            {
                txtUpdateAmount.Foreground = new SolidColorBrush(Colors.Orange);
                txtUpdateAmount.BorderBrush = new SolidColorBrush(Colors.Gray);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (txtUpdateAmount.Text == null)
            {
                status.Text = "Enter The Amount to be Updated";
                status.Foreground = new SolidColorBrush(Colors.Red);
                status.Visibility = Visibility.Visible;
            }
            else
            {
                status.Visibility = Visibility.Hidden;
                Count = 1;
                Amount = txtUpdateAmount.Text;
                this.Close();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            status.Visibility = Visibility.Hidden;
            Count = -1;
            this.Close();
        }

       
    }
}
