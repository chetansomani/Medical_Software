﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using MedicalSoftware.VendorTransactions;

namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for UpdateVendorTransactions.xaml
    /// </summary>
    public partial class UpdateVendorTransactions : UserControl
    {
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        DataTable dt;
       // DataSet ds;
        string amount;
        int i;

        public UpdateVendorTransactions()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            populateComboBox();
        }

        private void cmbUpdateVendorTran_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            StatusUpdateVendorTran.Visibility = Visibility.Hidden;
            UpdateVendorTranList.Visibility = Visibility.Hidden;
            if (cmbUpdateVendorTran.SelectedIndex == 0)
            {
                cmbUpdateVendorTran.BorderBrush = new SolidColorBrush(Colors.Orange);
                cmbUpdateVendorTran.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                cmbUpdateVendorTran.BorderBrush = new SolidColorBrush(Colors.Gray);
                cmbUpdateVendorTran.Foreground = new SolidColorBrush(Colors.Orange);
            }

        }

        private void btnUpdateVendorTran_Click(object sender, RoutedEventArgs e)
        {
            Thickness marginText = StatusUpdateVendorTran.Margin;
            if (cmbUpdateVendorTran.SelectedIndex == 0)
            {
                cmbUpdateVendorTran.BorderBrush = new SolidColorBrush(Colors.Red);
                StatusUpdateVendorTran.Margin = new Thickness(200, 0, 0, 0);
                StatusUpdateVendorTran.Text = "Select A Vendor Name In Order To Update" + "\n" + "Its Paid Transactions";
                StatusUpdateVendorTran.Foreground = new SolidColorBrush(Colors.Red);
                StatusUpdateVendorTran.Visibility = Visibility.Visible;
                UpdateVendorTranList.Visibility = Visibility.Hidden;
            }
            else
            {
                //ds = businessLayer.viewTransactions(1, cmbUpdateVendorTran.SelectedValue.ToString());
                //if (ds.Tables["Transaction"].Rows.Count == 0)
                //{
                //    StatusUpdateVendorTran.Foreground = new SolidColorBrush(Colors.Red);
                //    StatusUpdateVendorTran.Margin = new Thickness(200, 0, 0, 0);
                //    StatusUpdateVendorTran.Text = "No Records Found";
                //    StatusUpdateVendorTran.Visibility = Visibility.Visible;
                //}
                //else
                //{

                //    UpdateVendorTranList.DataContext = ds;
                //    StatusUpdateVendorTran.Visibility = Visibility.Hidden;
                //    UpdateVendorTranList.Visibility = Visibility.Visible;
                //}

            }
        }

        private void btnResetUpdateVendorTran_Click(object sender, RoutedEventArgs e)
        {
            cmbUpdateVendorTran.SelectedIndex = 0;
            StatusUpdateVendorTran.Visibility = Visibility.Hidden;
            UpdateVendorTranList.Visibility = Visibility.Hidden;
        }

        private void UpdateVendorTranList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            btnFinalUpdateTran.Visibility = Visibility.Hidden;
            StatusUpdateVendorTran.Visibility = Visibility.Hidden;
            i = UpdateVendorTranList.SelectedIndex;
            if (i >= 0)
            {

                //Way To Get Value FRom DataGrid IN WPF
                string VendorName = (UpdateVendorTranList.SelectedItem as DataRowView).Row["VendorName"].ToString();
                string dateOfReceival = (UpdateVendorTranList.SelectedItem as DataRowView).Row["DateOfTransaction"].ToString();
                amount = (UpdateVendorTranList.SelectedItem as DataRowView).Row["Amount"].ToString();
                UpdateVendorWindow window = new UpdateVendorWindow(VendorName, dateOfReceival, amount);
                window.ShowDialog();
                if (window.Count == 1)
                {
                    (UpdateVendorTranList.SelectedItem as DataRowView).Row["Amount"] = window.Amount;
                    btnFinalUpdateTran.Visibility = Visibility.Visible;
                }
                else
                {
                    //(UpdateVendorTranList.SelectedItem as DataRowView).Row["Amount"] = amount;

                    //btnFinalUpdateTran.Visibility = Visibility.Hidden;

                }

            }
            else
            {
            }
        }


        public void populateComboBox()
        {
            dt = new DataTable();
            dt = businessLayer.populateVendorName();
            dt.TableName = "PopulateVendor";
            DataRow dr = dt.NewRow();
            dr["VendorName"] = "--Select--";
            dr["VendorCode"] = "null";
            dt.Rows.InsertAt(dr, 0);
            cmbUpdateVendorTran.DataContext = dt;
            cmbUpdateVendorTran.DisplayMemberPath = dt.Columns["VendorName"].ToString();
            cmbUpdateVendorTran.SelectedValuePath = dt.Columns["VendorCode"].ToString();
        }

        private void btnFinalUpdateTran_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Do you Want To Update This Record?", "Update Confirmation", MessageBoxButton.YesNo);
            string resString = result.ToString();
            if (resString.Equals("Yes"))
            {
                string val = (UpdateVendorTranList.SelectedItem as DataRowView).Row["Amount"].ToString();
                string transctionId = (UpdateVendorTranList.SelectedItem as DataRowView).Row["TransactionId"].ToString();
                //int dataResult = businessLayer.updateVendorTransaction(Convert.ToInt32(transctionId), Convert.ToDouble(val));
                //if (dataResult > 0)
                //{
                //    ds.Tables["Transaction"].Rows[i]["Amount"] = Convert.ToDouble(val);
                //    StatusUpdateVendorTran.Text = "Update The TransactionDetails Of Vendor" + " " + (UpdateVendorTranList.SelectedItem as DataRowView).Row["VendorName"].ToString() + " " +
                //                                "of Date " + " " + (UpdateVendorTranList.SelectedItem as DataRowView).Row["DateOfTransaction"].ToString() + " " + "Successfully";
                //    StatusUpdateVendorTran.Visibility = Visibility.Visible;
                //}
                //else
                //{
                //    StatusUpdateVendorTran.Text = "Error In Updating The TransactionDetails Of Vendor" + " " + (UpdateVendorTranList.SelectedItem as DataRowView).Row["VendorName"].ToString() + " " +
                //                                "of Date " + " " + (UpdateVendorTranList.SelectedItem as DataRowView).Row["DateOfTransaction"].ToString() + " ";
                //    StatusUpdateVendorTran.Visibility = Visibility.Visible;
                //}
            }
            else
            {
                btnFinalUpdateTran.Visibility = Visibility.Hidden;
                (UpdateVendorTranList.SelectedItem as DataRowView).Row["Amount"] = amount;
            }
        }
    }
}
