﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for AddVendorTransactions.xaml
    /// </summary>
    public partial class AddVendorTransactions : UserControl
    {
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        DataTable dt;

        public AddVendorTransactions()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            populateComboBox();
        }

        private void cmbNewVendorTran_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ErrorTranStatus.Visibility = Visibility.Hidden;
            StatusTran.Visibility = Visibility.Hidden;
            if (cmbNewVendorTran.SelectedIndex == 0)
            {
                cmbNewVendorTran.BorderBrush = new SolidColorBrush(Colors.Orange);
                cmbNewVendorTran.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                cmbNewVendorTran.BorderBrush = new SolidColorBrush(Colors.Gray);
                cmbNewVendorTran.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void dtpNewVendorTran_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            ErrorTranStatus.Visibility = Visibility.Hidden;
            StatusTran.Visibility = Visibility.Hidden;
            if (dtpNewVendorTran.SelectedDate.Equals(null))
            {
                dtpNewVendorTran.BorderBrush = new SolidColorBrush(Colors.Orange);
                dtpNewVendorTran.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                dtpNewVendorTran.BorderBrush = new SolidColorBrush(Colors.Gray);
                dtpNewVendorTran.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void NewAmountTran_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorTranStatus.Visibility = Visibility.Hidden;
            StatusTran.Visibility = Visibility.Hidden;
            if (NewAmountTran.Text.Equals(""))
            {
                NewAmountTran.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewAmountTran.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewAmountTran.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewAmountTran.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void btnAddNewVendorTran_Click(object sender, RoutedEventArgs e)
        {
            Thickness marginText = ErrorTranStatus.Margin;
            ErrorTranStatus.Height = 20;
            ErrorTranStatus.Width = 200;
            StatusTran.Visibility = Visibility.Hidden;
            if (cmbNewVendorTran.SelectedIndex == 0)
            {
                cmbNewVendorTran.BorderBrush = new SolidColorBrush(Colors.Red);
                ErrorTranStatus.Margin = new Thickness(40.0, -194.0, 0.0, 0.0);
                ErrorTranStatus.Text = "Select A Vendor Name";
                ErrorTranStatus.Visibility = Visibility.Visible;

            }
            else
            {
                if (dtpNewVendorTran.SelectedDate.Equals(null))
                {
                    dtpNewVendorTran.BorderBrush = new SolidColorBrush(Colors.Red);
                    ErrorTranStatus.Margin = new Thickness(40.0, -80.0, 0.0, 0.0);
                    ErrorTranStatus.Text = "Select A Valid Date";
                    ErrorTranStatus.Visibility = Visibility.Visible;

                }
                else
                {
                    if (NewAmountTran.Text.Equals(""))
                    {
                        NewAmountTran.BorderBrush = new SolidColorBrush(Colors.Red);
                        ErrorTranStatus.Margin = new Thickness(40.0, 40.0, 0.0, 0.0);
                        ErrorTranStatus.Text = "Enter The AmountPaid";
                        ErrorTranStatus.Visibility = Visibility.Visible;
                        NewAmountTran.Focus();
                    }
                    else
                    {
                        //int value;
                        ////businessLayer.newvenTransaction(out value, cmbNewVendorTran.SelectedValue.ToString(), dtpNewVendorTran.SelectedDate.Value.Date, Convert.ToDouble(NewAmountTran.Text.ToString()));
                        //if (value == -1)
                        //{
                        //    StatusTran.Text = "No Purchase Record From Particular Vendor" + " " + cmbNewVendorTran.Text + "\n"
                        //                         + "Please Add Purchase Record First";
                        //    StatusTran.Visibility = Visibility.Visible;
                        //}
                        //else
                        //{
                        //    StatusTran.Foreground = new SolidColorBrush(Colors.Gray);
                        //    StatusTran.Text = "Transactions Updated Successfully";
                        //    StatusTran.Visibility = Visibility.Visible;
                        //}
                    }
                }


            }
        }

        private void btnResetNewVendorTran_Click(object sender, RoutedEventArgs e)
        {
            nullNewVendorDetails();
        }

        //NullMethod-Vendoromer Details.
        public void nullNewVendorDetails()
        {
            cmbNewVendorTran.SelectedIndex = 0;
            dtpNewVendorTran.SelectedDate = null;
            NewAmountTran.Text = null;
            ErrorTranStatus.Visibility = Visibility.Hidden;
            StatusTran.Visibility = Visibility.Hidden;
            cmbNewVendorTran.BorderBrush = new SolidColorBrush(Colors.Orange);
            cmbNewVendorTran.Foreground = new SolidColorBrush(Colors.Gray);
            dtpNewVendorTran.BorderBrush = new SolidColorBrush(Colors.Orange);
            dtpNewVendorTran.Foreground = new SolidColorBrush(Colors.Gray);
            NewAmountTran.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewAmountTran.Foreground = new SolidColorBrush(Colors.Gray);
        }

        public void populateComboBox()
        {
            dt = new DataTable();
            dt = businessLayer.populateVendorName();
            dt.TableName = "PopulateVendor";
            DataRow dr = dt.NewRow();
            dr["VendorName"] = "--Select--";
            dr["VendorCode"] = "null";
            dt.Rows.InsertAt(dr, 0);
            cmbNewVendorTran.DataContext = dt;
            cmbNewVendorTran.DisplayMemberPath = dt.Columns["VendorName"].ToString();
            cmbNewVendorTran.SelectedValuePath = dt.Columns["VendorCode"].ToString();
        }
    }
}
