﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using MedicalSoftware.CustomerTransactions;

namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for UpdateCustomerTransactions.xaml
    /// </summary>
    public partial class UpdateCustomerTransactions : UserControl
    {
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        DataTable dt;
      //  DataSet ds;
        string amount;
        int i;
        public UpdateCustomerTransactions()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            populateComboBox();
        }

        private void cmbUpdateCustTran_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            StatusUpdateCustTran.Visibility = Visibility.Hidden;
            UpdateCustTranList.Visibility = Visibility.Hidden;
            if (cmbUpdateCustTran.SelectedIndex == 0)
            {
                cmbUpdateCustTran.BorderBrush = new SolidColorBrush(Colors.Orange);
                cmbUpdateCustTran.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                cmbUpdateCustTran.BorderBrush = new SolidColorBrush(Colors.Gray);
                cmbUpdateCustTran.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void btnUpdateCustomerTran_Click(object sender, RoutedEventArgs e)
        {
            Thickness marginText = StatusUpdateCustTran.Margin;
            if (cmbUpdateCustTran.SelectedIndex == 0)
            {
                cmbUpdateCustTran.BorderBrush = new SolidColorBrush(Colors.Red);
                StatusUpdateCustTran.Margin = new Thickness(200, 0, 0, 0);
                StatusUpdateCustTran.Text = "Select A Customer Name In Order To Update" +"\n"+"Its Received Transactions";
                StatusUpdateCustTran.Foreground = new SolidColorBrush(Colors.Red);
                StatusUpdateCustTran.Visibility = Visibility.Visible;
                UpdateCustTranList.Visibility = Visibility.Hidden;
            }
            else
            {
                //ds = businessLayer.viewTransactions(1, cmbUpdateCustTran.SelectedValue.ToString());
                //if (ds.Tables["Transaction"].Rows.Count == 0)
                //{
                //    StatusUpdateCustTran.Foreground = new SolidColorBrush(Colors.Red);
                //    StatusUpdateCustTran.Margin = new Thickness(200, 0, 0, 0);
                //    StatusUpdateCustTran.Text = "No Records Found";
                //    StatusUpdateCustTran.Visibility = Visibility.Visible;
                //}
                //else
                //{
                    
                //    UpdateCustTranList.DataContext = ds;
                //    StatusUpdateCustTran.Visibility = Visibility.Hidden;
                //    UpdateCustTranList.Visibility = Visibility.Visible;
                //}

            }
        }

        private void btnResetUpdateCustomerTran_Click(object sender, RoutedEventArgs e)
        {
            cmbUpdateCustTran.SelectedIndex = 0;
            StatusUpdateCustTran.Visibility = Visibility.Hidden;
            UpdateCustTranList.Visibility = Visibility.Hidden;
        }

        public void populateComboBox()
        {
            dt = new DataTable();
            dt = businessLayer.populateCustomerName();
            dt.TableName = "PopulateCustomer";
            DataRow dr = dt.NewRow();
            dr["CustomerName"] = "--Select--";
            dr["CustomerCode"] = "null";
            dt.Rows.InsertAt(dr, 0);
            cmbUpdateCustTran.DataContext = dt;
            cmbUpdateCustTran.DisplayMemberPath = dt.Columns["CustomerName"].ToString();
            cmbUpdateCustTran.SelectedValuePath = dt.Columns["CustomerCode"].ToString();
        }

        private void UpdateCustTranList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            btnFinalUpdateTran.Visibility = Visibility.Hidden;
            StatusUpdateCustTran.Visibility = Visibility.Hidden;
            i = UpdateCustTranList.SelectedIndex;
            if (i >= 0)
            {
               
               //Way To Get Value FRom DataGrid IN WPF
                string custName = (UpdateCustTranList.SelectedItem as DataRowView).Row["CustomerName"].ToString();
                string dateOfReceival = (UpdateCustTranList.SelectedItem as DataRowView).Row["DateOfTransaction"].ToString();
                amount= (UpdateCustTranList.SelectedItem as DataRowView).Row["Amount"].ToString();
                UpdateWindow window = new UpdateWindow(custName, dateOfReceival, amount);
                window.ShowDialog();
                if (window.Count == 1)
                {
                    (UpdateCustTranList.SelectedItem as DataRowView).Row["Amount"] = window.Amount;
                    btnFinalUpdateTran.Visibility = Visibility.Visible;
                }
                else
                {
                    //(UpdateCustTranList.SelectedItem as DataRowView).Row["Amount"] = amount;

                    //btnFinalUpdateTran.Visibility = Visibility.Hidden;
                 
                }
               
            }
            else
            {
            }
        }

        private void btnFinalUpdateTran_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Do you Want To Update This Record?", "Update Confirmation", MessageBoxButton.YesNo);
            string resString = result.ToString();
            if (resString.Equals("Yes"))
            {
                string val = (UpdateCustTranList.SelectedItem as DataRowView).Row["Amount"].ToString();
                string transctionId = (UpdateCustTranList.SelectedItem as DataRowView).Row["TransactionId"].ToString();
                //int dataResult = businessLayer.updateCustomerTransaction(Convert.ToInt32(transctionId), Convert.ToDouble(val));
                //if (dataResult > 0)
                //{
                //    ds.Tables["Transaction"].Rows[i]["Amount"] = Convert.ToDouble(val);
                //    StatusUpdateCustTran.Text = "Update The TransactionDetails Of Customer" + " " + (UpdateCustTranList.SelectedItem as DataRowView).Row["CustomerName"].ToString() + " " +
                //                                "of Date " +" "+ (UpdateCustTranList.SelectedItem as DataRowView).Row["DateOfTransaction"].ToString() + " " + "Successfully";
                //    StatusUpdateCustTran.Visibility = Visibility.Visible;
                //}
                //else
                //{
                //    StatusUpdateCustTran.Text = "Error In Updating The TransactionDetails Of Customer" + " " + (UpdateCustTranList.SelectedItem as DataRowView).Row["CustomerName"].ToString() + " " +
                //                                "of Date " + " " + (UpdateCustTranList.SelectedItem as DataRowView).Row["DateOfTransaction"].ToString() + " ";
                //    StatusUpdateCustTran.Visibility = Visibility.Visible;
                //}
            }
            else
            {
                btnFinalUpdateTran.Visibility = Visibility.Hidden;
                (UpdateCustTranList.SelectedItem as DataRowView).Row["Amount"] = amount;
            }
        }


       
       
       

    }
}
