﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for ViewCustomerTransactions.xaml
    /// </summary>
    public partial class ViewCustomerTransactions : UserControl
    {
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        DataTable dt;
        //DataSet ds;
        int count;

        public ViewCustomerTransactions()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            populateComboBox();
            hypercheck1.IsChecked = false;
            hypercheck2.IsChecked = false;
            hypercheck3.IsChecked = false;
            hypercheck4.IsChecked = false;
            cmbViewCustTran.Visibility = Visibility.Hidden;
            StatusViewCustTran.Visibility = Visibility.Hidden;
            ViewCustTranList.Visibility = Visibility.Hidden;
            textCustomerName.Visibility = Visibility.Hidden;
            hypercheck3.Visibility = Visibility.Hidden;
            hypercheck4.Visibility = Visibility.Hidden;
        }

        private void cmbViewCustTran_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            StatusViewCustTran.Visibility = Visibility.Hidden;
            if (cmbViewCustTran.SelectedIndex == 0)
            {
                cmbViewCustTran.BorderBrush = new SolidColorBrush(Colors.Orange);
                cmbViewCustTran.Foreground = new SolidColorBrush(Colors.Gray);
                hypercheck3.Visibility = Visibility.Hidden;
                hypercheck4.Visibility = Visibility.Hidden;
            }
            else
            {
                hypercheck3.Visibility = Visibility.Visible;
                hypercheck4.Visibility = Visibility.Visible;
                cmbViewCustTran.BorderBrush = new SolidColorBrush(Colors.Gray);
                cmbViewCustTran.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

      
        private void hypercheck1_Checked(object sender, RoutedEventArgs e)
        {
            count = 1;
            hypercheck2.IsChecked = false;
            hypercheck4.IsChecked = false; 
            hypercheck3.IsChecked = false;
            hyperchecklabel1.BorderBrush = new SolidColorBrush(Colors.Orange);
            hyperchecklabel1.Foreground = new SolidColorBrush(Colors.Orange);
            hyperchecklabel2.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel2.BorderBrush = new SolidColorBrush(Colors.White);
            cmbViewCustTran.Visibility = Visibility.Visible;
            textCustomerName.Visibility = Visibility.Visible;
        }

        private void hypercheck2_Checked(object sender, RoutedEventArgs e)
        {
            count = 2;
            hypercheck1.IsChecked = false;
            hypercheck4.IsChecked = false;
            hypercheck3.IsChecked = false;
            hyperchecklabel2.BorderBrush = new SolidColorBrush(Colors.Orange);
            hyperchecklabel2.Foreground = new SolidColorBrush(Colors.Orange);
            hyperchecklabel1.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel1.BorderBrush = new SolidColorBrush(Colors.White);
            cmbViewCustTran.Visibility = Visibility.Visible;
            textCustomerName.Visibility = Visibility.Visible;
        }

        private void hypercheck1_Unchecked(object sender, RoutedEventArgs e)
        {
           
            hyperchecklabel1.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel1.BorderBrush = new SolidColorBrush(Colors.White);
            cmbViewCustTran.Visibility = Visibility.Hidden;
            StatusViewCustTran.Visibility = Visibility.Hidden;
            ViewCustTranList.Visibility = Visibility.Hidden;
            textCustomerName.Visibility = Visibility.Hidden;
            hypercheck3.Visibility = Visibility.Hidden;
            hypercheck4.Visibility = Visibility.Hidden;
            cmbViewCustTran.SelectedIndex = 0;
            cmbViewCustTran.BorderBrush = new SolidColorBrush(Colors.Orange);
            cmbViewCustTran.Foreground = new SolidColorBrush(Colors.Gray);
        }

        private void hypercheck2_Unchecked(object sender, RoutedEventArgs e)
        {
           
            hyperchecklabel2.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel2.BorderBrush = new SolidColorBrush(Colors.White);
            cmbViewCustTran.Visibility = Visibility.Hidden;
            StatusViewCustTran.Visibility = Visibility.Hidden;
            ViewCustTranList.Visibility = Visibility.Hidden;
            textCustomerName.Visibility = Visibility.Hidden;
            hypercheck3.Visibility = Visibility.Hidden;
            hypercheck4.Visibility = Visibility.Hidden;
            cmbViewCustTran.SelectedIndex = 0;
            cmbViewCustTran.BorderBrush = new SolidColorBrush(Colors.Orange);
            cmbViewCustTran.Foreground = new SolidColorBrush(Colors.Gray);
        }


        public void populateComboBox()
        {
            dt = new DataTable();
            dt = businessLayer.populateCustomerName();
            dt.TableName = "PopulateCustomer";
            DataRow dr = dt.NewRow();
            dr["CustomerName"] = "--Select--";
            dr["CustomerCode"] = "null";
            dt.Rows.InsertAt(dr, 0);
            cmbViewCustTran.DataContext = dt;
            cmbViewCustTran.DisplayMemberPath = dt.Columns["CustomerName"].ToString();
            cmbViewCustTran.SelectedValuePath = dt.Columns["CustomerCode"].ToString();
        }

        private void hypercheck3_Checked(object sender, RoutedEventArgs e)
        {
            hypercheck4.IsChecked = false;
            hyperchecklabel3.BorderBrush = new SolidColorBrush(Colors.Orange);
            hyperchecklabel3.Foreground = new SolidColorBrush(Colors.Orange);
            hyperchecklabel4.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel4.BorderBrush = new SolidColorBrush(Colors.White);
           // int value;
            if (count == 1)
            {
               // value = 1;
                //ds=businessLayer.viewTransactions(value,cmbViewCustTran.SelectedValue.ToString());
                //if (ds.Tables["Transaction"].Rows.Count == 0)
                //{
                //    StatusViewCustTran.Foreground = new SolidColorBrush(Colors.Red);
                //    StatusViewCustTran.Text = "No Received Transaction Records Found For The Customer"+ " "+cmbViewCustTran.Text;
                //    StatusViewCustTran.Visibility = Visibility.Visible;
                //}
                //else
                //{
                //    ViewCustTranList.DataContext = ds;
                //    ViewCustTranList.Visibility = Visibility.Visible;
                //    StatusViewCustTran.Visibility = Visibility.Hidden;
                //}
            }
            else if (count == 2)
            {
                //value = 3;
                //ds = businessLayer.viewTransactions(value, cmbViewCustTran.SelectedValue.ToString());
                //if (ds.Tables["Transaction"].Rows.Count == 0)
                //{
                //    StatusViewCustTran.Foreground = new SolidColorBrush(Colors.Red);
                //    StatusViewCustTran.Text = "No Received Transaction Records Found For The Customer" + " " + cmbViewCustTran.Text;
                //    StatusViewCustTran.Visibility = Visibility.Visible;
                //}
                //else
                //{
                //    ViewCustTranList.DataContext = ds;
                //    ViewCustTranList.Visibility = Visibility.Visible;
                //    StatusViewCustTran.Visibility = Visibility.Hidden;
                //}
            }

        }

        private void hypercheck3_Unchecked(object sender, RoutedEventArgs e)
        {
            hyperchecklabel3.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel3.BorderBrush = new SolidColorBrush(Colors.White);
            StatusViewCustTran.Visibility = Visibility.Hidden;
            ViewCustTranList.Visibility = Visibility.Hidden;
        }

        private void hypercheck4_Checked(object sender, RoutedEventArgs e)
        {
            hypercheck3.IsChecked = false;
            hyperchecklabel4.BorderBrush = new SolidColorBrush(Colors.Orange);
            hyperchecklabel4.Foreground = new SolidColorBrush(Colors.Orange);
            hyperchecklabel3.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel3.BorderBrush = new SolidColorBrush(Colors.White);
            //int value;
            if (count == 1)
            {
               // value = 2;
                //ds = businessLayer.viewTransactions(value, cmbViewCustTran.SelectedValue.ToString());
                //if (ds.Tables["Transaction"].Rows.Count == 0)
                //{
                //    StatusViewCustTran.Foreground = new SolidColorBrush(Colors.Red);
                //    StatusViewCustTran.Text = "No Sold Transactions Records Found For The Customer" + " " + cmbViewCustTran.Text;
                //    StatusViewCustTran.Visibility = Visibility.Visible;
                //}
                //else
                //{
                //    ViewCustTranList.DataContext = ds;
                //    ViewCustTranList.Visibility = Visibility.Visible;
                //    StatusViewCustTran.Visibility = Visibility.Hidden;
                //}
            }
            else if (count == 2)
            {
               // value = 4;
                //ds = businessLayer.viewTransactions(value, cmbViewCustTran.SelectedValue.ToString());
                //if (ds.Tables["Transaction"].Rows.Count == 0)
                //{
                //    StatusViewCustTran.Foreground = new SolidColorBrush(Colors.Red);
                //    StatusViewCustTran.Text = "No Sold Transaction Records Found For The Customer" + " " + cmbViewCustTran.Text;
                //    StatusViewCustTran.Visibility = Visibility.Visible;
                //}
                //else
                //{
                //    ViewCustTranList.DataContext = ds;
                //    ViewCustTranList.Visibility = Visibility.Visible;
                //    StatusViewCustTran.Visibility = Visibility.Hidden;

                //}
            }
        }

        private void hypercheck4_Unchecked(object sender, RoutedEventArgs e)
        {
            hyperchecklabel4.Foreground = new SolidColorBrush(Colors.Gray);
            hyperchecklabel4.BorderBrush = new SolidColorBrush(Colors.White);
            StatusViewCustTran.Visibility = Visibility.Hidden;
            ViewCustTranList.Visibility = Visibility.Hidden;
        }
   
    }
}
