﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalSoftware.CustomerTransactions
{
    /// <summary>
    /// Interaction logic for UpdateWindow.xaml
    /// </summary>
    public partial class UpdateWindow : Window
    {
        private string custName;

        public string CustName
        {
            get { return custName; }
            set { custName = value; }
        }
        private string dateOfReceival;

        public string DateOfReceival
        {
            get { return dateOfReceival; }
            set { dateOfReceival = value; }
        }
        private string amount;

        public string Amount
        {
            get { return amount; }
            set { amount = value; }
        }
        private int count;

        public int Count
        {
            get { return count; }
            set { count = value; }
        }

        public UpdateWindow()
        {
            InitializeComponent();
        }

        public UpdateWindow(string custname,string date,string amount)
        {
            InitializeComponent();
            CustName = custname;
            Amount = amount;
            DateOfReceival = date;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            status.Visibility = Visibility.Hidden;
            txtCustomer.Text = CustName;
            txtDateOfReceival.Text = DateOfReceival;
            txtUpdateAmount.Text = Amount;
        }

        private void txtUpdateAmount_TextChanged(object sender, TextChangedEventArgs e)
        {
            status.Visibility = Visibility.Hidden;
            if (txtUpdateAmount.Text == null)
            {
                txtUpdateAmount.Foreground = new SolidColorBrush(Colors.Gray);
                txtUpdateAmount.BorderBrush = new SolidColorBrush(Colors.Orange);
            }
            else
            {
                txtUpdateAmount.Foreground = new SolidColorBrush(Colors.Orange);
                txtUpdateAmount.BorderBrush = new SolidColorBrush(Colors.Gray);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (txtUpdateAmount.Text == null)
            {
                status.Text = "Enter The Amount to be Updated";
                status.Foreground = new SolidColorBrush(Colors.Red);
                status.Visibility = Visibility.Visible;
            }
            else
            {
                status.Visibility = Visibility.Hidden;
                Count = 1;
                Amount = txtUpdateAmount.Text;
                this.Close();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            status.Visibility = Visibility.Hidden;
            Count = -1;
            this.Close();
        }
    }
}
