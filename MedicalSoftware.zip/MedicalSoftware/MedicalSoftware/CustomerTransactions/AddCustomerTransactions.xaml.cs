﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for AddCustomerTransactions.xaml
    /// </summary>
    public partial class AddCustomerTransactions : UserControl
    {
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        
       
        public AddCustomerTransactions()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            //populateComboBox();
        }

         private void cmbNewCustTran_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ErrorTranStatus.Visibility = Visibility.Hidden;
            StatusTran.Visibility = Visibility.Hidden;
           if (cmbNewCustTran.SelectedIndex == 0)
            {
                cmbNewCustTran.BorderBrush = new SolidColorBrush(Colors.Orange);
                cmbNewCustTran.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                cmbNewCustTran.BorderBrush = new SolidColorBrush(Colors.Gray);
                cmbNewCustTran.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void dtpNewCustTran_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            ErrorTranStatus.Visibility = Visibility.Hidden;
            StatusTran.Visibility = Visibility.Hidden;
            if (dtpNewCustTran.SelectedDate.Equals(null))
            {
                dtpNewCustTran.BorderBrush = new SolidColorBrush(Colors.Orange);
                dtpNewCustTran.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                dtpNewCustTran.BorderBrush = new SolidColorBrush(Colors.Gray);
                dtpNewCustTran.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void NewAmountTran_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorTranStatus.Visibility = Visibility.Hidden;
            StatusTran.Visibility = Visibility.Hidden;
            if (NewAmountTran.Text.Equals(""))
            {
                NewAmountTran.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewAmountTran.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewAmountTran.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewAmountTran.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void btnAddNewCustTran_Click(object sender, RoutedEventArgs e)
        {
            Thickness marginText = ErrorTranStatus.Margin;
            ErrorTranStatus.Height = 20;
            ErrorTranStatus.Width = 200;
            StatusTran.Visibility = Visibility.Hidden;
            if (cmbNewCustTran.SelectedIndex == 0)
            {
                cmbNewCustTran.BorderBrush = new SolidColorBrush(Colors.Red);
                ErrorTranStatus.Margin = new Thickness(40.0, -194.0, 0.0, 0.0);
                ErrorTranStatus.Text = "Select A Customer Name";
                ErrorTranStatus.Visibility = Visibility.Visible;

            }
            else
            {
                if (dtpNewCustTran.SelectedDate.Equals(null))
                {
                    dtpNewCustTran.BorderBrush = new SolidColorBrush(Colors.Red);
                    ErrorTranStatus.Margin = new Thickness(40.0, -80.0, 0.0, 0.0);
                    ErrorTranStatus.Text = "Select A Valid Date";
                    ErrorTranStatus.Visibility = Visibility.Visible;

                }
                else
                {
                    if (NewAmountTran.Text.Equals(""))
                    {
                        NewAmountTran.BorderBrush = new SolidColorBrush(Colors.Red);
                        ErrorTranStatus.Margin = new Thickness(40.0, 40.0, 0.0, 0.0);
                        ErrorTranStatus.Text = "Enter The AmountReceived";
                        ErrorTranStatus.Visibility = Visibility.Visible;
                        NewAmountTran.Focus();
                    }
                    else
                    {
                       // int value;
                        //businessLayer.newCustTransaction(out value, cmbNewCustTran.SelectedValue.ToString(), dtpNewCustTran.SelectedDate.Value.Date,Convert.ToDouble(NewAmountTran.Text.ToString()));
                        //if (value == -1)
                        //{
                        //   StatusTran.Text = "No Sales Record For Particular Customer"+" "+cmbNewCustTran.Text+"\n"
                        //                        + "Please Add Sales Record First";
                        //   StatusTran.Visibility = Visibility.Visible;
                        //}
                        //else
                        //{
                        //    StatusTran.Foreground = new SolidColorBrush(Colors.Gray);
                        //    StatusTran.Text = "Transactions Updated Successfully";
                        //    StatusTran.Visibility = Visibility.Visible;
                        //}
                    }
                }


            }
        }

       
          private void btnResetNewCustTran_Click(object sender, RoutedEventArgs e)
        {
            nullNewCustDetails();
        }

        //NullMethod-Customer Details.
        public void nullNewCustDetails()
        {
            cmbNewCustTran.SelectedIndex = 0;
            dtpNewCustTran.SelectedDate = null;
            NewAmountTran.Text = null;
            ErrorTranStatus.Visibility = Visibility.Hidden;
            StatusTran.Visibility = Visibility.Hidden;
            cmbNewCustTran.BorderBrush = new SolidColorBrush(Colors.Orange);
            cmbNewCustTran.Foreground = new SolidColorBrush(Colors.Gray);
            dtpNewCustTran.BorderBrush = new SolidColorBrush(Colors.Orange);
            dtpNewCustTran.Foreground = new SolidColorBrush(Colors.Gray);
            NewAmountTran.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewAmountTran.Foreground = new SolidColorBrush(Colors.Gray);
        }

        //public void populateComboBox()
        //{
        //    dt = new DataTable();
        //    dt = businessLayer.populateCustomerName();
        //    dt.TableName = "PopulateCustomer";
        //    DataRow dr = dt.NewRow();
        //    dr["CustomerName"] = "--Select--";
        //    dr["CustomerCode"] = "null";
        //    dt.Rows.InsertAt(dr, 0);
        //    cmbNewCustTran.DataContext = dt;
        //    cmbNewCustTran.DisplayMemberPath = dt.Columns["CustomerName"].ToString();
        //    cmbNewCustTran.SelectedValuePath = dt.Columns["CustomerCode"].ToString();
        //}
    }
}
