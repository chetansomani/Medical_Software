﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Windows.Threading;

namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer progressDispatch;
        BusinessAccessLayer businessLayer;
        int result;
        DataTable dt;

        public MainWindow()
        {
            InitializeComponent();
            progressDispatch = new DispatcherTimer();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            businessLayer = new BusinessAccessLayer();
            string username, passward;
            Thickness marginText = LoginErrorStatus.Margin;
              if (txtUsername.Text.Equals(""))
              {
                  LoginErrorStatus.Visibility = Visibility.Visible;
                  LoginErrorStatus.Margin = new Thickness(40.0, 20.0, 0.0, 0.0);
                  LoginErrorStatus.Text = "Enter Username";
                  LoginErrorStatus.Foreground = new SolidColorBrush(Colors.Red);
                  txtUsername.BorderBrush = new SolidColorBrush(Colors.Red);
                  txtUsername.Focus();
                 
              }
              else
              {
                  username = txtUsername.Text;
                  if (txtpassword.Password.ToString().Equals(""))
                  {
                      LoginErrorStatus.Visibility = Visibility.Visible;
                      LoginErrorStatus.Margin = new Thickness(200.0, 24.0, 0.0, 0.0);
                      LoginErrorStatus.Text = "Enter Password";
                      LoginErrorStatus.Foreground = new SolidColorBrush(Colors.Red);
                      txtpassword.BorderBrush = new SolidColorBrush(Colors.Red);
                      txtpassword.Focus();
                      
                  }
                  else
                  {
                      passward = txtpassword.Password.ToString();
                      dt = new DataTable();
                      dt = businessLayer.checkLoginDetails(username, passward);
                      if (dt.Rows.Count>0)
                      {
                          //sleepMethod();
                          Home homeWindow = new Home();
                          homeWindow.ShowDialog();
                      }
                      else
                      {
                          LoginErrorStatus.Margin = new Thickness(10.0, 24.0, 0.0, 0.0);
                          LoginErrorStatus.Visibility = Visibility.Visible;
                          LoginErrorStatus.Text = "Login Failed..Enter Correct Username And Password.";
                          txtpassword.BorderBrush = new SolidColorBrush(Colors.Red);
                          txtpassword.Foreground = new SolidColorBrush(Colors.Black);
                          txtpassword.Focus();
                          LoginErrorStatus.Foreground = new SolidColorBrush(Colors.Red);
                      }
                  }
              }
        }

        private void btnLoginReset_Click(object sender, RoutedEventArgs e)
        {
            txtUsername.Text = "";
            txtpassword.Password = "";
            LoginErrorStatus.Visibility = Visibility.Hidden;
            txtUsername.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtUsername.Foreground = new SolidColorBrush(Colors.Gray);
            txtpassword.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtpassword.Foreground = new SolidColorBrush(Colors.Gray);
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            businessLayer = new BusinessAccessLayer();
            Thickness marginText = RegisterErrorStatus.Margin;
            string registerId = businessLayer.autoRegisterId();
            string newUsername, newPassward, question, answer;
            if (txtNewUsername.Text.Equals(""))
            {
                txtNewUsername.Focus();
                txtNewUsername.BorderBrush = new SolidColorBrush(Colors.Red);
                RegisterErrorStatus.Margin = new Thickness(15.0, 5.0, 0.0, 0.0);
                RegisterErrorStatus.Text = "Enter Username";
                RegisterErrorStatus.Visibility = Visibility.Visible;
                RegisterErrorStatus.Foreground = new SolidColorBrush(Colors.Red);

            }
            else
            {
                newUsername = txtNewUsername.Text;
                if (txtNewpassword.Password.ToString().Equals(""))
                {
                    txtNewpassword.BorderBrush = new SolidColorBrush(Colors.Red);
                    txtNewpassword.Focus();
                    RegisterErrorStatus.Margin = new Thickness(15.0, 35.0, 0.0, 0.0);
               
                    RegisterErrorStatus.Text = "Enter Password";
                    RegisterErrorStatus.Visibility = Visibility.Visible;
                    RegisterErrorStatus.Foreground = new SolidColorBrush(Colors.Red);
                }
                else
                {

                    if (txtRetypepassword.Password.ToString().Equals(""))
                    {
                        txtRetypepassword.BorderBrush = new SolidColorBrush(Colors.Red);
                        txtRetypepassword.Focus();
                        RegisterErrorStatus.Margin = new Thickness(0.0, 72.0, 0.0, 0.0);
               
                        RegisterErrorStatus.Text = "Enter RetypePassword";
                        RegisterErrorStatus.Visibility = Visibility.Visible;
                        RegisterErrorStatus.Foreground = new SolidColorBrush(Colors.Red);
                    }
                    else
                    {
                        if (txtNewpassword.Password.ToString().Equals(txtRetypepassword.Password.ToString()))
                        {
                            newPassward = txtNewpassword.Password.ToString();
                            if (cmbQuestion.SelectedIndex == 0)
                            {
                                cmbQuestion.BorderBrush = new SolidColorBrush(Colors.Red);
                                cmbQuestion.Focus();
                                RegisterErrorStatus.Margin = new Thickness(10.0, 105.0, 0.0, 0.0);
               
                                RegisterErrorStatus.Text = "Select A Question";
                                RegisterErrorStatus.Visibility = Visibility.Visible;
                                RegisterErrorStatus.Foreground = new SolidColorBrush(Colors.Red);

                            }
                            else
                            {
                                question = cmbQuestion.SelectedIndex.ToString();
                                if (txtAnswer.Password.ToString().Equals(""))
                                {
                                    txtAnswer.BorderBrush = new SolidColorBrush(Colors.Red);
                                    txtAnswer.Focus();
                                    RegisterErrorStatus.Margin = new Thickness(10.0, 138.0, 0.0, 0.0);
                                    RegisterErrorStatus.Text = "Enter The Answer";
                                    RegisterErrorStatus.Visibility = Visibility.Visible;
                                    RegisterErrorStatus.Foreground = new SolidColorBrush(Colors.Red);
                                }
                                else
                                {
                                    answer = txtAnswer.Password.ToString();
                                    result = businessLayer.newRegisterDetails(registerId, newUsername, newPassward, question, answer);
                                    if (result>0)
                                    {
                                        RegisterStatus.Text = "Registered Successfully.Now,you can Login.";
                                        RegisterStatus.Foreground = new SolidColorBrush(Colors.Gray);
                                        RegisterStatus.Visibility = Visibility.Visible;
                                    }
                                    else
                                    {
                                        
                                        RegisterStatus.Text = "Error In Registering.Please Try Again Later.";
                                        RegisterStatus.Foreground = new SolidColorBrush(Colors.Red);
                                        RegisterStatus.Visibility = Visibility.Visible;
                                    }
                                }

                            }
                        }
                        else
                        {
                            //txtNewpassword.BorderBrush = new SolidColorBrush(Colors.Red);
                            //txtNewpassword.Focus();
                            txtRetypepassword.BorderBrush = new SolidColorBrush(Colors.Red);
                            txtRetypepassword.Focus();
                            RegisterStatus.Text = "Passwords Do not Match."+"\n"+"Re-Enter The Password.";
                            RegisterStatus.Foreground = new SolidColorBrush(Colors.Red);
                            RegisterStatus.Visibility = Visibility.Visible;
                        }
                    }
                }
            }
        }

        private void btnRegisterReset_Click(object sender, RoutedEventArgs e)
        {
            txtNewUsername.Text = "";
            txtNewpassword.Password = "";
            txtRetypepassword.Password = "";
            cmbQuestion.SelectedIndex = 0;
            txtAnswer.Password = "";
            RegisterErrorStatus.Visibility = Visibility.Hidden;
            RegisterStatus.Visibility = Visibility.Hidden;
            txtNewUsername.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtNewUsername.Foreground = new SolidColorBrush(Colors.Gray);
            txtNewpassword.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtNewpassword.Foreground = new SolidColorBrush(Colors.Gray);
            txtRetypepassword.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtRetypepassword.Foreground = new SolidColorBrush(Colors.Gray);
            cmbQuestion.BorderBrush = new SolidColorBrush(Colors.Orange);
            cmbQuestion.Foreground = new SolidColorBrush(Colors.Gray);
            txtAnswer.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtAnswer.Foreground = new SolidColorBrush(Colors.Gray);
        }

        private void txtUsername_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoginErrorStatus.Visibility = Visibility.Hidden;
            if (txtUsername.Text.Equals(""))
            {
                txtUsername.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtUsername.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                txtUsername.BorderBrush = new SolidColorBrush(Colors.Gray);
                txtUsername.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void txtpassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            LoginErrorStatus.Visibility = Visibility.Hidden;
            if (txtpassword.Password.ToString().Equals(""))
            {
                txtpassword.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtpassword.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                txtpassword.BorderBrush = new SolidColorBrush(Colors.Gray);
                txtpassword.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void txtNewUsername_TextChanged(object sender, TextChangedEventArgs e)
        {
            RegisterStatus.Visibility = Visibility.Hidden;
            RegisterErrorStatus.Visibility = Visibility.Hidden;
            if (txtNewUsername.Text.Equals(""))
            {
                txtNewUsername.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtNewUsername.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                txtNewUsername.BorderBrush = new SolidColorBrush(Colors.Gray);
                txtNewUsername.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void txtNewpassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            RegisterStatus.Visibility = Visibility.Hidden;
            RegisterErrorStatus.Visibility = Visibility.Hidden;
            if (txtNewpassword.Password.ToString().Equals(""))
            {
                txtNewpassword.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtNewpassword.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                txtNewpassword.BorderBrush = new SolidColorBrush(Colors.Gray);
                txtNewpassword.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void txtRetypepassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            RegisterStatus.Visibility = Visibility.Hidden;
            RegisterErrorStatus.Visibility = Visibility.Hidden;
            if (txtRetypepassword.Password.ToString().Equals(""))
            {
                txtRetypepassword.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtRetypepassword.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                txtRetypepassword.BorderBrush = new SolidColorBrush(Colors.Gray);
                txtRetypepassword.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void cmbQuestion_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RegisterStatus.Visibility = Visibility.Hidden;
            RegisterErrorStatus.Visibility = Visibility.Hidden;
            if (cmbQuestion.SelectedIndex==0)
            {
                cmbQuestion.BorderBrush = new SolidColorBrush(Colors.Orange);
                cmbQuestion.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                cmbQuestion.BorderBrush = new SolidColorBrush(Colors.Gray);
                cmbQuestion.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

  
        private void txtAnswer_PasswordChanged(object sender, RoutedEventArgs e)
        {
            RegisterStatus.Visibility = Visibility.Hidden;
            RegisterErrorStatus.Visibility = Visibility.Hidden;
            if (txtAnswer.Password.ToString().Equals(""))
            {
                txtAnswer.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtAnswer.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                txtAnswer.BorderBrush = new SolidColorBrush(Colors.Gray);
                txtAnswer.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void forgotPassword_Click(object sender, RoutedEventArgs e)
        {
            ForgotPassword frgtPass = new ForgotPassword();
            frgtPass.ShowDialog();
        }

        private void forgotPassword_MouseLeave(object sender, MouseEventArgs e)
        {
            forgotPassword.TextDecorations = null;
        }

        private void forgotPassword_MouseEnter(object sender, MouseEventArgs e)
        {
            forgotPassword.TextDecorations = TextDecorations.Underline;
        }

        //public void sleepMethod()
        //{
        //    progressDispatch.Tick += new EventHandler(dispatcher_Tick);
        //    progressDispatch.Interval = TimeSpan.FromMilliseconds(50);
        //    progressDispatch.Start();
        //    System.Threading.Thread.Sleep(1000);
        //}

        ////DispatcherTick Method.
        //private void dispatcher_Tick(object sender, EventArgs e)
        //{
            

        //}
    }

}
