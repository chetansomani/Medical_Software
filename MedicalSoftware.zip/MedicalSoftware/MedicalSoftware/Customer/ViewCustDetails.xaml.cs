﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for ViewCustDetails.xaml
    /// </summary>
    public partial class ViewCustDetails : UserControl
    {
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        DataTable dt;
        DataSet ds;
        private int count;

        public int Count
        {
            get { return count; }
            set { count = value; }
        }
       
        public ViewCustDetails()
        {
            InitializeComponent();
            
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

            populateComboBox();
        }

        //Combo Box
        private void cmbViewCustomerDetails_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            StatusViewCustomerDetails.Visibility = Visibility.Hidden;
            ViewCustomerDetailsList.Visibility = Visibility.Hidden;
            if (cmbViewCustomerDetails.SelectedIndex == 0)
            {
                cmbViewCustomerDetails.BorderBrush = new SolidColorBrush(Colors.Orange);
                cmbViewCustomerDetails.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                cmbViewCustomerDetails.BorderBrush = new SolidColorBrush(Colors.Gray);
                cmbViewCustomerDetails.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        //View Button
        private void btnViewCustomerDetails_Click(object sender, RoutedEventArgs e)
        {
            if (cmbViewCustomerDetails.SelectedIndex == 0)
            {
                cmbViewCustomerDetails.BorderBrush = new SolidColorBrush(Colors.Red);
                StatusViewCustomerDetails.Text = "Select A Customer Name In Order To View His Details";
                StatusViewCustomerDetails.Foreground = new SolidColorBrush(Colors.Red);
                StatusViewCustomerDetails.Visibility = Visibility.Visible;
                ViewCustomerDetailsList.Visibility = Visibility.Hidden;
            }
            else
            {
                StatusViewCustomerDetails.Visibility = Visibility.Hidden;
                ViewCustomerDetailsList.Visibility = Visibility.Visible;
                ds = businessLayer.viewCustomerDetails(cmbViewCustomerDetails.SelectedValue.ToString());
                ViewCustomerDetailsList.DataContext = ds;
               
            }
        }

     

        //Reset Button
        private void btnResetViewCustomerDetails_Click(object sender, RoutedEventArgs e)
        {
            cmbViewCustomerDetails.SelectedIndex = 0;
            StatusViewCustomerDetails.Visibility = Visibility.Hidden;
            ViewCustomerDetailsList.Visibility = Visibility.Hidden;
        }

        public void populateComboBox()
        {
            dt = new DataTable();
            dt = businessLayer.populateCustomerName();
            dt.TableName = "PopulateCustomer";
            DataRow dr = dt.NewRow();
            dr["CustomerName"] = "--Select--";
            dr["CustomerCode"] = "null";
            dt.Rows.InsertAt(dr, 0);
            cmbViewCustomerDetails.DataContext = dt;
            cmbViewCustomerDetails.DisplayMemberPath = dt.Columns["CustomerName"].ToString();
            cmbViewCustomerDetails.SelectedValuePath = dt.Columns["CustomerCode"].ToString();
        }
    }
}
