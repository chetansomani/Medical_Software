﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;


namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for DeleteCustDetails.xaml
    /// </summary>
    public partial class DeleteCustDetails : UserControl
    {
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        DataTable dt;
        DataSet ds;
        private int count;

        public int Count
        {
            get { return count; }
            set { count = value; }
        }
       

        public DeleteCustDetails()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            populateComboBox();
        }

        private void btnDeleteCustomerDetails_Click(object sender, RoutedEventArgs e)
        {
            if (cmbDeleteCustomerDetails.SelectedIndex == 0)
            {
                cmbDeleteCustomerDetails.BorderBrush = new SolidColorBrush(Colors.Red);
                StatusDeleteCustomerDetails.Text = "Select A Customer Name In Order To Delete His Details";
                StatusDeleteCustomerDetails.Foreground = new SolidColorBrush(Colors.Red);
                StatusDeleteCustomerDetails.Visibility = Visibility.Visible;
                DeleteCustomerDetailsList.Visibility = Visibility.Hidden;
                btnDeleteFinal.Visibility = Visibility.Hidden;
            }
            else
            {
                StatusDeleteCustomerDetails.Visibility = Visibility.Hidden;
                DeleteCustomerDetailsList.Visibility = Visibility.Visible;
                ds = businessLayer.viewCustomerDetails(cmbDeleteCustomerDetails.SelectedValue.ToString());
                DeleteCustomerDetailsList.DataContext = ds;
                btnDeleteFinal.Visibility = Visibility.Visible;
            }
        }

        private void cmbDeleteCustomerDetails_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            StatusDeleteCustomerDetails.Visibility = Visibility.Hidden;
            DeleteCustomerDetailsList.Visibility = Visibility.Hidden;
            btnDeleteFinal.Visibility = Visibility.Hidden;
            if (cmbDeleteCustomerDetails.SelectedIndex == 0)
            {
                cmbDeleteCustomerDetails.BorderBrush = new SolidColorBrush(Colors.Orange);
                cmbDeleteCustomerDetails.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                cmbDeleteCustomerDetails.BorderBrush = new SolidColorBrush(Colors.Gray);
                cmbDeleteCustomerDetails.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void btnResetDeleteCustomerDetails_Click(object sender, RoutedEventArgs e)
        {
            cmbDeleteCustomerDetails.SelectedIndex = 0;
            StatusDeleteCustomerDetails.Visibility = Visibility.Hidden;
            DeleteCustomerDetailsList.Visibility = Visibility.Hidden;
            btnDeleteFinal.Visibility = Visibility.Hidden;
        }


        public void populateComboBox()
        {
            dt = new DataTable();
            dt = businessLayer.populateCustomerName();
            dt.TableName = "PopulateCustomer";
            DataRow dr = dt.NewRow();
            dr["CustomerName"] = "--Select--";
            dr["CustomerCode"] = "null";
            dt.Rows.InsertAt(dr, 0);
            cmbDeleteCustomerDetails.DataContext = dt;
            cmbDeleteCustomerDetails.DisplayMemberPath = dt.Columns["CustomerName"].ToString();
            cmbDeleteCustomerDetails.SelectedValuePath = dt.Columns["CustomerCode"].ToString();
        }

        private void btnDeleteFinal_Click(object sender, RoutedEventArgs e)
        {
            StatusDeleteCustomerDetails.Visibility = Visibility.Hidden;
            int i;
            System.Windows.MessageBoxResult result = MessageBox.Show("You wanna Delete?", "Delete", MessageBoxButton.YesNo);
            string res = result.ToString();
            if (res.Equals("Yes"))
            {
                string custName = cmbDeleteCustomerDetails.Text;
                i = businessLayer.deleteCustomerDetails(cmbDeleteCustomerDetails.SelectedValue.ToString());
                if (i > 0)
                {
                    DeleteCustomerDetailsList.Visibility = Visibility.Hidden;
                    btnDeleteFinal.Visibility = Visibility.Hidden;
                    //populateComboBox();
                    cmbDeleteCustomerDetails.SelectedIndex = 0;
                    StatusDeleteCustomerDetails.Text = "Customer"+" "+custName+" "+"Details Deleted Succesfully";
                    StatusDeleteCustomerDetails.Foreground = new SolidColorBrush(Colors.Gray);
                    StatusDeleteCustomerDetails.Visibility = Visibility.Visible;
                }
                else
                {
                    StatusDeleteCustomerDetails.Text = "Error In Deleting Customer"+" "+custName+" "+"Details";
                    StatusDeleteCustomerDetails.Foreground = new SolidColorBrush(Colors.Red);
                    StatusDeleteCustomerDetails.Visibility = Visibility.Visible;
                }
            }
            else
            {
            }

        }

       
    }
}
