﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for NewCustDetails.xaml
    /// </summary>
    public partial class NewCustDetails : UserControl
    {
        BusinessAccessLayer businessLayer;
        string addAppend;
        public NewCustDetails()
        {
            InitializeComponent();
        }

        //****************************************Customer Methods*************************************************************
        //Text Changed Methods
        
        private void NewCustCode_TextChanged(object sender, TextChangedEventArgs e)
        {
             ErrorStatus.Visibility = Visibility.Hidden;
             Status.Visibility = Visibility.Hidden;
             if (NewCustCode.Text.Equals(""))
             {
                 NewCustCode.BorderBrush = new SolidColorBrush(Colors.Orange);
                 NewCustCode.Foreground = new SolidColorBrush(Colors.Gray);
             }
             else
             {
                 NewCustCode.BorderBrush = new SolidColorBrush(Colors.Gray);
                 NewCustCode.Foreground = new SolidColorBrush(Colors.Orange);

             }
        }

        private void NewCustDlNo_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;
            if (NewCustDlNo.Text.Equals(""))
            {
                NewCustDlNo.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewCustDlNo.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewCustDlNo.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewCustDlNo.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void NewCustName_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;
             if ( NewCustName.Text.Equals(""))
             {
                 NewCustName.BorderBrush = new SolidColorBrush(Colors.Orange);
                 NewCustName.Foreground = new SolidColorBrush(Colors.Gray);
             }
             else
             {
                 NewCustName.BorderBrush = new SolidColorBrush(Colors.Gray);
                 NewCustName.Foreground = new SolidColorBrush(Colors.Orange);
             }
        }

        private void NewCustAdd_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;
              if ( NewCustAdd.Text.Equals(""))
              {
                  NewCustAdd.BorderBrush = new SolidColorBrush(Colors.Orange);
                  NewCustAdd.Foreground = new SolidColorBrush(Colors.Gray);
              }
              else
              {
                  NewCustAdd.BorderBrush = new SolidColorBrush(Colors.Gray);
                  NewCustAdd.Foreground = new SolidColorBrush(Colors.Orange);
              }
        }

        private void NewCustPhno1_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;
            if (NewCustPhno1.Text.Equals(""))
            {
                NewCustPhno1.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewCustPhno1.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewCustPhno1.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewCustPhno1.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void NewCustPhno2_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;
              if (NewCustPhno2.Text.Equals(""))
              {
                  NewCustPhno2.BorderBrush = new SolidColorBrush(Colors.Orange);
                  NewCustPhno2.Foreground = new SolidColorBrush(Colors.Gray);
              }
              else
              {
                  NewCustPhno2.BorderBrush = new SolidColorBrush(Colors.Gray);
                  NewCustPhno2.Foreground = new SolidColorBrush(Colors.Orange);
              }
        }

        //AddAddress-Button To Add Address

        private void btnNewCustAdd_Click(object sender, RoutedEventArgs e)
        {
            //Changes Made
            NewCustAdd.IsReadOnly = false;
            AddressWindow add = new AddressWindow();
            Address address = new Address();
            add.ShowDialog();
            if (AddressWindow.Count == 1)
            {
                string addre, city, state, pincode;
                address.outputAddress(out addre, out city, out state, out pincode);
                NewCustAdd.Text = addre+ ","+ "\n" + city +"," + state +"-"+ pincode;
                addAppend = addre + "^" + city + "^" + state + "^" + pincode;
            }
            else
            {
                NewCustAdd.IsReadOnly = true;
            }
        }


        //AddDetails-Button To Add New Customer Details
        private void btnAddNewCustDetails_Click(object sender, RoutedEventArgs e)
        {
            businessLayer = new BusinessAccessLayer();
            int result;
            Thickness marginText = ErrorStatus.Margin;
            ErrorStatus.Height = 20;
            ErrorStatus.Width = 200;
            if (NewCustCode.Text.Equals(""))
            {
                NewCustCode.BorderBrush = new SolidColorBrush(Colors.Red);
                ErrorStatus.Margin = new Thickness(100.0, -260.0, 0.0, 0.0);
                ErrorStatus.Text = "Enter Customer Code";
                ErrorStatus.Visibility = Visibility.Visible;
                NewCustCode.Focus();
            }
            else
            {
                if (NewCustDlNo.Text.Equals(""))
                {
                    NewCustDlNo.BorderBrush = new SolidColorBrush(Colors.Red);
                    ErrorStatus.Margin = new Thickness(80.0, -140.0, 0.0, 0.0);
                    ErrorStatus.Text = "Enter Customer DlNo";
                    ErrorStatus.Visibility = Visibility.Visible;
                    NewCustDlNo.Focus();
                }
                else
                {
                    if (NewCustName.Text.Equals(""))
                    {
                        NewCustName.BorderBrush = new SolidColorBrush(Colors.Red);
                        ErrorStatus.Margin = new Thickness(70.0, -20.0, 0.0, 0.0);
                        ErrorStatus.Text = "Enter Customer Name";
                        ErrorStatus.Visibility = Visibility.Visible;
                        NewCustName.Focus();
                    }
                    else
                    {
                        //Changes Made
                        if (NewCustAdd.Text.Equals(""))
                        {
                            NewCustAdd.BorderBrush = new SolidColorBrush(Colors.Red);
                            ErrorStatus.Margin = new Thickness(0.0,140.0, 0.0, 0.0);
                            ErrorStatus.Text = "Enter CustomerAddress Using >>>";
                            ErrorStatus.Visibility = Visibility.Visible;
                            NewCustAdd.IsReadOnly = true;
                            btnNewCustAdd.Focus();
                        }
                        else
                        {
                            if (NewCustPhno1.Text.Equals(""))
                            {
                                NewCustPhno1.BorderBrush = new SolidColorBrush(Colors.Red);
                                ErrorStatus.Margin = new Thickness(45.0, 240.0, 0.0, 0.0);
                                ErrorStatus.Text = "Enter Customer Phno1";
                                ErrorStatus.Visibility = Visibility.Visible;
                                NewCustPhno1.Focus();
                            }
                            else
                            {
                                if (NewCustPhno2.Text.Equals(""))
                                {
                                    NewCustPhno2.Text = "0000000000";
                                    result = businessLayer.newCustomerDetails(NewCustCode.Text, NewCustDlNo.Text, NewCustName.Text, addAppend, Convert.ToInt64(NewCustPhno1.Text.ToString()), Convert.ToInt64(NewCustPhno2.Text.ToString()));
                                    if (result > 0)
                                    {
                                        Status.Text = "Customer"+" "+NewCustName.Text+" "+"Details Successfully Inserted.";
                                        Status.Visibility = Visibility.Visible;
                                    }
                                    else
                                    {
                                        Status.Text = "Error In Inserting Details Of Customer"+ " "+NewCustName.Text;
                                        Status.Visibility = Visibility.Visible;
                                    }
                                }
                                else
                                {
                                    result = businessLayer.newCustomerDetails(NewCustCode.Text, NewCustDlNo.Text, NewCustName.Text, addAppend, Convert.ToInt64(NewCustPhno1.Text.ToString()), Convert.ToInt64(NewCustPhno2.Text.ToString()));
                                    if (result > 0)
                                    {
                                        Status.Text = "Customer" + " " + NewCustName.Text + " " + "Details Successfully Inserted.";
                                        Status.Visibility = Visibility.Visible;
                                    }
                                    else
                                    {
                                        Status.Text = "Error In Inserting Details Of Customer" + " " + NewCustName.Text;
                                        Status.Visibility = Visibility.Visible;
                                    }
                                }
                            }
                        }
                    }
                }
            }

        }
       

        //ResetDetails-Button To Reset New Customer Details
        private void btnResetNewCustDetails_Click(object sender, RoutedEventArgs e)
        {
            nullNewCustDetails();
        }

        //NullMethod-Customer Details.
        public void nullNewCustDetails()
        {
            NewCustCode.Text = null;
            NewCustDlNo.Text = null;
            NewCustName.Text = null;
            NewCustAdd.Text = null;
            NewCustPhno1.Text = null;
            NewCustPhno2.Text = null;
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;
            NewCustPhno2.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewCustPhno2.Foreground = new SolidColorBrush(Colors.Gray);
            NewCustPhno1.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewCustPhno1.Foreground = new SolidColorBrush(Colors.Gray);
            NewCustCode.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewCustCode.Foreground = new SolidColorBrush(Colors.Gray);
            NewCustName.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewCustName.Foreground = new SolidColorBrush(Colors.Gray);
            NewCustAdd.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewCustAdd.Foreground = new SolidColorBrush(Colors.Gray);
            NewCustDlNo.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewCustDlNo.Foreground = new SolidColorBrush(Colors.Gray);
        }

    }
}
