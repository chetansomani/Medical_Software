﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;


namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for UpdateCustDetails.xaml
    /// </summary>
    public partial class UpdateCustDetails : UserControl
    {
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        DataTable dt;
        DataSet ds;
        string addUpdate;
        string initialAdd;
        public UpdateCustDetails()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            populateComboBox();
        }

        private void cmbUpdateCustomerDetails_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            if (cmbUpdateCustomerDetails.SelectedIndex == 0)
            {
                cmbUpdateCustomerDetails.BorderBrush = new SolidColorBrush(Colors.Orange);
                cmbUpdateCustomerDetails.Foreground = new SolidColorBrush(Colors.Gray);
                btnUpdateCustAdd.Visibility = Visibility.Hidden;
                UpdateCustCode.Text = null;
                UpdateCustDlNo.Text = null;
                UpdateCustAdd.Text = null;
                UpdateCustPhno1.Text = null;
                UpdateCustPhno2.Text = null;
                UpdateCustAdd.IsReadOnly = true;
                UpdateCustCode.IsReadOnly = true;
                UpdateCustDlNo.IsReadOnly = true;
                UpdateCustPhno1.IsReadOnly = true;
                UpdateCustPhno2.IsReadOnly = true;
            }
            else
            {
                btnUpdateCustAdd.Visibility = Visibility.Visible;
                cmbUpdateCustomerDetails.BorderBrush = new SolidColorBrush(Colors.Gray);
                cmbUpdateCustomerDetails.Foreground = new SolidColorBrush(Colors.Orange);
                UpdateCustAdd.IsReadOnly = false;
                UpdateCustCode.IsReadOnly = false;
                UpdateCustDlNo.IsReadOnly = false;
                UpdateCustPhno1.IsReadOnly = false;
                UpdateCustPhno2.IsReadOnly = false;
                ds = businessLayer.viewCustomerDetails(cmbUpdateCustomerDetails.SelectedValue.ToString());
                UpdateCustCode.Text = ds.Tables["Customer"].Rows[0]["CustomerCode"].ToString();
                UpdateCustDlNo.Text = ds.Tables["Customer"].Rows[0]["CustomerDlno"].ToString();
                initialAdd = ds.Tables["Customer"].Rows[0]["CustomerAddress"].ToString();
                string[] arrayString = initialAdd.Split('^');
                int length = arrayString.Length;
                string addre = arrayString[0].ToString();
                string city = arrayString[1].ToString();
                string state = arrayString[2].ToString();
                string pincode = arrayString[3].ToString();
                UpdateCustAdd.Text = addre + "," + "\n" + city + "," + state + "-" + pincode;
                UpdateCustPhno1.Text = ds.Tables["Customer"].Rows[0]["CustomerPhno1"].ToString();
                UpdateCustPhno2.Text = ds.Tables["Customer"].Rows[0]["CustomerPhno2"].ToString();
            }
        }

        private void UpdateCustCode_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            if (UpdateCustCode.Text.Equals(""))
            {
                UpdateCustCode.BorderBrush = new SolidColorBrush(Colors.Orange);
                UpdateCustCode.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                UpdateCustCode.BorderBrush = new SolidColorBrush(Colors.Gray);
                UpdateCustCode.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void UpdateCustDlNo_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            if (UpdateCustDlNo.Text.Equals(""))
            {
                UpdateCustDlNo.BorderBrush = new SolidColorBrush(Colors.Orange);
                UpdateCustDlNo.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                UpdateCustDlNo.BorderBrush = new SolidColorBrush(Colors.Gray);
                UpdateCustDlNo.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void UpdateCustAdd_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateCustAdd.IsReadOnly = true;
            ErrorStatus.Visibility = Visibility.Hidden;
            if (UpdateCustAdd.Text.Equals(""))
            {
                UpdateCustAdd.BorderBrush = new SolidColorBrush(Colors.Orange);
                UpdateCustAdd.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                UpdateCustAdd.BorderBrush = new SolidColorBrush(Colors.Gray);
                UpdateCustAdd.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void UpdateCustPhno1_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            if (UpdateCustPhno1.Text.Equals(""))
            {
                UpdateCustPhno1.BorderBrush = new SolidColorBrush(Colors.Orange);
                UpdateCustPhno1.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                UpdateCustPhno1.BorderBrush = new SolidColorBrush(Colors.Gray);
                UpdateCustPhno1.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void UpdateCustPhno2_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            if (UpdateCustPhno2.Text.Equals(""))
            {
                UpdateCustPhno2.BorderBrush = new SolidColorBrush(Colors.Orange);
                UpdateCustPhno2.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                UpdateCustPhno2.BorderBrush = new SolidColorBrush(Colors.Gray);
                UpdateCustPhno2.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void btnUpdateCustAdd_Click(object sender, RoutedEventArgs e)
        {
            string addressString = initialAdd;
            string[] arrayString=addressString.Split('^');
            int length = arrayString.Length;
            string add1 = arrayString[0].ToString();
            string add2 = arrayString[1].ToString();
            string add3 = arrayString[2].ToString();
            string add4 = arrayString[3].ToString();
            //string add5 = arrayString[4].ToString();
            AddressWindow add = new AddressWindow(add1,add2,add3,add4);
            add.ShowDialog();
            Address address = new Address();
            if (AddressWindow.Count == 1)
            {
                string addre, city, state, pincode;
                address.outputAddress(out addre, out city, out state, out pincode);
                UpdateCustAdd.Text = addre + "," + "\n" + city + "," + state + "-" + pincode;
                addUpdate = addre + "^" + city + "^" + state + "^" + pincode;
            }
            else
            {
                UpdateCustAdd.IsReadOnly = true;
            }
        }

        private void btnUpdateCustDetails_Click(object sender, RoutedEventArgs e)
        {
            int result;
            string cmbValue = "";
            cmbValue = cmbUpdateCustomerDetails.Text;
            Thickness marginText = ErrorStatus.Margin;
            ErrorStatus.Height = 20;
            ErrorStatus.Width = 200;
            if (cmbUpdateCustomerDetails.SelectedIndex == 0)
            {
                cmbUpdateCustomerDetails.BorderBrush = new SolidColorBrush(Colors.Red);
                ErrorStatus.Margin = new Thickness(40.0, -194.0, 0.0, 0.0);
                ErrorStatus.Text = "Select A Customer Name";
                ErrorStatus.Visibility = Visibility.Visible;
            }
            else
            {
                if (UpdateCustCode.Text.Equals(""))
                {
                    UpdateCustCode.BorderBrush = new SolidColorBrush(Colors.Red);
                    ErrorStatus.Margin = new Thickness(80.0, -140.0, 0.0, 0.0);
                    ErrorStatus.Text = "Enter Customer Code";
                    ErrorStatus.Visibility = Visibility.Visible;
                    UpdateCustCode.Focus();
                }
                else
                {
                    if (UpdateCustDlNo.Text.Equals(""))
                    {
                        UpdateCustDlNo.BorderBrush = new SolidColorBrush(Colors.Red);
                        ErrorStatus.Margin = new Thickness(70.0, -20.0, 0.0, 0.0);
                        ErrorStatus.Text = "Enter Customer DlNo";
                        ErrorStatus.Visibility = Visibility.Visible;
                        UpdateCustDlNo.Focus();
                    }
                    else
                    {
                       if (UpdateCustAdd.Text.Equals(""))
                            {
                                UpdateCustAdd.BorderBrush = new SolidColorBrush(Colors.Red);
                                ErrorStatus.Margin = new Thickness(0.0, 140.0, 0.0, 0.0);
                                ErrorStatus.Text = "Enter Customer Address";
                                ErrorStatus.Visibility = Visibility.Visible;
                                UpdateCustAdd.IsReadOnly = true;
                                btnUpdateCustAdd.Focus();
                            }
                            else
                            {
                                if (UpdateCustPhno1.Text.Equals(""))
                                {
                                    UpdateCustPhno1.BorderBrush = new SolidColorBrush(Colors.Red);
                                    ErrorStatus.Margin = new Thickness(45.0, 240.0, 0.0, 0.0);
                                    ErrorStatus.Text = "Enter Customer Phno1";
                                    ErrorStatus.Visibility = Visibility.Visible;
                                    UpdateCustPhno1.Focus();
                                }
                                else
                                {
                                    if (UpdateCustPhno2.Text.Equals(""))
                                    {
                                        UpdateCustPhno2.Text = "0000000000";
                                        result = businessLayer.updateCustomerDetails(UpdateCustCode.Text, UpdateCustDlNo.Text, cmbValue, addUpdate, Convert.ToInt64(UpdateCustPhno1.Text.ToString()), Convert.ToInt64(UpdateCustPhno2.Text.ToString()));
                                        if (result > 0)
                                        {
                                            Status.Text = "Customer" + " " + cmbValue + " " + "Details Successfully Updated.";
                                            Status.Visibility = Visibility.Visible;
                                        }
                                        else
                                        {
                                            Status.Text = "Error In Updating Details Of Customer" + " " + cmbValue;
                                            Status.Visibility = Visibility.Visible;
                                        }
                                    }
                                    else
                                    {
                                        result = businessLayer.updateCustomerDetails(UpdateCustCode.Text, UpdateCustDlNo.Text, cmbValue, addUpdate, Convert.ToInt64(UpdateCustPhno1.Text.ToString()), Convert.ToInt64(UpdateCustPhno2.Text.ToString()));
                                        if (result > 0)
                                        {
                                            Status.Text = "Customer" + " " + cmbValue + " " + "Details Successfully Updated.";
                                            Status.Visibility = Visibility.Visible;
                                        }
                                        else
                                        {
                                            Status.Text = "Error In Updating Details Of Customer" + " " + cmbValue;
                                            Status.Visibility = Visibility.Visible;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            
        }

        private void btnResetUpdateCustDetails_Click(object sender, RoutedEventArgs e)
        {
            nullUpdateCustDetails();
        }

        //NullMethod-Customer Details.
        public void nullUpdateCustDetails()
        {
            btnUpdateCustAdd.Visibility = Visibility.Hidden;
            UpdateCustCode.Text = null;
            UpdateCustDlNo.Text = null;
            cmbUpdateCustomerDetails.SelectedIndex = 0;
            UpdateCustAdd.Text = null;
            UpdateCustPhno1.Text = null;
            UpdateCustPhno2.Text = null;
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;
            UpdateCustPhno2.BorderBrush = new SolidColorBrush(Colors.Orange);
            UpdateCustPhno2.Foreground = new SolidColorBrush(Colors.Gray);
            UpdateCustPhno1.BorderBrush = new SolidColorBrush(Colors.Orange);
            UpdateCustPhno1.Foreground = new SolidColorBrush(Colors.Gray);
            UpdateCustCode.BorderBrush = new SolidColorBrush(Colors.Orange);
            UpdateCustCode.Foreground = new SolidColorBrush(Colors.Gray);
            cmbUpdateCustomerDetails.BorderBrush = new SolidColorBrush(Colors.Orange);
            cmbUpdateCustomerDetails.Foreground = new SolidColorBrush(Colors.Gray);
            UpdateCustAdd.BorderBrush = new SolidColorBrush(Colors.Orange);
            UpdateCustAdd.Foreground = new SolidColorBrush(Colors.Gray);
            UpdateCustDlNo.BorderBrush = new SolidColorBrush(Colors.Orange);
            UpdateCustDlNo.Foreground = new SolidColorBrush(Colors.Gray);
        }

        public void populateComboBox()
        {
            dt = new DataTable();
            dt = businessLayer.populateCustomerName();
            dt.TableName = "PopulateCustomer";
            DataRow dr = dt.NewRow();
            dr["CustomerName"] = "--Select--";
            dr["CustomerCode"] = "null";
            dt.Rows.InsertAt(dr, 0);
            cmbUpdateCustomerDetails.DataContext = dt;
            cmbUpdateCustomerDetails.DisplayMemberPath = dt.Columns["CustomerName"].ToString();
            cmbUpdateCustomerDetails.SelectedValuePath = dt.Columns["CustomerCode"].ToString();
        }

        
    }
}
