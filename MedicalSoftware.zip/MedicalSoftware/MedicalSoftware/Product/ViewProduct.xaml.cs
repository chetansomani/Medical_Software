﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;


namespace MedicalSoftware.Product
{
    /// <summary>
    /// Interaction logic for ViewProduct.xaml
    /// </summary>
    public partial class ViewProduct : UserControl
    {
        Product product;
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        DataSet ds;
        private int count;

        public int Count
        {
            get { return count; }
            set { count = value; }
        }

        public ViewProduct()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            StatusViewProductDetails.Visibility = Visibility.Collapsed;
            ListViewProdNames.Visibility = Visibility.Collapsed;
            ViewProductDetailsList.Visibility = Visibility.Hidden;
        }

        private void ViewProdNameDetails_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (ViewProdNameDetails.Text.Equals(""))
            {
                ViewProdNameDetails.BorderBrush = new SolidColorBrush(Colors.Orange);
                ViewProdNameDetails.Foreground = new SolidColorBrush(Colors.Gray);
                StatusViewProductDetails.Visibility = Visibility.Collapsed;
                ListViewProdNames.Visibility = Visibility.Collapsed;
                ViewProductDetailsList.Visibility = Visibility.Collapsed;
            }
            else
            {
                ViewProdNameDetails.BorderBrush = new SolidColorBrush(Colors.Gray);
                ViewProdNameDetails.Foreground = new SolidColorBrush(Colors.Orange);
                ds = businessLayer.viewProductDetails(ViewProdNameDetails.Text,count);
                if (ds.Tables["ProductTable"].Rows.Count == 0)
                {
                    ListViewProdNames.Visibility = Visibility.Collapsed;
                    StatusViewProductDetails.Visibility = Visibility.Visible;
                    StatusViewProductDetails.Text = "No Records Found";
                }
                else
                {
                    StatusViewProductDetails.Visibility = Visibility.Collapsed;
                    ListViewProdNames.Visibility = Visibility.Visible;
                    ListViewProdNames.DataContext = ds;
                    
                }
            }
        }

        private void ListViewProdNames_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int i = ListViewProdNames.SelectedIndex;
            if (i < 0)
            {
                MessageBox.Show("Select A Valid Record");
            }
            else
            {
               product = new Product((ListViewProdNames.SelectedItem as DataRowView).Row["ProductId"].ToString(), (ListViewProdNames.SelectedItem as DataRowView).Row["ProductBatchNo"].ToString(),
                     (ListViewProdNames.SelectedItem as DataRowView).Row["ProductMFG"].ToString(), (ListViewProdNames.SelectedItem as DataRowView).Row["ProductName"].ToString(),
                      (ListViewProdNames.SelectedItem as DataRowView).Row["ProductPack"].ToString(), Convert.ToInt64((ListViewProdNames.SelectedItem as DataRowView).Row["ProductQuantity"].ToString()), (ListViewProdNames.SelectedItem as DataRowView).Row["ProductExpiry"].ToString()
                      , Convert.ToDouble((ListViewProdNames.SelectedItem as DataRowView).Row["ProductMRP"].ToString()));
                //The Content Property Of ContentPresenter Is Binded To The Class Properties.
                ViewProductDetailsList.DataContext = this.product;
                ViewProductDetailsList.Visibility = Visibility.Visible;
            }
        }

        private void checkboxProdBatch_Checked(object sender, RoutedEventArgs e)
        {
            count = 0;
            checkboxProdName.IsChecked = false;
            txtBorderSearchProdBatch.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtProductNameType.Visibility = Visibility.Visible;
            txtProductNameType.Text = "Product BatchNo";
            ViewProdNameDetails.Visibility = Visibility.Visible;
        }

        private void checkboxProdBatch_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBorderSearchProdBatch.BorderBrush = new SolidColorBrush(Colors.White);
            txtProductNameType.Visibility = Visibility.Collapsed;
            ViewProdNameDetails.Visibility = Visibility.Collapsed;
        }

        private void checkboxProdName_Checked(object sender, RoutedEventArgs e)
        {
            count = 1;
            checkboxProdBatch.IsChecked = false;
            txtBorderSearchProdName.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtProductNameType.Visibility = Visibility.Visible;
            txtProductNameType.Text = "Product Name";
            ViewProdNameDetails.Visibility = Visibility.Visible;
        }

        private void checkboxProdName_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBorderSearchProdName.BorderBrush = new SolidColorBrush(Colors.White);
            txtProductNameType.Visibility = Visibility.Collapsed;
            ViewProdNameDetails.Visibility = Visibility.Collapsed;
        }

       
       

       
       
    }
}
