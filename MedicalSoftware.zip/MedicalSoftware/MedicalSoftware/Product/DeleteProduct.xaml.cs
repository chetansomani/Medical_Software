﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using MedicalSoftware;

namespace MedicalSoftware.Product
{
    /// <summary>
    /// Interaction logic for DeleteProduct.xaml
    /// </summary>
    public partial class DeleteProduct : UserControl
    {
        string prodbatch,prodName;
        Product product;
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        DataSet ds;
        private int count;

        public int Count
        {
            get { return count; }
            set { count = value; }
        }
        public DeleteProduct()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            StatusDeleteProductDetails.Visibility = Visibility.Collapsed;
            ListViewProdNames.Visibility = Visibility.Collapsed;
            ViewProductDetailsList.Visibility = Visibility.Hidden;
        }

        private void DeleteProdNameDetails_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DeleteProdNameDetails.Text.Equals(""))
            {
                DeleteProdNameDetails.BorderBrush = new SolidColorBrush(Colors.Orange);
                DeleteProdNameDetails.Foreground = new SolidColorBrush(Colors.Gray);
                StatusDeleteProductDetails.Visibility = Visibility.Collapsed;
                ListViewProdNames.Visibility = Visibility.Collapsed;
                ViewProductDetailsList.Visibility = Visibility.Collapsed;
            }
            else
            {
                DeleteProdNameDetails.BorderBrush = new SolidColorBrush(Colors.Gray);
                DeleteProdNameDetails.Foreground = new SolidColorBrush(Colors.Orange);
                ds = businessLayer.viewProductDetails(DeleteProdNameDetails.Text, count);
                if (ds.Tables["ProductTable"].Rows.Count == 0)
                {
                    ListViewProdNames.Visibility = Visibility.Collapsed;
                    StatusDeleteProductDetails.Visibility = Visibility.Visible;
                    StatusDeleteProductDetails.Text = "No Records Found";
                }
                else
                {
                    StatusDeleteProductDetails.Visibility = Visibility.Collapsed;
                    ListViewProdNames.Visibility = Visibility.Visible;
                    ListViewProdNames.DataContext = ds;

                }
            }
        }

        private void ListViewProdNames_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int i = ListViewProdNames.SelectedIndex;
            if (i < 0)
            {
            }
            else
            {
                product = new Product((ListViewProdNames.SelectedItem as DataRowView).Row["ProductId"].ToString(), (ListViewProdNames.SelectedItem as DataRowView).Row["ProductBatchNo"].ToString(),
                      (ListViewProdNames.SelectedItem as DataRowView).Row["ProductMFG"].ToString(), (ListViewProdNames.SelectedItem as DataRowView).Row["ProductName"].ToString(),
                       (ListViewProdNames.SelectedItem as DataRowView).Row["ProductPack"].ToString(), Convert.ToInt64((ListViewProdNames.SelectedItem as DataRowView).Row["ProductQuantity"].ToString()), (ListViewProdNames.SelectedItem as DataRowView).Row["ProductExpiry"].ToString()
                       , Convert.ToDouble((ListViewProdNames.SelectedItem as DataRowView).Row["ProductMRP"].ToString()));
                //The Content Property Of ContentPresenter Is Binded To The Class Properties.
                prodName = (ListViewProdNames.SelectedItem as DataRowView).Row["ProductName"].ToString();
                prodbatch = (ListViewProdNames.SelectedItem as DataRowView).Row["ProductBatchNo"].ToString();
                ViewProductDetailsList.DataContext = this.product;
                ViewProductDetailsList.Visibility = Visibility.Visible;
            }
        }

        private void btnDeleteProdDetails_Click(object sender, RoutedEventArgs e)
        {
            string messageContent = "Do You Want To Delete The Record Of Product" + " " + prodName + " "+"?";
            string mesageTitle = "Delete Product Confirmation";
            MessageWindow msgWindow = new MessageWindow(messageContent,mesageTitle);
            msgWindow.ShowDialog();
            if (MessageWindow.Count == 1)
            {
                int deleteResult = businessLayer.deleteProductDetails(prodbatch);
                if (deleteResult > 0)
                {
                    StatusDeleteProductDetails.Foreground = new SolidColorBrush(Colors.Gray);
                    StatusDeleteProductDetails.Text = "Deleted Successfully Details Of Product" + "  " + prodName;
                    StatusDeleteProductDetails.Visibility = Visibility.Visible;
                }
                else
                {
                    StatusDeleteProductDetails.Foreground = new SolidColorBrush(Colors.Red);
                    StatusDeleteProductDetails.Text = "Error In Deleting The Details Of Product" + " " + prodName;
                    StatusDeleteProductDetails.Visibility = Visibility.Visible;
                }
            }
            else
            {}
           
         }

        private void checkboxProdBatch_Checked(object sender, RoutedEventArgs e)
        {
            count = 0;
            checkboxProdName.IsChecked = false;
            txtBorderSearchProdBatch.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtProductNameType.Visibility = Visibility.Visible;
            txtProductNameType.Text = "Product BatchNo";
            DeleteProdNameDetails.Visibility = Visibility.Visible;
        }

        private void checkboxProdBatch_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBorderSearchProdBatch.BorderBrush = new SolidColorBrush(Colors.White);
            txtProductNameType.Visibility = Visibility.Collapsed;
            DeleteProdNameDetails.Visibility = Visibility.Collapsed;
        }

        private void checkboxProdName_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBorderSearchProdName.BorderBrush = new SolidColorBrush(Colors.White);
            txtProductNameType.Visibility = Visibility.Collapsed;
            DeleteProdNameDetails.Visibility = Visibility.Collapsed;
        }

        private void checkboxProdName_Checked(object sender, RoutedEventArgs e)
        {
            count = 1;
            checkboxProdBatch.IsChecked = false;
            txtBorderSearchProdName.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtProductNameType.Visibility = Visibility.Visible;
            txtProductNameType.Text = "Product Name";
            DeleteProdNameDetails.Visibility = Visibility.Visible;
        }

       

      
    }
}
