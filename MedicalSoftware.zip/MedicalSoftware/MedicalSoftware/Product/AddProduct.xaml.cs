﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MedicalSoftware.Product
{
    /// <summary>
    /// Interaction logic for AddProduct.xaml
    /// </summary>
    public partial class AddProduct : UserControl
    {
        BusinessAccessLayer businessLayer=new BusinessAccessLayer();
            
        public AddProduct()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            NewProductId.Text = businessLayer.autoProductId();
        }

        private void btnAddNewProductDetails_Click(object sender, RoutedEventArgs e)
        {
           
            Thickness marginText = ErrorStatus.Margin;
            ErrorStatus.Height = 20;
            ErrorStatus.Width = 200;
            if (NewProductBatchNo.Text.Equals(""))
            {
                NewProductBatchNo.BorderBrush = new SolidColorBrush(Colors.Red);
                ErrorStatus.Margin = new Thickness(40.0, -214.0, 0.0, 0.0);
                ErrorStatus.Text = "Enter Product BatchNo";
                ErrorStatus.Visibility = Visibility.Visible;
                NewProductBatchNo.Focus();
            }
            else
            {
                if (NewProductMFG.Text.Equals(""))
                {
                    NewProductMFG.BorderBrush = new SolidColorBrush(Colors.Red);
                    ErrorStatus.Margin = new Thickness(40.0, -120.0, 0.0, 0.0);
                    ErrorStatus.Text = "Enter Product MFG";
                    ErrorStatus.Visibility = Visibility.Visible;
                    NewProductMFG.Focus();
                }
                else
                {
                    if (NewProductName.Text.Equals(""))
                    {
                        NewProductName.BorderBrush = new SolidColorBrush(Colors.Red);
                        ErrorStatus.Margin = new Thickness(40.0, -30.0, 0.0, 0.0);
                        ErrorStatus.Text = "Enter Product Name";
                        ErrorStatus.Visibility = Visibility.Visible;
                        NewProductName.Focus();
                    }
                    else
                    {
                        if (NewProductPack.Text.Equals(""))
                        {
                            NewProductPack.BorderBrush = new SolidColorBrush(Colors.Red);
                            ErrorStatus.Margin = new Thickness(0.0, 60.0, 0.0, 0.0);
                            ErrorStatus.Text = "Enter Packs Of Product Available";
                            ErrorStatus.Visibility = Visibility.Visible;
                            NewProductPack.Focus();
                            
                        }
                        else
                        {
                            if (NewProductQuantity.Text.Equals(""))
                            {
                                NewProductQuantity.BorderBrush = new SolidColorBrush(Colors.Red);
                                ErrorStatus.Margin = new Thickness(0.0, 170.0, 0.0, 0.0);
                                ErrorStatus.Text = "Enter Quantity Available";
                                ErrorStatus.Visibility = Visibility.Visible;
                                NewProductQuantity.Focus();
                            }
                            else
                            {
                                if (NewProductExpiry.Text.Equals(""))
                                {
                                    NewProductExpiry.BorderBrush = new SolidColorBrush(Colors.Red);
                                    ErrorStatus.Margin = new Thickness(0.0, 270.0, 0.0, 0.0);
                                    ErrorStatus.Text = "Select Product Expiry Date";
                                    ErrorStatus.Visibility = Visibility.Visible;
                                    NewProductExpiry.Focus();
                                }
                                else
                                {
                                    if (NewProductMRP.Text.Equals(""))
                                    {
                                        NewProductMRP.BorderBrush = new SolidColorBrush(Colors.Red);
                                        ErrorStatus.Margin = new Thickness(40.0, 340.0, 0.0, 0.0);
                                        ErrorStatus.Text = "Enter MRP Of Product Available";
                                        ErrorStatus.Visibility = Visibility.Visible;
                                        NewProductMRP.Focus();
                                    }
                                    else
                                    {
                                        int result = businessLayer.newProductDetails(NewProductId.Text, NewProductBatchNo.Text, NewProductMFG.Text, NewProductName.Text, NewProductPack.Text, Convert.ToInt32(NewProductQuantity.Text), NewProductExpiry.SelectedDate.Value, Convert.ToDouble(NewProductMRP.Text));
                                        if (result > 0)
                                        {
                                            Status.Foreground = new SolidColorBrush(Colors.Gray);
                                            Status.Text = "Product" + " " + NewProductName.Text + " " + "Details Inserted Successfully";
                                            Status.Visibility = Visibility.Visible;
                                            
                                        }
                                        else
                                        {
                                            Status.Foreground = new SolidColorBrush(Colors.Red);
                                            Status.Text = "Error In Inserting The Details Of Product" + " " + NewProductName.Text ;
                                            Status.Visibility = Visibility.Visible;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void btnResetNewProductDetails_Click(object sender, RoutedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;

            NewProductBatchNo.Text = null;
            NewProductName.Text = null;
            NewProductMRP.Text = null;
            NewProductMFG.Text = null;
            NewProductPack.Text = null;
            NewProductQuantity.Text = null;
            NewProductExpiry.Text = null;
            NewProductBatchNo.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewProductBatchNo.Foreground = new SolidColorBrush(Colors.Gray);
            NewProductMFG.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewProductMFG.Foreground = new SolidColorBrush(Colors.Gray);
            NewProductName.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewProductName.Foreground = new SolidColorBrush(Colors.Gray);
            NewProductPack.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewProductPack.Foreground = new SolidColorBrush(Colors.Gray);
            NewProductQuantity.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewProductQuantity.Foreground = new SolidColorBrush(Colors.Gray);
            NewProductMRP.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewProductMRP.Foreground = new SolidColorBrush(Colors.Gray);
            NewProductExpiry.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewProductExpiry.Foreground = new SolidColorBrush(Colors.Gray);
        }

        private void NewProductBatchNo_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;
            if (NewProductBatchNo.Text.Equals(""))
            {
                NewProductBatchNo.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewProductBatchNo.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewProductBatchNo.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewProductBatchNo.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void NewProductMFG_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;
            if (NewProductMFG.Text.Equals(""))
            {
                NewProductMFG.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewProductMFG.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewProductMFG.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewProductMFG.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void NewProductName_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;
            if (NewProductName.Text.Equals(""))
            {
                NewProductName.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewProductName.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewProductName.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewProductName.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void NewProductPack_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;
            if (NewProductPack.Text.Equals(""))
            {
                NewProductPack.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewProductPack.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewProductPack.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewProductPack.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void NewProductQuantity_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;
            if (NewProductQuantity.Text.Equals(""))
            {
                NewProductQuantity.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewProductQuantity.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewProductQuantity.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewProductQuantity.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

       

        private void NewProductMRP_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;
            if (NewProductMRP.Text.Equals(""))
            {
                NewProductMRP.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewProductMRP.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewProductMRP.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewProductMRP.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        //private void NewProductExpiry_TextChanged(object sender, TextChangedEventArgs e)
        //{
            
        //}

        private void NewProductExpiry_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Hidden;
            Status.Visibility = Visibility.Hidden;
            if (NewProductExpiry.Text.Equals(""))
            {
                NewProductExpiry.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewProductExpiry.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewProductExpiry.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewProductExpiry.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

       
    }
}
