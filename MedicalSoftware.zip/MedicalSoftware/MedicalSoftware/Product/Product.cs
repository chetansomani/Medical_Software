﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MedicalSoftware.Product
{
    class Product
    {
        private static string prodId;

        public static string ProdId
        {
            get { return Product.prodId; }
            set { Product.prodId = value; }
        }


        private static string prodBatchNo;

        public static string ProdBatchNo
        {
            get { return prodBatchNo; }
            set { prodBatchNo = value; }
        }

        private static string prodMFG;

        public static string ProdMFG
        {
            get { return prodMFG; }
            set { prodMFG = value; }
        }
        private static string prodName;

        public static string ProdName
        {
            get { return prodName; }
            set { prodName = value; }
        }
        private static string prodPack;

        public static string ProdPack
        {
            get { return prodPack; }
            set { prodPack = value; }
        }
        private static long quantity;

        public static long Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }
        private static string prodExpiry;

        public static string ProdExpiry
        {
            get { return prodExpiry; }
            set { prodExpiry = value; }
        }
        private static double prodMRP;

        public static double ProdMRP
        {
            get { return prodMRP; }
            set { prodMRP = value; }
        }

        public Product()
        {

        }

        public Product(string prodId,string prodBatch,string prodMFG,string prodName,string prodPack,long prodQuant,string prodExpiry,double prodMRP)
        {
            ProdId = prodId;
            ProdBatchNo = prodBatch;
            ProdMFG = prodMFG;
            ProdMRP = prodMRP;
            ProdName = prodName;
            ProdPack = prodPack;
            Quantity = prodQuant;
            ProdExpiry = prodExpiry;
        }

    }
}
