﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace MedicalSoftware.Product
{
    /// <summary>
    /// Interaction logic for UpdateProduct.xaml
    /// </summary>
    public partial class UpdateProduct : UserControl
    {

        Product product;
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        DataSet ds;
        string prodId,productMFG, productName, productPack, productExpiry,prodBatchNO;
        long productQuant;
        double productMRP;
        private int count;

        public int Count
        {
            get { return count; }
            set { count = value; }
        }

        public UpdateProduct()
        {
            InitializeComponent();
        }

        private void UpdateProdNameDetails_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (UpdateProdNameDetails.Text.Equals(""))
            {
                UpdateProdNameDetails.BorderBrush = new SolidColorBrush(Colors.Orange);
                UpdateProdNameDetails.Foreground = new SolidColorBrush(Colors.Gray);
                StatusUpdateProductDetails.Visibility = Visibility.Collapsed;
                ListUpdateProdNames.Visibility = Visibility.Collapsed;
                UpdateProductDetailsList.Visibility = Visibility.Collapsed;
            }
            else
            {
                UpdateProdNameDetails.BorderBrush = new SolidColorBrush(Colors.Gray);
                UpdateProdNameDetails.Foreground = new SolidColorBrush(Colors.Orange);
                ds = businessLayer.viewProductDetails(UpdateProdNameDetails.Text,1);
                if (ds.Tables["ProductTable"].Rows.Count == 0)
                {
                    ListUpdateProdNames.Visibility = Visibility.Collapsed;
                    StatusUpdateProductDetails.Visibility = Visibility.Visible;
                    StatusUpdateProductDetails.Text = "No Records Found";
                }
                else
                {
                    StatusUpdateProductDetails.Visibility = Visibility.Collapsed;
                    ListUpdateProdNames.Visibility = Visibility.Visible;
                    ListUpdateProdNames.DataContext = ds;

                }
            }
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            StatusUpdateProductDetails.Visibility = Visibility.Collapsed;
            ListUpdateProdNames.Visibility = Visibility.Collapsed;
            UpdateProductDetailsList.Visibility = Visibility.Hidden;
        }

        private void ListUpdateProdNames_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int i = ListUpdateProdNames.SelectedIndex;
            if (i < 0)
            {
                
            }
            else
            {
                prodBatchNO = (ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductBatchNo"].ToString();
                prodId = (ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductId"].ToString();
                productExpiry = (ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductExpiry"].ToString();
                productMFG=(ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductMFG"].ToString();
                productMRP= Convert.ToDouble((ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductMRP"].ToString());
                productName=(ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductName"].ToString();
                productPack=(ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductPack"].ToString();
                productQuant=Convert.ToInt64((ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductQuantity"].ToString());
                product = new Product((ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductId"].ToString(), (ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductBatchNo"].ToString(),
                      (ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductMFG"].ToString(), (ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductName"].ToString(),
                       (ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductPack"].ToString(), Convert.ToInt64((ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductQuantity"].ToString()), (ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductExpiry"].ToString()
                       , Convert.ToDouble((ListUpdateProdNames.SelectedItem as DataRowView).Row["ProductMRP"].ToString()));
                //The Content Property Of ContentPresenter Is Binded To The Class Properties.
                UpdateProductDetailsList.DataContext = this.product;
                UpdateProductDetailsList.Visibility = Visibility.Visible;
                
            }
        }

        private void contentTxtProdMFG_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (contentTxtProdMFG.Text.Equals(""))
            {
                contentTxtProdMFG.BorderBrush = new SolidColorBrush(Colors.Orange);
                contentTxtProdMFG.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                contentTxtProdMFG.BorderBrush = new SolidColorBrush(Colors.Gray);
                contentTxtProdMFG.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void contentTxtProdName_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (contentTxtProdName.Text.Equals(""))
            {
                contentTxtProdName.BorderBrush = new SolidColorBrush(Colors.Orange);
                contentTxtProdName.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                contentTxtProdName.BorderBrush = new SolidColorBrush(Colors.Gray);
                contentTxtProdName.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void contentTxtProdPack_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (contentTxtProdPack.Text.Equals(""))
            {
                contentTxtProdPack.BorderBrush = new SolidColorBrush(Colors.Orange);
                contentTxtProdPack.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                contentTxtProdPack.BorderBrush = new SolidColorBrush(Colors.Gray);
                contentTxtProdPack.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void contentTxtProdQuant_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (contentTxtProdQuant.Text.Equals(""))
            {
                contentTxtProdQuant.BorderBrush = new SolidColorBrush(Colors.Orange);
                contentTxtProdQuant.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                contentTxtProdQuant.BorderBrush = new SolidColorBrush(Colors.Gray);
                contentTxtProdQuant.Foreground = new SolidColorBrush(Colors.Orange);
            }

        }

        private void contentTxtProdExpiry_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (contentTxtProdExpiry.Text.Equals(""))
            {
                contentTxtProdExpiry.BorderBrush = new SolidColorBrush(Colors.Orange);
                contentTxtProdExpiry.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                contentTxtProdExpiry.BorderBrush = new SolidColorBrush(Colors.Gray);
                contentTxtProdExpiry.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void contentTxtProdMRP_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (contentTxtProdMRP.Text.Equals(""))
            {
                contentTxtProdMRP.BorderBrush = new SolidColorBrush(Colors.Orange);
                contentTxtProdMRP.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                contentTxtProdMRP.BorderBrush = new SolidColorBrush(Colors.Gray);
                contentTxtProdMRP.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void btnUpdateProdDetails_Click(object sender, RoutedEventArgs e)
        {
            if (contentTxtProdMFG.Text.Equals(""))
            {
                contentTxtProdMFG.BorderBrush = new SolidColorBrush(Colors.Red);
                contentStatus.Text = "Enter Product MFG";
                contentStatus.Visibility = Visibility.Visible;
                contentTxtProdMFG.Focus();
            }
            else
            {
                if (contentTxtProdName.Text.Equals(""))
                {
                    contentTxtProdName.BorderBrush = new SolidColorBrush(Colors.Red);
                    contentStatus.Text = "Enter Product Name";
                    contentStatus.Visibility = Visibility.Visible;
                    contentTxtProdName.Focus();
                }
                else
                {
                    if (contentTxtProdPack.Text.Equals(""))
                    {
                        contentTxtProdPack.BorderBrush = new SolidColorBrush(Colors.Red);
                        contentStatus.Text = "Enter Product Pack";
                        contentStatus.Visibility = Visibility.Visible;
                        contentTxtProdPack.Focus();
                    }
                    else
                    {
                        if (contentTxtProdQuant.Text.Equals(""))
                        {
                            contentTxtProdQuant.BorderBrush = new SolidColorBrush(Colors.Red);
                            contentStatus.Text = "Enter Product Quantity";
                            contentStatus.Visibility = Visibility.Visible;
                            contentTxtProdQuant.Focus();
                        }
                        else
                        {
                            if (contentTxtProdExpiry.Text.Equals(""))
                            {
                                contentTxtProdExpiry.BorderBrush = new SolidColorBrush(Colors.Red);
                                contentStatus.Text = "Enter Product Expiry";
                                contentStatus.Visibility = Visibility.Visible;
                                contentTxtProdExpiry.Focus();
                            }
                            else
                            {
                                if (contentTxtProdMRP.Text.Equals(""))
                                {
                                    contentTxtProdMRP.BorderBrush = new SolidColorBrush(Colors.Red);
                                    contentStatus.Text = "Enter Product MRP";
                                    contentStatus.Visibility = Visibility.Visible;
                                    contentTxtProdMRP.Focus();
                                }
                                else
                                {
                                    contentStatus.Visibility = Visibility.Hidden;
                                    int result = businessLayer.updateProductDetails(prodId, prodBatchNO, contentTxtProdMFG.Text, contentTxtProdName.Text, contentTxtProdPack.Text, Convert.ToInt64(contentTxtProdQuant.Text),
                                        Convert.ToDateTime(contentTxtProdExpiry.Text), Convert.ToDouble(contentTxtProdMRP.Text));
                                    if (result > 0)
                                    {
                                        StatusUpdateProductDetails.Text="Product"+" "+contentTxtProdName.Text+" "+"Details Updated Succesfully";
                                        StatusUpdateProductDetails.Visibility = Visibility.Visible;
                                        //Need To Even Update The DataGridRow
                                    }
                                    else
                                    {
                                        StatusUpdateProductDetails.Text = "Error In Updating The Details Of Product"+" "+contentTxtProdName.Text;
                                        StatusUpdateProductDetails.Visibility = Visibility.Visible;
                                    }
                                }
                            }
                        }
                    }
                }
            }

        }

        private void btnCancelUpdateProdDetails_Click(object sender, RoutedEventArgs e)
        {
            contentStatus.Visibility = Visibility.Hidden;
            contentTxtProdExpiry.BorderBrush = new SolidColorBrush(Colors.Gray);
            contentTxtProdName.BorderBrush = new SolidColorBrush(Colors.Gray);
            contentTxtProdMRP.BorderBrush = new SolidColorBrush(Colors.Gray);
            contentTxtProdMFG.BorderBrush = new SolidColorBrush(Colors.Gray);
            contentTxtProdQuant.BorderBrush = new SolidColorBrush(Colors.Gray);
            contentTxtProdPack.BorderBrush = new SolidColorBrush(Colors.Gray);
            contentTxtProdExpiry.Text=productExpiry;
            contentTxtProdMRP.Text=productMRP.ToString();
            contentTxtProdName.Text=productName;
            contentTxtProdMFG.Text=productMFG;
            contentTxtProdQuant.Text=productQuant.ToString();
            contentTxtProdPack.Text=productPack;
            
        }
    }
}
