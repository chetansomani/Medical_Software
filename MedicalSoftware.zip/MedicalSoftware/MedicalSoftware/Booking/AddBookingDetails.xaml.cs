﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace MedicalSoftware.Booking
{
    /// <summary>
    /// Interaction logic for AddBookingDetails.xaml
    /// </summary>
    public partial class AddBookingDetails : UserControl
    {
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        DataTable dt;
        DataSet ds;
        private int count;

        public int Count
        {
            get { return count; }
            set { count = value; }
        }

        public AddBookingDetails()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            string bookId = businessLayer.autoBookingId();
            NewBookingId.Text = bookId;
        }

        private void NewBookingVendorName_TextChanged(object sender, TextChangedEventArgs e)
        {
            Thickness marginList = displayDataDetails.Margin;
            Thickness marginError = ErrorStatus.Margin;
            if (NewBookingVendorName.Text.Equals(""))
            {
                NewBookingVendorName.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewBookingVendorName.Foreground = new SolidColorBrush(Colors.Gray);
                Status.Visibility = Visibility.Collapsed;
                displayDataDetails.Visibility = Visibility.Collapsed;
                ErrorStatus.Visibility = Visibility.Collapsed;
            }
            else
            {
                NewBookingVendorName.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewBookingVendorName.Foreground = new SolidColorBrush(Colors.Orange);
                dt = businessLayer.displayVendorName(NewBookingVendorName.Text);
                if (dt.Rows.Count == 0)
                {
                    displayDataDetails.Visibility = Visibility.Collapsed;
                    ErrorStatus.Margin = new Thickness(75.0, -234.0, 0.0, 0.0);
                    ErrorStatus.Visibility = Visibility.Visible;
                    ErrorStatus.Text = "No Vendor Records Found";
                }
                else
                {
                    Count = 1;
                    Binding bind = new Binding();
                    Binding bind1 = new Binding("VendorName");
                    ErrorStatus.Visibility = Visibility.Collapsed;
                    Status.Visibility = Visibility.Collapsed;
                    displayDataDetails.Visibility = Visibility.Visible;
                    displayDataDetails.DataContext = dt;
                    displayDataDetails.SetBinding(ListView.ItemsSourceProperty, bind);
                    listColumnView.Header = "VendorName";
                    listColumnView.DisplayMemberBinding = bind1;
                    displayDataDetails.Margin = new Thickness(-270, 10, 0, 0);

                }
            }
        }

        private void NewBookingProductName_TextChanged(object sender, TextChangedEventArgs e)
        {
            Thickness marginList = displayDataDetails.Margin;
            if (NewBookingProductName.Text.Equals(""))
            {
                NewBookingProductName.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewBookingProductName.Foreground = new SolidColorBrush(Colors.Gray);
                Status.Visibility = Visibility.Collapsed;
                displayDataDetails.Visibility = Visibility.Collapsed;
                ErrorStatus.Visibility = Visibility.Collapsed;
            }
            else
            {
                NewBookingProductName.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewBookingProductName.Foreground = new SolidColorBrush(Colors.Orange);
                ds= businessLayer.viewProductDetails(NewBookingProductName.Text, 1);
                if (ds.Tables["ProductTable"].Rows.Count == 0)
                {
                    displayDataDetails.Visibility = Visibility.Collapsed;
                    ErrorStatus.Margin = new Thickness(70.0, -135.0, 0.0, 0.0);
                    ErrorStatus.Visibility = Visibility.Visible;
                    ErrorStatus.Text = "No Product Records Found";
                }
                else
                {
                    Count = 2;
                    Binding bind = new Binding("ProductTable");
                    Binding bind1 = new Binding("ProductName");
                    ErrorStatus.Visibility = Visibility.Collapsed;
                    Status.Visibility = Visibility.Collapsed;
                    displayDataDetails.Visibility = Visibility.Visible;
                    displayDataDetails.DataContext = ds;
                    displayDataDetails.SetBinding(ListView.ItemsSourceProperty,bind);
                    listColumnView.Header = "ProductName";
                    listColumnView.DisplayMemberBinding = bind1;
                    displayDataDetails.Margin = new Thickness(-270, 120, 0, 0);

                }
            }
        }

        private void displayDataDetails_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            int i = displayDataDetails.SelectedIndex;
            if (i < 0)
            {

            }
            else
            {
                if (Count == 1)
                {
                    string vendorName = (displayDataDetails.SelectedItem as DataRowView).Row["VendorName"].ToString();
                    NewBookingVendorName.Text = vendorName;
                    displayDataDetails.Visibility = Visibility.Collapsed;
                }
                else if (Count == 2)
                {
                    NewBookingProductName.Text = (displayDataDetails.SelectedItem as DataRowView).Row["ProductName"].ToString();
                    displayDataDetails.Visibility = Visibility.Collapsed;
                }
            }
        }


        private void NewBookingPacks_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Collapsed;
            Status.Visibility = Visibility.Collapsed;
            if (NewBookingPacks.Text.Equals(""))
            {
                NewBookingPacks.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewBookingPacks.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewBookingPacks.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewBookingPacks.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void NewBookingQuantity_TextChanged(object sender, TextChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Collapsed;
            Status.Visibility = Visibility.Collapsed;
            if (NewBookingQuantity.Text.Equals(""))
            {
                NewBookingQuantity.BorderBrush = new SolidColorBrush(Colors.Orange);
                NewBookingQuantity.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                NewBookingQuantity.BorderBrush = new SolidColorBrush(Colors.Gray);
                NewBookingQuantity.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void dtpNewBookingDate_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            ErrorStatus.Visibility = Visibility.Collapsed;
            Status.Visibility = Visibility.Collapsed;
            if (dtpNewBookingDate.SelectedDate.Equals(null))
            {
                dtpNewBookingDate.BorderBrush = new SolidColorBrush(Colors.Orange);
                dtpNewBookingDate.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                dtpNewBookingDate.BorderBrush = new SolidColorBrush(Colors.Gray);
                dtpNewBookingDate.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void cmbNewBookingStatus_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           
            if (cmbNewBookingStatus.SelectedIndex==0)
            {
                cmbNewBookingStatus.BorderBrush = new SolidColorBrush(Colors.Orange);
                cmbNewBookingStatus.Foreground = new SolidColorBrush(Colors.Gray);

            }
            else
            {
                ErrorStatus.Visibility = Visibility.Hidden;
                Status.Visibility = Visibility.Hidden;
                cmbNewBookingStatus.BorderBrush = new SolidColorBrush(Colors.Gray);
                cmbNewBookingStatus.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void btnAddNewBookingDetails_Click(object sender, RoutedEventArgs e)
        {
            Thickness marginText = ErrorStatus.Margin;
            ErrorStatus.Height = 20;
            ErrorStatus.Width = 200;
            if (NewBookingVendorName.Text.Equals(""))
            {
                NewBookingVendorName.BorderBrush = new SolidColorBrush(Colors.Red);
                ErrorStatus.Margin = new Thickness(105.0, -228.0, 0.0, 0.0);
                ErrorStatus.Text = "Enter Vendor Name";
                ErrorStatus.Visibility = Visibility.Visible;
                NewBookingVendorName.Focus();
            }
            else
            {
                if (NewBookingProductName.Text.Equals(""))
                {
                    NewBookingProductName.BorderBrush = new SolidColorBrush(Colors.Red);
                    ErrorStatus.Margin = new Thickness(99.0, -134.0, 0.0, 0.0);
                    ErrorStatus.Text = "Enter Product Name";
                    ErrorStatus.Visibility = Visibility.Visible;
                    NewBookingProductName.Focus();
                }
                else
                {
                    if (NewBookingPacks.Text.Equals(""))
                    {
                        NewBookingPacks.BorderBrush = new SolidColorBrush(Colors.Red);
                        ErrorStatus.Margin = new Thickness(40.0, -40.0, 0.0, 0.0);
                        ErrorStatus.Text = "Enter Cartoons Booked";
                        ErrorStatus.Visibility = Visibility.Visible;
                        NewBookingPacks.Focus();
                    }
                    else
                    {
                        if (NewBookingQuantity.Text.Equals(""))
                        {
                            NewBookingQuantity.BorderBrush = new SolidColorBrush(Colors.Red);
                            ErrorStatus.Margin = new Thickness(0.0, 50.0, 0.0, 0.0);
                            ErrorStatus.Text = "Enter Product Quantity Booked";
                            ErrorStatus.Visibility = Visibility.Visible;
                            NewBookingQuantity.Focus();

                        }
                        else
                        {
                            if (dtpNewBookingDate.SelectedDate.Equals(null))
                            {
                                dtpNewBookingDate.BorderBrush = new SolidColorBrush(Colors.Red);
                                ErrorStatus.Margin = new Thickness(30.0, 145.0, 0.0, 0.0);
                                ErrorStatus.Text = "Enter Date Of Booking";
                                ErrorStatus.Visibility = Visibility.Visible;
                               
                            }
                            else
                            {
                                if (cmbNewBookingStatus.SelectedIndex == 0)
                                {
                                    cmbNewBookingStatus.BorderBrush = new SolidColorBrush(Colors.Red);
                                    ErrorStatus.Margin = new Thickness(20.0, 240.0, 0.0, 0.0);
                                    ErrorStatus.Text = "Select Booking Status";
                                    ErrorStatus.Visibility = Visibility.Visible;
                                    cmbNewBookingStatus.Focus();
                                }
                               
                                    else
                                    {
                                        int result = businessLayer.insertBookingDetails(NewBookingId.Text, NewBookingVendorName.Text, NewBookingProductName.Text, Convert.ToInt32(NewBookingPacks.Text.ToString()), Convert.ToInt64(NewBookingQuantity.Text.ToString()),Convert.ToDateTime(dtpNewBookingDate.Text.ToString()), cmbNewBookingStatus.SelectedIndex.ToString());   
                                    if (result > 0)
                                        {
                                            Status.Foreground = new SolidColorBrush(Colors.Gray);
                                            Status.Text = "Booking" + " " + NewBookingId.Text + " " + "Details Inserted Successfully";
                                            Status.Visibility = Visibility.Visible;

                                        }
                                        else
                                        {
                                            Status.Foreground = new SolidColorBrush(Colors.Red);
                                            Status.Text = "Error In Inserting The Details Of Booking" + " " + NewBookingId.Text;
                                            Status.Visibility = Visibility.Visible;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            
        }

        private void btnResetNewBookingDetails_Click(object sender, RoutedEventArgs e)
        {
            nullMethod();
        }

        private void nullMethod()
        {
            displayDataDetails.Visibility = Visibility.Collapsed;
            ErrorStatus.Visibility = Visibility.Collapsed;
            Status.Visibility = Visibility.Collapsed;
            NewBookingPacks.Text = null;
            NewBookingProductName.Text = null;
            NewBookingQuantity.Text = null;
            NewBookingVendorName.Text = null;
            cmbNewBookingStatus.SelectedIndex = 0;
            dtpNewBookingDate.SelectedDate = null;
            dtpNewBookingDate.BorderBrush = new SolidColorBrush(Colors.Orange);
            dtpNewBookingDate.Foreground = new SolidColorBrush(Colors.Gray);
            cmbNewBookingStatus.BorderBrush = new SolidColorBrush(Colors.Orange);
            cmbNewBookingStatus.Foreground = new SolidColorBrush(Colors.Gray);
            NewBookingQuantity.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewBookingQuantity.Foreground = new SolidColorBrush(Colors.Gray);
            NewBookingPacks.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewBookingPacks.Foreground = new SolidColorBrush(Colors.Gray);
            NewBookingProductName.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewBookingProductName.Foreground = new SolidColorBrush(Colors.Gray);
            NewBookingVendorName.BorderBrush = new SolidColorBrush(Colors.Orange);
            NewBookingVendorName.Foreground = new SolidColorBrush(Colors.Gray);
        }

        
    }
}
