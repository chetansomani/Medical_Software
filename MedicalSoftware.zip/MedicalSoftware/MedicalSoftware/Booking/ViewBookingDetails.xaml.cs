﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace MedicalSoftware.Booking
{
    /// <summary>
    /// Interaction logic for ViewBookingDetails.xaml
    /// </summary>
    public partial class ViewBookingDetails : UserControl
    {
        int i;
        BusinessAccessLayer businessLayer = new BusinessAccessLayer();
        DataSet ds;
        private int count;
        DataTable dt;
        public int Count
        {
            get { return count; }
            set { count = value; }
        }

        private int getDetails;

        public int GetDetails
        {
            get { return getDetails; }
            set { getDetails = value; }
        }
        

        public ViewBookingDetails()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void checkboxBookPending_Checked(object sender, RoutedEventArgs e)
        {
            Count = 1;
            txtBorderSearchBookPending.BorderBrush = new SolidColorBrush(Colors.Orange);
            checkboxBookDispatched.IsChecked = false;
            checkboxBooReceived.IsChecked = false;
            checkboxGroupByDate.Visibility = Visibility.Visible;
            checkboxgroupByProduct.Visibility = Visibility.Visible;
            checkboxGroupByVendor.Visibility = Visibility.Visible;
            txtBorderGroupByDate.BorderBrush = new SolidColorBrush(Colors.White);
            txtBordergroupByProduct.BorderBrush = new SolidColorBrush(Colors.White);
            txtBorderGroupByVendor.BorderBrush = new SolidColorBrush(Colors.White);
            checkboxgroupByProduct.IsChecked = false;
            checkboxGroupByDate.IsChecked = false;
            checkboxGroupByVendor.IsChecked = false;
        }

        private void checkboxBookPending_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBorderSearchBookPending.BorderBrush = new SolidColorBrush(Colors.White);
            checkboxGroupByDate.Visibility = Visibility.Collapsed;
            checkboxgroupByProduct.Visibility = Visibility.Collapsed;
            checkboxGroupByVendor.Visibility = Visibility.Collapsed;
        }

        private void checkboxBookDispatched_Checked(object sender, RoutedEventArgs e)
        {
            Count = 2;
            txtBorderSearchBookDispatched.BorderBrush = new SolidColorBrush(Colors.Orange);
            checkboxBookPending.IsChecked = false;
            checkboxBooReceived.IsChecked = false;
            checkboxGroupByDate.Visibility = Visibility.Visible;
            checkboxgroupByProduct.Visibility = Visibility.Visible;
            checkboxGroupByVendor.Visibility = Visibility.Visible;
            txtBorderGroupByDate.BorderBrush = new SolidColorBrush(Colors.White);
            txtBordergroupByProduct.BorderBrush = new SolidColorBrush(Colors.White);
            txtBorderGroupByVendor.BorderBrush = new SolidColorBrush(Colors.White);
            checkboxgroupByProduct.IsChecked = false;
            checkboxGroupByDate.IsChecked = false;
            checkboxGroupByVendor.IsChecked = false;
        }

        private void checkboxBookDispatched_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBorderSearchBookDispatched.BorderBrush = new SolidColorBrush(Colors.White);
            checkboxGroupByDate.Visibility = Visibility.Collapsed;
            checkboxgroupByProduct.Visibility = Visibility.Collapsed;
            checkboxGroupByVendor.Visibility = Visibility.Collapsed;
        }

        private void checkboxBooReceived_Checked(object sender, RoutedEventArgs e)
        {
            Count = 3;
            txtBorderSearchBookReceived.BorderBrush = new SolidColorBrush(Colors.Orange);
            checkboxBookPending.IsChecked = false;
            checkboxBookDispatched.IsChecked = false;
            checkboxGroupByDate.Visibility = Visibility.Visible;
            checkboxgroupByProduct.Visibility = Visibility.Visible;
            checkboxGroupByVendor.Visibility = Visibility.Visible;
            txtBorderGroupByDate.BorderBrush = new SolidColorBrush(Colors.White);
            txtBordergroupByProduct.BorderBrush = new SolidColorBrush(Colors.White);
            txtBorderGroupByVendor.BorderBrush = new SolidColorBrush(Colors.White);
            checkboxgroupByProduct.IsChecked = false;
            checkboxGroupByDate.IsChecked = false;
            checkboxGroupByVendor.IsChecked = false;
        }

        private void checkboxBooReceived_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBorderSearchBookReceived.BorderBrush = new SolidColorBrush(Colors.White);
            checkboxGroupByDate.Visibility = Visibility.Collapsed;
            checkboxgroupByProduct.Visibility = Visibility.Collapsed;
            checkboxGroupByVendor.Visibility = Visibility.Collapsed;
        }

        private void checkboxGroupByVendor_Checked(object sender, RoutedEventArgs e)
        {
            getDetails = 1;
            txtBorderGroupByVendor.BorderBrush = new SolidColorBrush(Colors.Orange);
            checkboxgroupByProduct.IsChecked = false;
            checkboxGroupByDate.IsChecked = false;
            tbCommonName.Text = "Vendor Name";
            tbCommonName.Visibility = Visibility.Visible;
            txtCommonName.Visibility = Visibility.Visible;
            dtpDatePicker.Visibility = Visibility.Hidden;
            txtCommonName.Text = "";
         }

        private void checkboxGroupByVendor_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBorderGroupByVendor.BorderBrush = new SolidColorBrush(Colors.White);
            tbCommonName.Visibility = Visibility.Hidden;
            txtCommonName.Visibility = Visibility.Hidden;
            displayDataDetails.Visibility = Visibility.Hidden;
        }

        private void checkboxGroupByDate_Checked(object sender, RoutedEventArgs e)
        {
            getDetails = 2;
            txtBorderGroupByDate.BorderBrush = new SolidColorBrush(Colors.Orange);
            checkboxgroupByProduct.IsChecked = false;
            checkboxGroupByVendor.IsChecked = false;
            tbCommonName.Text = "Date Of Booking";
            tbCommonName.Visibility = Visibility.Visible;
            txtCommonName.Visibility = Visibility.Hidden;
            dtpDatePicker.Visibility = Visibility.Visible;
           
            
        }

        private void checkboxGroupByDate_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBorderGroupByDate.BorderBrush = new SolidColorBrush(Colors.White);
            tbCommonName.Visibility = Visibility.Hidden;
            dtpDatePicker.Visibility = Visibility.Hidden;
            displayDataDetails.Visibility = Visibility.Hidden;
         }

        private void checkboxgroupByProduct_Checked(object sender, RoutedEventArgs e)
        {
            getDetails = 3;
            txtBordergroupByProduct.BorderBrush = new SolidColorBrush(Colors.Orange);
            checkboxGroupByVendor.IsChecked = false;
            checkboxGroupByDate.IsChecked = false;
            tbCommonName.Text = "Product Name";
            tbCommonName.Visibility = Visibility.Visible;
            txtCommonName.Visibility = Visibility.Visible;
            dtpDatePicker.Visibility = Visibility.Hidden;
            txtCommonName.Text = "";
          
        }

        private void checkboxgroupByProduct_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBordergroupByProduct.BorderBrush = new SolidColorBrush(Colors.White);
            tbCommonName.Visibility = Visibility.Hidden;
            txtCommonName.Visibility = Visibility.Hidden;
            displayDataDetails.Visibility = Visibility.Hidden;
        }

        private void dtpDatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            StatusViewBookingDetails.Visibility = Visibility.Hidden;
            ListBoxBookingDetails.Visibility = Visibility.Hidden;
            if (dtpDatePicker.SelectedDate.Equals(null))
            {
                 dtpDatePicker.BorderBrush = new SolidColorBrush(Colors.Orange);
                 dtpDatePicker.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                 dtpDatePicker.BorderBrush = new SolidColorBrush(Colors.Gray);
                 dtpDatePicker.Foreground = new SolidColorBrush(Colors.Orange);
                 ds = businessLayer.viewBookingDetails(3, count.ToString(),"", dtpDatePicker.Text.ToString(), "");
                 if (ds.Tables["Booking"].Rows.Count == 0)
                 {
                     StatusViewBookingDetails.Foreground = new SolidColorBrush(Colors.Red);
                     StatusViewBookingDetails.Text = "No Records Found For Product " + " " + txtCommonName.Text.ToString() + " " + "with Status" + " ";
                     StatusViewBookingDetails.Visibility = Visibility.Visible;
                 }
                 else
                 {
                     ListBoxBookingDetails.DataContext = ds;
                     ListBoxBookingDetails.Visibility = Visibility.Visible;
                     StatusViewBookingDetails.Visibility = Visibility.Hidden;
                 }
            }
        }

        private void displayDataDetails_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            i = displayDataDetails.SelectedIndex;
            if (i < 0)
            {

            }
            else
            {
                if (getDetails == 1)
                {
                    string vendorName = (displayDataDetails.SelectedItem as DataRowView).Row["VendorName"].ToString();
                    txtCommonName.Text = vendorName;
                    displayDataDetails.Visibility = Visibility.Collapsed;
                    ds = businessLayer.viewBookingDetails(3, count.ToString(), "", "", txtCommonName.Text.ToString());
                    if (ds.Tables["Booking"].Rows.Count == 0)
                    {
                        StatusViewBookingDetails.Foreground = new SolidColorBrush(Colors.Red);
                        StatusViewBookingDetails.Text = "No Records Found For Vendor " + " " + txtCommonName.Text.ToString() + " " + "with Status" + " ";
                        StatusViewBookingDetails.Visibility = Visibility.Visible;
                        StatusViewBookingDetails.Margin = new Thickness(30,50,0,0);
                        ListBoxBookingDetails.Visibility = Visibility.Collapsed;
                    }
                    else
                    {
                        ListBoxBookingDetails.DataContext = ds;
                        ListBoxBookingDetails.Visibility = Visibility.Visible;
                        StatusViewBookingDetails.Visibility = Visibility.Hidden;
                    }
                }
                else if (getDetails == 3)
                {
                    txtCommonName.Text = (displayDataDetails.SelectedItem as DataRowView).Row["ProductName"].ToString();
                    displayDataDetails.Visibility = Visibility.Collapsed;
                    ds = businessLayer.viewBookingDetails(3, count.ToString(), "", "", txtCommonName.Text.ToString());
                    if (ds.Tables["Booking"].Rows.Count == 0)
                    {
                        StatusViewBookingDetails.Foreground = new SolidColorBrush(Colors.Red);
                        StatusViewBookingDetails.Text = "No Records Found For Product " + " " + txtCommonName.Text.ToString() + " " + "with Status" + " ";
                        StatusViewBookingDetails.Visibility = Visibility.Visible;
                        ListBoxBookingDetails.Visibility = Visibility.Collapsed;

                        StatusViewBookingDetails.Margin = new Thickness(30, 50, 0, 0);
                    }
                    else
                    {
                        ListBoxBookingDetails.DataContext = ds;
                        ListBoxBookingDetails.Visibility = Visibility.Visible;
                        StatusViewBookingDetails.Visibility = Visibility.Hidden;
                    }
                }
            }
        }

        private void txtCommonName_TextChanged(object sender, TextChangedEventArgs e)
        {
           
            StatusViewBookingDetails.Visibility = Visibility.Hidden;
            ListBoxBookingDetails.Visibility = Visibility.Hidden;
            if (txtCommonName.Text.Equals(""))
            {
                txtCommonName.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtCommonName.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                txtCommonName.BorderBrush = new SolidColorBrush(Colors.Gray);
                txtCommonName.Foreground = new SolidColorBrush(Colors.Orange);
                if (getDetails == 1)
                {
                   
                    dt = businessLayer.displayVendorName(txtCommonName.Text);
                    if (dt.Rows.Count == 0)
                    {
                        displayDataDetails.Visibility = Visibility.Collapsed;
                        StatusViewBookingDetails.Visibility = Visibility.Visible;
                        StatusViewBookingDetails.Text = "No Vendor Records Found";
                    }
                    else
                    {
                      
                        Binding bind = new Binding();
                        Binding bind1 = new Binding("VendorName");
                        StatusViewBookingDetails.Visibility = Visibility.Collapsed;
                        displayDataDetails.Visibility = Visibility.Visible;
                        displayDataDetails.DataContext = dt;
                        displayDataDetails.SetBinding(ListView.ItemsSourceProperty, bind);
                        listColumnView.Header = "VendorName";
                        listColumnView.DisplayMemberBinding = bind1;
                        displayDataDetails.Margin = new Thickness(-270, 5, 0, 0);
                       
                       
                           
                       
                    }
                }

               else if(getDetails==3)
               {
                 
                ds= businessLayer.viewProductDetails(txtCommonName.Text, 1);
                if (ds.Tables["ProductTable"].Rows.Count == 0)
                {
                    displayDataDetails.Visibility = Visibility.Collapsed;
                    StatusViewBookingDetails.Visibility = Visibility.Visible;
                    StatusViewBookingDetails.Text = "No Product Records Found";
                }
                else
                {
                   
                    Binding bind = new Binding("ProductTable");
                    Binding bind1 = new Binding("ProductName");
                    StatusViewBookingDetails.Visibility = Visibility.Collapsed;
                    displayDataDetails.Visibility = Visibility.Visible;
                    displayDataDetails.DataContext = ds;
                    displayDataDetails.SetBinding(ListView.ItemsSourceProperty,bind);
                    listColumnView.Header = "ProductName";
                    listColumnView.DisplayMemberBinding = bind1;
                    displayDataDetails.Margin = new Thickness(-270, 5, 0, 0);
                   
                      
                                 }
                    }

                    }
                }
            }
        }


    

