﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for MessageWindow.xaml
    /// </summary>
    public partial class MessageWindow : Window
    {
        private static string messageContent;

        public static string MessageContent1
        {
            get { return MessageWindow.messageContent; }
            set { MessageWindow.messageContent = value; }
        }

        private static string title;

        public static string Title1
        {
            get { return MessageWindow.title; }
            set { MessageWindow.title = value; }
        }

        private static string btnOkText;

        public static string BtnOkText
        {
            get { return MessageWindow.btnOkText; }
            set { MessageWindow.btnOkText = value; }
        }

        private static string btnCancelText;

        public static string BtnCancelText
        {
            get { return MessageWindow.btnCancelText; }
            set { MessageWindow.btnCancelText = value; }
        }

        private static int count;

        public static int Count
        {
            get { return MessageWindow.count; }
            set { MessageWindow.count = value; }
        }

        public MessageWindow()
        {
            InitializeComponent();
        }

        public MessageWindow(string mesageContent,string title)
        {
            InitializeComponent();
            MessageContent1 = mesageContent;
            Title1 = title;
           
        }

        private void messageBox_Loaded(object sender, RoutedEventArgs e)
        {
            messageBox.Title = Title1;
            MessageContent.Text = MessageContent1;
        }

        private void MessageOkButton_Click(object sender, RoutedEventArgs e)
        {
            Count = 1;
            this.Close();
        }

        private void MessageCancelButton_Click(object sender, RoutedEventArgs e)
        {
            Count = 0;
            this.Close();
        }

      
    }
}
