﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for ForgotPassword.xaml
    /// </summary>
    public partial class ForgotPassword : Window
    {
        BusinessAccessLayer businessLayer;
        public ForgotPassword()
        {
            InitializeComponent();
        }

        private void txtUsername_TextChanged(object sender, TextChangedEventArgs e)
        {
            ForgotStatus.Visibility = Visibility.Hidden;
            ForgotErrorStatus.Visibility = Visibility.Hidden;
            if (txtUsername.Text.Equals(""))
            {
                txtUsername.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtUsername.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                txtNewPass.Visibility = Visibility.Hidden;
                btnChangePass.Visibility = Visibility.Hidden;
                btnResetPass.Visibility = Visibility.Hidden;
                tbNewPassword.Visibility = Visibility.Hidden;
                ForgotErrorStatus.Visibility = Visibility.Hidden;
                txtAnswer.Visibility = Visibility.Hidden;
                tbAnswer.Visibility = Visibility.Hidden;
                txtQuestion.Visibility = Visibility.Hidden;
                selectQuestion.Visibility = Visibility.Hidden;
                txtUsername.BorderBrush = new SolidColorBrush(Colors.Gray);
                txtUsername.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }


        private void txtAnswer_PasswordChanged(object sender, RoutedEventArgs e)
        {
            txtNewPass.Visibility = Visibility.Hidden;
            ForgotStatus.Visibility = Visibility.Hidden;
            ForgotErrorStatus.Visibility = Visibility.Hidden;
            if (txtAnswer.Password.ToString().Equals(""))
            {
                txtAnswer.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtAnswer.Foreground = new SolidColorBrush(Colors.Gray);
                btnValidate.Visibility = Visibility.Hidden;
            }
            else
            {
                txtNewPass.Visibility = Visibility.Hidden;
                btnChangePass.Visibility = Visibility.Hidden;
                btnResetPass.Visibility = Visibility.Hidden;
                tbNewPassword.Visibility = Visibility.Hidden;
                ForgotErrorStatus.Visibility = Visibility.Hidden;
                txtAnswer.BorderBrush = new SolidColorBrush(Colors.Gray);
                txtAnswer.Foreground = new SolidColorBrush(Colors.Orange);
                btnValidate.Visibility = Visibility.Visible;
             
            }
        }

        private void txtNewPass_PasswordChanged(object sender, RoutedEventArgs e)
        {
            ForgotStatus.Visibility = Visibility.Hidden;
            ForgotErrorStatus.Visibility = Visibility.Hidden;
            if (txtNewPass.Password.ToString().Equals(""))
            {
                txtNewPass.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtNewPass.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                txtNewPass.BorderBrush = new SolidColorBrush(Colors.Gray);
                txtNewPass.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void btnChangePass_Click(object sender, RoutedEventArgs e)
        {
            string username=txtUsername.Text.ToString();
            businessLayer=new BusinessAccessLayer();
            Thickness marginText = ForgotStatus.Margin;
            if (txtNewPass.Password.ToString().Equals(""))
            {
                txtNewPass.Focus();
                txtNewPass.BorderBrush = new SolidColorBrush(Colors.Red);
                ForgotStatus.Visibility = Visibility.Visible;
                ForgotStatus.Text = "Enter New Password";
                ForgotStatus.Margin = new Thickness(65.0, 185.0, 0.0, 0.0);

            }

            else
            {
                MessageWindow getConfirmation = new MessageWindow("You Sure you want to change your password?", "Change Password");
                getConfirmation.ShowDialog();
                if (MessageWindow.Count == 1)
                {
                    int result = businessLayer.updateNewPassword(username, txtNewPass.Password.ToString());
                    if (result == 1)
                    {
                        ForgotErrorStatus.Text = "Updated Password Succesfully";
                        ForgotErrorStatus.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        ForgotErrorStatus.Text = "Error In Updating Password";
                        ForgotErrorStatus.Visibility = Visibility.Visible;
                    }
                }
                else
                {
                    getConfirmation.Close();
                }


            }
        }

        private void txtQuestion_TextChanged(object sender, TextChangedEventArgs e)
        {
            ForgotStatus.Visibility = Visibility.Hidden;
            ForgotErrorStatus.Visibility = Visibility.Hidden;
            if (txtQuestion.Text.Equals(""))
            {
                txtQuestion.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtQuestion.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                txtQuestion.BorderBrush = new SolidColorBrush(Colors.Gray);
                txtQuestion.Foreground = new SolidColorBrush(Colors.Orange);

            }
        }

        private void btnResetPass_Click(object sender, RoutedEventArgs e)
        {
            txtNewPass.Password = "";
            ForgotStatus.Visibility = Visibility.Hidden;
            ForgotErrorStatus.Visibility = Visibility.Hidden;
        }

        private void btngetQuestion_Click(object sender, RoutedEventArgs e)
        {
            string username;
            string questionId;
            string questSelected="";
            Thickness marginText = ForgotStatus.Margin;
            businessLayer = new BusinessAccessLayer();
             if (txtUsername.Text.Equals(""))
             {
                 txtUsername.BorderBrush = new SolidColorBrush(Colors.Red);
                 ForgotStatus.Visibility = Visibility.Visible;
                 ForgotStatus.Text = "Enter Username";
                 ForgotStatus.Margin = new Thickness(65.0, 40.0, 0.0, 0.0);
                 txtUsername.Focus();
             }
             else
             {
                 username = txtUsername.Text;
                 questionId = businessLayer.getQuestion(username);
                 if (questionId.Equals(""))
                 {
                     ForgotStatus.Visibility = Visibility.Visible;
                     txtUsername.BorderBrush = new SolidColorBrush(Colors.Red);
                     ForgotStatus.Margin = new Thickness(60.0, 40.0, 0.0, 0.0);
                     ForgotStatus.Text = "Incorrect Username";
                     txtUsername.Focus();
                 }
                 else
                 {
                     tbAnswer.Visibility = Visibility.Visible;
                     selectQuestion.Visibility = Visibility.Visible;
                     txtQuestion.Visibility = Visibility.Visible;
                     if (questionId.Equals("1"))
                     {
                         questSelected = "Your First Date";
                     }
                     else if(questionId.Equals("2"))
                     {
                         questSelected = "Your Phone Number";
                     }
                     else if (questionId.Equals("3"))
                     {
                         questSelected = "Your Nick Name";
                     }
                     txtQuestion.Text = questSelected;
                     txtQuestion.IsReadOnly = true;
                     txtAnswer.Visibility = Visibility.Visible;
                  }
             }
        }

        private void btnValidate_Click(object sender, RoutedEventArgs e)
        {
            string userName = txtUsername.Text.ToString();
            string answer = txtAnswer.Password.ToString();
            int validateVal = businessLayer.validateAns(userName,answer);
            if (validateVal == 1)
            {
                ForgotErrorStatus.Visibility = Visibility.Hidden;
                tbNewPassword.Visibility = Visibility.Visible;
                txtNewPass.Visibility = Visibility.Visible;
                btnChangePass.Visibility = Visibility.Visible;
                btnResetPass.Visibility = Visibility.Visible;
            }
            else
            {
                tbNewPassword.Visibility = Visibility.Hidden;
                ForgotErrorStatus.Text = "Answer In Valid.Enter The Right Answer";
                ForgotErrorStatus.Visibility = Visibility.Visible;
                txtNewPass.Visibility = Visibility.Hidden;
                btnChangePass.Visibility = Visibility.Hidden;
                btnResetPass.Visibility = Visibility.Hidden;
            }
        }

     
    }
}
