﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MedicalSoftware
{
    class Address
    {
        private static string add;

        public static string Add
        {
            get { return Address.add; }
            set { Address.add = value; }
        }


        private static string city;

        public static string City
        {
            get { return Address.city; }
            set { Address.city = value; }
        }


        private static string state;

        public static string State
        {
            get { return Address.state; }
            set { Address.state = value; }
        }


        private static long pincode;

        public static long Pincode
        {
            get { return Address.pincode; }
            set { Address.pincode = value; }
        }

        private static int c;

        public static int C
        {
            get { return Address.c; }
            set { Address.c = value; }
        }

        public Address()
        {
        }


        public Address(string add,string city,string state,long pincode)
        {
             Add = add;
                City = city;
                State = state;
                Pincode = pincode;
            

        }

        public void outputAddress(out string Oadd,out string Ocity,out string Ostate,out string Opincode)
        {
            Oadd = Add;
            Ocity = City;
            Ostate = State;
            Opincode = Pincode.ToString();
        }
    }
}
