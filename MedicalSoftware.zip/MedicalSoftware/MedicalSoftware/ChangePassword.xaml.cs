﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalSoftware
{
    /// <summary>
    /// Interaction logic for ChangePassword.xaml
    /// </summary>
    public partial class ChangePassword : Window
    {
        public ChangePassword()
        {
            InitializeComponent();
        }

        private void txtUsername_TextChanged(object sender, TextChangedEventArgs e)
        {
            Status.Visibility = Visibility.Hidden;
            ErrorStatus.Visibility = Visibility.Hidden;
            if (txtUsername.Text.Equals(""))
            {
                txtUsername.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtUsername.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                txtUsername.BorderBrush = new SolidColorBrush(Colors.Gray);
                txtUsername.Foreground = new SolidColorBrush(Colors.Orange);
            }
        }

        private void txtCurntPass_TextChanged(object sender, TextChangedEventArgs e)
        {
            Status.Visibility = Visibility.Hidden;
            ErrorStatus.Visibility = Visibility.Hidden;
            if (txtCurntPass.Text.Equals(""))
            {
                txtCurntPass.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtCurntPass.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                System.Text.RegularExpressions.Regex regex4 = new System.Text.RegularExpressions.Regex("[a-zA-Z]+");
                if (!regex4.IsMatch(txtCurntPass.Text))
                {
                    txtCurntPass.BorderBrush = new SolidColorBrush(Colors.Red);
                    txtCurntPass.Foreground = new SolidColorBrush(Colors.Red);
                    ErrorStatus.Text = "CurntPass Not In Correct Format." + "\n" + "Only Alphabets Accepted" + "\n" + "Ex:Hyderabad";
                    ErrorStatus.Visibility = Visibility.Visible;
                    txtCurntPass.Focus();
                }
                else
                {
                    txtCurntPass.BorderBrush = new SolidColorBrush(Colors.Gray);
                    txtCurntPass.Foreground = new SolidColorBrush(Colors.Orange);
                }
            }
        }

        private void txtNewPass_TextChanged(object sender, TextChangedEventArgs e)
        {
            Status.Visibility = Visibility.Hidden;
            ErrorStatus.Visibility = Visibility.Hidden;
            if (txtNewPass.Text.Equals(""))
            {
                txtNewPass.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtNewPass.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                System.Text.RegularExpressions.Regex regex2 = new System.Text.RegularExpressions.Regex("[a-zA-Z]+");
                if (!regex2.IsMatch(txtNewPass.Text))
                {
                    txtNewPass.BorderBrush = new SolidColorBrush(Colors.Red);
                    txtNewPass.Foreground = new SolidColorBrush(Colors.Red);
                    ErrorStatus.Text = "NewPass Not In Correct Format." + "\n" + "Only Alphabets Accepted" + "\n" + "Ex:AndhraPradesh";
                    ErrorStatus.Visibility = Visibility.Visible;
                    txtNewPass.Focus();
                }
                else
                {
                    txtNewPass.BorderBrush = new SolidColorBrush(Colors.Gray);
                    txtNewPass.Foreground = new SolidColorBrush(Colors.Orange);
                }
            }
        }

        private void txtRetypePass_TextChanged(object sender, TextChangedEventArgs e)
        {
            Status.Visibility = Visibility.Hidden;
            ErrorStatus.Visibility = Visibility.Hidden;
            if (txtRetypePass.Text.Equals(""))
            {
                txtRetypePass.BorderBrush = new SolidColorBrush(Colors.Orange);
                txtRetypePass.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {

                System.Text.RegularExpressions.Regex regex3 = new System.Text.RegularExpressions.Regex("[a-zA-Z]+");
                if (!regex3.IsMatch(txtRetypePass.Text))
                {
                    txtRetypePass.BorderBrush = new SolidColorBrush(Colors.Red);
                    txtRetypePass.Foreground = new SolidColorBrush(Colors.Red);
                    ErrorStatus.Text = "RetypePass Not In Correct Format." + "\n" + "It should Be Of 6 Digits Not Starting With 0." + "\n" + "[ex:RetypePass:500060]";
                    ErrorStatus.Visibility = Visibility.Visible;
                    txtRetypePass.Focus();
                }
                else
                {
                    txtRetypePass.BorderBrush = new SolidColorBrush(Colors.Gray);
                    txtRetypePass.Foreground = new SolidColorBrush(Colors.Orange);
                }
            }
        }

        private void btnChangePass_Click(object sender, RoutedEventArgs e)
        {
            Status.Visibility = Visibility.Hidden;
            ErrorStatus.Visibility = Visibility.Hidden;
            Thickness marginText = Status.Margin;
            Status.Height = 20;
            Status.Width = 200;
            if (txtUsername.Text.Equals(""))
            {
                txtUsername.BorderBrush = new SolidColorBrush(Colors.Red);
                Status.Margin = new Thickness(40.0, -45.0, 0.0, 0.0);
                Status.Text = "Enter Username";
                Status.Visibility = Visibility.Visible;
                txtUsername.Focus();
            }
            else
            {
                //System.Text.RegularExpressions.Regex regex1 = new System.Text.RegularExpressions.Regex("");
                //if (!regex1.IsMatch(txtUsername.Text))
                //{
                //    txtUsername.BorderBrush = new SolidColorBrush(Colors.Red);
                //    Status.Text = "Username Not In Correct Format";
                //    Status.Visibility = Visibility.Visible;
                //    txtUsername.Focus();
                //}
                //else
                //{
                if (txtCurntPass.Text.Equals(""))
                {
                    txtCurntPass.BorderBrush = new SolidColorBrush(Colors.Red);
                    Status.Margin = new Thickness(40.0, 20.0, 0.0, 0.0);
                    Status.Text = "Enter CurrentPassword";
                    Status.Visibility = Visibility.Visible;
                    txtCurntPass.Focus();
                }
                else
                {
                    if (txtNewPass.Text.Equals(""))
                    {
                        txtNewPass.BorderBrush = new SolidColorBrush(Colors.Red);
                        Status.Margin = new Thickness(40.0, 92.0, 0.0, 0.0);
                        Status.Text = "Enter NewPassword";
                        Status.Visibility = Visibility.Visible;
                        txtNewPass.Focus();
                    }
                    else
                    {
                        if (txtRetypePass.Text.Equals(""))
                        {
                            txtRetypePass.BorderBrush = new SolidColorBrush(Colors.Red);
                            Status.Margin = new Thickness(40.0, 164.0, 0.0, 0.0);
                            Status.Text = "Enter RetypePassword";
                            Status.Visibility = Visibility.Visible;
                            txtRetypePass.Focus();
                        }
                        else
                        {
                           if(!(txtRetypePass.Text.Equals(txtNewPass.Text)))
                           {
                               txtRetypePass.BorderBrush = new SolidColorBrush(Colors.Red);
                               Status.Margin = new Thickness(-100.0, 164.0, 0.0, 0.0);
                               Status.Text = "Passwords Dont Match..Try Again..";
                               Status.Visibility = Visibility.Visible;
                               txtRetypePass.Focus();
                           }
                            else
                            {
                                this.Close();
                                txtUsername.Text = null;
                                txtCurntPass.Text = null;
                                txtRetypePass.Text = null;
                                txtNewPass.Text = null;
                            }
                        }
                    }

                }
            }
        }

        private void btnResetPass_Click(object sender, RoutedEventArgs e)
        {
            txtUsername.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtCurntPass.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtNewPass.BorderBrush = new SolidColorBrush(Colors.Orange);
            txtRetypePass.BorderBrush = new SolidColorBrush(Colors.Orange);
            Status.Visibility = Visibility.Hidden;
            ErrorStatus.Visibility = Visibility.Hidden;
            txtUsername.Text = null;
            txtCurntPass.Text = null;
            txtRetypePass.Text = null;
            txtNewPass.Text = null;
        }
    }
}
